<template>
  <sections page="categories" />
</template>
