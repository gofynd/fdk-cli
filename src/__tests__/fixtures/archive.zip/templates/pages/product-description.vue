<template>
  <div>
    <div v-if="context.product.loading && !context.product.slug">
      <fdk-loader class="loader-ws"></fdk-loader>
    </div>
    <div v-else>
      <div class="product-details">
        <div class="bread-crumb">
          <bread-crumb :tree="getBreadCrumb()"></bread-crumb>
        </div>
        <div class="product-container">
          <product-view
            :product="context.product"
            :product_meta="context.product_meta"
            :context="context"
            :page_config="page_config"
            :global_config="global_config"
          ></product-view>
        </div>
        <!-- Product Description -->
        <div class="description-container" v-if="context.product.description">
          <h2 class="bold-lg title">Product Description</h2>
          <fdk-html-content
            class="product-long-description"
            :content="context.product.description"
          ></fdk-html-content>
        </div>
         <fdk-extension v-if="getTemplates('product_description_bottom').length" :templates="getTemplates('product_description_bottom')" /> 
        <div>
          <no-ssr>
            <fdk-accounts class="wishlist-btn">
              <template slot-scope="accountsData">
                <fdk-add-review
                  :product_type="context.product.type"
                  :product_uid="context.product.uid"
                >
                  <template slot-scope="reviewData">
                    <div
                      class="review-container"
                      v-if="
                        checkReview ||
                          (context.is_logged_in &&
                            page_config &&
                            page_config.props.reviews &&
                            reviewData.is_eligible)
                      "
                    >
                      <div>
                        <p class="review-container__title">
                          Ratings & Reviews

                          <a
                            class="add-review ukt-links"
                            v-if="
                              reviewData.is_eligible && context.is_logged_in
                            "
                            @click="
                              context.is_logged_in
                                ? redirectToAddReview()
                                : accountsData.openLogin()
                            "
                          >
                            Rate Product
                          </a>
                        </p>
                        <review-list
                          v-if="reviewList.length > 0"
                          :reviews="reviewList.slice(0, 3)"
                          :product="context.product"
                          :showtitle="false"
                        />
                        <div
                          v-else-if="reviewData.is_eligible"
                          class="no-reviews"
                        >
                          No reviews found
                        </div>
                      </div>

                      <div
                        class="view-all-ratings"
                        @click="redirectToReview"
                        v-if="
                          context &&
                            context.reviews &&
                            context.reviews.data &&
                            context.reviews.data.length &&
                            context.reviews.data.length > 3
                        "
                      >
                        <p>View all</p>
                        <span>&#8594;</span>
                      </div>
                    </div>
                  </template>
                </fdk-add-review>
              </template>
            </fdk-accounts>
          </no-ssr>
        </div>
        <div
          v-if="
            context.similar_products &&
              page_config &&
              page_config.props.similar_products
          "
        >
          <similar-product
            :similars="context.similar_products"
          ></similar-product>
        </div>
        <div
          v-if="
            context.frequently_compared_products &&
              context.frequently_compared_products.items &&
              context.frequently_compared_products.items.length > 0 &&
              page_config.props.compare_products
          "
        >
          <compare-products
            :compare="context.frequently_compared_products"
          ></compare-products>
        </div>
      </div>
    </div>
  </div>
</template>
<settings>
{
"props": [
    {
      "type": "checkbox",
      "id": "wishlist",
      "label": "Wishlist",
      "default": true,
      "info": "Show Wishlist for product"
    },
    {
      "type": "checkbox",
      "id": "reviews",
      "label": "Review",
      "default": true,
      "info": "Show Reviews of product"
    },
    {
      "type": "checkbox",
      "id": "add_to_compare",
      "label": "Add to Compare",
      "default": true,
      "info": "Allow comparison of products"
    },
    {
      "type": "checkbox",
      "id": "size_guide",
      "label": "Size Guide",
      "default": true,
      "info": "Show Size Guide"
    },
    {
      "type": "checkbox",
      "id": "product_request",
      "label": "Product Request",
      "default": true,
      "info": "Show Product Request"
    },
    {
      "type": "checkbox",
      "id": "share",
      "label": "Share",
      "default": true,
      "info": "Enable Sharing product"
    },
    {
      "type": "checkbox",
      "id": "store_selection",
      "label": "Seller Store Selection",
      "default": true,
      "info": "Allow to explicitly select stores"
    },
    {
      "type": "checkbox",
      "id": "compare_products",
      "label": "Compare Products",
      "default": true,
      "info": "Show Most Compared Products"
    },
    {
      "type": "checkbox",
      "id": "variants",
      "label": "Product Variants",
      "default": true,
      "info": "Show Product Variants"
    },
    {
      "type": "checkbox",
      "id": "ratings",
      "label": "Product Rating",
      "default": true,
      "info": "Show Product Ratings"
    },
    {
      "type": "checkbox",
      "id": "similar_products",
      "label": "Similar Products",
      "default": true,
      "info": "Show Similar Products"
    },
    {
      "type": "checkbox",
      "id": "bulk_prices",
      "label": "Bulk Prices",
      "default": true,
      "info": "Show Bulk Prices"
    },
    {
      "type": "checkbox",
      "id": "show_sellers",
      "label": "Show Sellers",
      "default": true,
      "info": "Show sellers"
    },
    {
      "type": "text",
      "id": "returnLink",
      "default": "/faq",
      "label": "Return Policy Link"
    },
    {
      "type": "extension",
      "id": "extension",
      "label": "Extension Positions",
      "info": "Handle extension in these positions",
      "positions": [
        {
          "value": "above_image_component",
          "text": "Above Image Component"
        },
        {
          "value": "below_image_component",
          "text": "Below Image Component"
        },
        {
          "value": "above_product_info",
          "text": "Above Product Info"
        },
        {
          "value": "below_price_component",
          "text": "Below Price Component"
        },
        {
          "value": "below_size_component",
          "text": "Below Size Component"
        },
        {
          "value": "below_add_to_cart",
          "text" : "Below Add To Cart"
        },
        {
          "value": "below_product_info",
          "text": "Below Product Info"
        },
        {
          "value": "product_description_bottom",
          "text": "Bottom Of Product Description"
        }
      ],
      "default": {}
    }
 ]
}
</settings>
<script>
import breadcrumb from "./../components/product-description/breadcrumb.vue";
import similarproduct from "./../components/product-description/similar-products.vue";
import compareproducts from "./../components/product-description/compare-products.vue";
import productview from "./../components/product-description/product-view.vue";
import ratinglist from "./../../global/components/reviews/review-list.vue";
import NoSSR from "vue-no-ssr";

export default {
  components: {
    "bread-crumb": breadcrumb,
    "similar-product": similarproduct,
    "compare-products": compareproducts,
    "product-view": productview,
    "review-list": ratinglist,
    "no-ssr": NoSSR,
  },
  data() {
    return {
      reviewList: [],
    };
  },
  methods: {
     getTemplates(position) {
      return this.page_config.props?.extension?.[position] || [];
    },
    getBreadCrumb() {
      let arr = [];
      arr.push({
        display: "Home",
        link: "/",
      });
      arr.push({
        display: "Brand",
        link: "/brands/",
      });
      arr.push({
        display: this.context.product.brand.name,
        link: "/products/?q=" + this.context.product.brand.name,
      });
      return arr;
    },
    redirectToReview() {
      this.$router.push({
        path: `${this.$route.path}/reviews`,
        query: { type: "product", uid: this.context.product.uid },
      });
    },
    redirectToAddReview() {
      this.$router.push({
        path: `${this.$route.path}/add-review`,
        query: { type: "product", uid: this.context.product.uid },
      });
    },
  },
  watch: {
    context(newValue) {
      if (
        newValue.reviews &&
        newValue.reviews.data &&
        newValue.reviews.data.length
      ) {
        this.reviewList = newValue.reviews.data;
      }
    },
  },
  computed: {
    checkReview() {
      if (
        this.page_config?.props?.reviews &&
        this.context?.reviews?.data?.length > 0
      ) {
        return true;
      }
      return false;
    },
  },
};
</script>

<style lang="less" scoped>
.description-container {
  background-color: @White;
  padding: 20px;
  margin-top: 20px;
  @media @mobile {
    padding: 10px;
    margin: 10px 0 0 0;
  }

  .title {
    margin: 10px 0 0 0;
    text-transform: uppercase;
    display: flex;
    justify-content: space-between;
    color: #41434c;
    a {
      padding: 0 0 0 20px;
      text-transform: capitalize;
    }
  }
  .product-long-description {
    line-height: 25px;
    margin-top: 20px;
    overflow-wrap: break-word;
  }
}

.review-container {
  background-color: @White;
  padding: 20px;
  margin-top: 15px;

  &__title {
    font-size: 20px;
    font-weight: bold;
    margin: 10px 0 0 0;
    text-transform: uppercase;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: #41434c;
    a {
      padding: 0 0 0 20px;
      text-transform: capitalize;
    }
  }
  .add-review {
    font-size: 14px;
    text-decoration: underline;
    color: @Black;
    cursor: pointer;
  }

  .no-reviews {
    margin: 20px 0;
  }

  .view-all-ratings {
    margin-top: 20px;
    display: inline-flex;
    align-items: center;
    border-bottom: 1px solid;
    cursor: pointer;
    p {
      margin-right: 10px;
    }
  }
}
</style>
