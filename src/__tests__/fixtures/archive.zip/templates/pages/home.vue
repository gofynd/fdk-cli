<template>
  <div class="home-cont">
    <sections page="home" />
  </div>
</template>
<style lang="less" scoped>
.no-select {
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -khtml-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  -webkit-tap-highlight-color: transparent;
}
.home-cont {
  .main-product-container {
    border-top: 0.5px solid rgba(211, 211, 211, 0.829);
    border-bottom: 0.5px solid rgba(211, 211, 211, 0.829);
    padding: 10px;
  }
}
</style>
<script>
export default {
  data() {
    return {};
  },
  methods: {
    loadMoreData(homeListing) {
      this.loading = true;
      if (homeListing.hasNext) {
        homeListing.loadmore().then(() => {
          this.loading = false;
        });
      }
    },
  },
  components: {},
};
</script>
