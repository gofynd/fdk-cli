<template>
  <div class="wl-cont">
    <div v-if="context.favourites && context.favourites.loading">
      <fdk-loader></fdk-loader>
    </div>
    <template
      v-if="
        context &&
          context.favourites &&
          context.favourites.items &&
          context.favourites.items.length
      "
    >
      <div class="section-main-container">
        <h2 class="section-heading">
          Wishlist
        </h2>
        <fdk-infinite-favourites>
          <template slot-scope="infiniteLoaderData">
            <div class="grid-wrapper">
              <div class="group-cards">
                <div
                  v-for="(product, index) in context.favourites.items"
                  :key="`p-wl-${index}`"
                >
                  <fdk-link :link="redirectPdp(product)" class="wl-link">
                    <fy-product-card
                      :isWishListPage="true"
                      :product="product"
                    />
                  </fdk-link>
                </div>
                <fdk-loader
                  id="loader"
                  v-if="infiniteLoaderData.hasNext"
                ></fdk-loader>
              </div>
            </div>
          </template>
        </fdk-infinite-favourites>
      </div>
    </template>
    <div
      v-else-if="
        context.favourites &&
          !context.favourites.loading &&
          !context.favourites.items.length
      "
    >
      <fdk-empty-state title="Your Wishlist is empty." />
    </div>
  </div>
</template>
<style lang="less" scoped>
.wl-cont {
  min-height: 600px;
  background: @White;
  .section-main-container {
    position: relative;
    padding-bottom: 50px;
    background-color: transparent;
  }
  .section-heading {
    padding: 20px 0 0 0;
    font-size: 30px;
    font-weight: 700;
    text-transform: uppercase;
    margin-bottom: 30px;
    text-align: left;
  }
  .wl-link {
    -webkit-tap-highlight-color: transparent;
  }
  .grid-wrapper {
    margin: 0 20px;
  }
  .group-cards {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(15%, 1fr));
    grid-auto-rows: auto;
    grid-gap: 2em;
  }
  @media screen and (max-width: 768px) {
    .group-cards {
      grid-template-columns: repeat(auto-fill, minmax(40%, 1fr));
      grid-gap: 0.5em;
    }
  }
}
</style>
<script>
import productCard from "./../../global/components/fy-product-card.vue";
export default {
  name: "wishlist",
  components: {
    "fy-product-card": productCard,
  },
  data() {
    return {};
  },
  methods: {
    redirectPdp(product) {
      if (product.sellable) {
        return `/product/${product.slug}`;
      }
      return;
    }
  },
};
</script>
