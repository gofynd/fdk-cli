<template>
  <sections page="collections" />
</template>
