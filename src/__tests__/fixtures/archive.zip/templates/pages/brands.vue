<template>
  <sections page="brands" />
</template>
