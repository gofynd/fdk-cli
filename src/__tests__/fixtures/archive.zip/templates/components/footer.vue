<template>
  <div>
    <div class="desktop-footer">
      <div class="fyndFeatures" v-if="context.app_info.business_highlights">
        <div class="blocks">
          <div
            class="block-item"
            v-for="(data, index) in context.app_info.business_highlights"
            :key="index"
          >
            <span class="feaure-icon">
              <span class="inline-svg">
                <img :src="data.icon" />
              </span>
            </span>
            <span class="feature-data">
              <div class="feature-h1 bold-xl cl-DarkGrey">{{ data.title }}</div>
              <div class="feature-text regular-xs cl-DarkGrey">
                {{ data.sub_title }}
              </div>
            </span>
          </div>
        </div>
      </div>
      <!-- Main Footer -->
      <div class="footer">
        <div class="footer-container">
          <div class="footer-container-box">
            <div class="footer-border footer-border-box">
              <div class="subscribe-container">
                <span class="alignment">
                  <img :src="logoUrl" class="footer-fynd-logo alignment" />
                </span>
                <span class="alignment logo-content">
                  <div class="logo-title">{{ context.name }}</div>
                  <div class="logo-subtitle">{{ context.description }}</div>
                </span>
              </div>
            </div>
          </div>
          <div class="footer-container-box">
            <div class="footer-border-box social-icons-box">
              <div class="subscribe-container">
                <ul class="icons-box">
                  <li
                    v-for="(social, index) in context.app_info.social_links"
                    :key="index"
                  >
                    <span v-if="social.link">
                      <fdk-link :link="social.link" :title="social.title">
                        <img alt="social.title" :src="social.icon" />
                      </fdk-link>
                    </span>
                  </li>
                </ul>
              </div>
              <div class="subscribe-container">
                <ul class="icons-links-box">
                  <li v-for="(item, index) in context.navigation" :key="index">
                    <fdk-link
                      class="social-icons"
                      :link="item.link"
                      target="_blank"
                      >{{ item.display }}</fdk-link
                    >
                    <span class="_2_sXK _3JjKc">|</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Footer bottom -->
      <div class="_2S9rh">
        <div class="_3zxBY">
          <div class="_2q1FD">
            <div class="_2ZXtD vh_aj">
              <ul class="_1r85L _1prJF">
                <li
                  v-for="(data, index) in getFooterLinks"
                  :key="index"
                  class="links-list"
                >
                  <fdk-link
                    class="_2_sXK _2GkDx"
                    :link="data.link"
                    target="_blank"
                    >{{ data.title }}</fdk-link
                  >
                  <span class="_2_sXK _2GkDx list-seperator">|</span>
                </li>
              </ul>
              <div class="_1r85L _1prJF">
                <span class="_3CF3_ _2_sXK _2GkDx">
                  {{ context.app_info.copyright_text }}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Mobile Footer -->
    <div class="mobile-footer">
      <div class="-q-Yp">
        <div class="_2Wo8X">
          <ul>
            <li
              class="_2w5-u"
              v-for="(item, index) in context.navigation"
              :key="index"
            >
              <fdk-link
                class="light-xs clDarkGrey"
                :link="item.link"
                target="_blank"
                >{{ item.display }}</fdk-link
              >
            </li>
          </ul>
        </div>
        <div class="_2Wo8X">
          <ul>
            <li
              class="_2w5-u"
              v-for="(data, index) in context.app_info.links"
              :key="index"
            >
              <fdk-link
                class="light-xxs clDarkGrey"
                :link="data.link"
                target="_blank"
                >{{ data.title }}</fdk-link
              >
            </li>
          </ul>
        </div>
        <div class="-Mlx8 clDarkGrey light-xxs">
          {{ context.app_info.copyright_text }}
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { logoUrl } from "../../helper/utils";
export default {
  name: "fdk-footer",
  props: {
    msg: String,
  },
  mounted() {
    this.context.navigation.forEach((item, index) => {
      this.navs.push(item);
    });
  },
  computed: {
    logoUrl() {
      return logoUrl(this.context.logo, this.context.mobileLogo);
    },
    getFooterLinks() {
      let links = [];
      links = this.context.app_info && this.context.app_info.links;
      links = links.filter((entry) => {
        return !!entry.link;
      });
      return links;
    },
  },
  methods: {
    getBottomNavigation() {},
  },

  data: function data() {
    return {
      navs: [],
    };
  },
};
</script>
<style scoped>
._2w5-u:last-child ._2_sXK ._3JjKc {
  display: none;
}
a {
  text-decoration: none;
}

body {
  margin-left: auto;
  margin-right: auto;
  background: #f8f8f8;
}

.desktop-footer {
  margin-top: 35px;
}

.fyndFeatures {
  background: #fff;
  display: block;
}

.blocks {
  width: 100%;
  opacity: 0.7;
  max-width: 1200px;
  margin: 0 auto;
  display: flex;
  flex-direction: row;
  flex-wrap: nowrap;
  justify-content: space-between;
  align-items: flex-start;
  align-content: flex-start;
}

.block-item {
  padding: 25px 0;
  max-width: 350px;
  display: flex;
  flex-direction: row;
  flex-wrap: nowrap;
  justify-content: flex-start;
  align-items: flex-start;
  align-content: flex-start;
}

.feature-data {
  padding: 8px 0 0 15px;
}

.feature-text {
  margin-top: 3px;
  line-height: 21px;
}

.bold-xl {
  font-weight: 700;
  font-size: 16px;
}

.regular-xs {
  font-weight: 400;
  font-size: 14px;
}

.footer {
  background: #fff;
}

.footer-container {
  max-width: 1200px;
  margin: 0 auto;
}

.footer-container-box {
  background: #fff;
  display: table;
  vertical-align: top;
  width: 100%;
  box-sizing: border-box;
}

.footer-fynd-logo {
  height: 24px;
  background-size: cover;
}

.icons-box li a:hover {
  opacity: 0.7;
}

.footer-border-box {
  padding: 20px 0;
  display: table;
  vertical-align: top;
  width: 100%;
  box-sizing: border-box;
}

.footer-border {
  border-bottom: 1px solid #ececec;
}

.subscribe-container {
  display: table-cell;
  vertical-align: middle;
}

.logo-content {
  padding: 0 0 0 5px;
}

.alignment {
  display: inline-block;
}

.logo-title {
  font-weight: 700;
  font-size: 12px;
  line-height: 17px;
}

.logo-subtitle {
  font-weight: 300;
  font-size: 12px;
}

.subscribe-form {
  float: right;
}

.form-input {
  height: 43px;
  min-width: 400px;
  max-width: 400px;
  display: inline-block;
}

.form-input input[type="text"] {
  height: 100%;
  outline: 0;
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;
}

.form-input input[type="text"] {
  width: 70%;
  float: left;
  padding-left: 10px;
  background-color: #fff;
  border: 1px solid #ccc;
  box-sizing: border-box;
  border-radius: 5px 0 0 5px;
}

.icons-box {
  padding-left: 0px;
}

.social-icons-box {
  padding: 12px 0;
}

ul {
  list-style: none;
}

._3JjKc {
  font-weight: 300;
  font-size: 14px;
}

.icons-box li a {
  margin: 0 12px;
}

.form-input input[type="submit"] {
  width: 30%;
  background-color: #f5f5f5;
  border: 1px solid #ccc;
  border-radius: 0 5px 5px 0;
  padding: 9px;
  color: #41434c;
  border-left: 0;
  cursor: pointer;
  height: 100%;
}

.icons-box li {
  border: 0;
  display: inline-block;
  vertical-align: top;
}

.icons-links-box li {
  border: 0;
  display: inline-block;
  vertical-align: top;
}

.icons-links-box {
  text-align: right;
}

.icons-links-box li:first-child a {
  margin: 0 12px 0 0;
}

.icons-links-box li a {
  margin: 0 12px;
  font-weight: 300;
  font-size: 14px;
  color: #41434c;
  text-decoration: none;
}

.icons-box li:first-child a {
  margin-left: 0;
}

.social-icons {
  display: inline-block;
}

.links-container {
  text-align: right;
}

.links-container li a {
  text-decoration: none;
}

.links-container li:first-child a {
  font-weight: 300;
  font-size: 14px;

  margin: 0 12px 0 0;
  text-decoration: none;
}

.links-container li:last-child a {
  margin-right: 0;
  text-decoration: none;
}

/* Footer Bottom */

._1qAdG,
._2S9rh {
  max-width: 1200px;
  margin: 0 auto;
  padding: 15px 0;
}

._1qAdG,
._3zxBY {
  display: table;
  vertical-align: top;
  width: 100%;
  box-sizing: border-box;
  padding: 0;
  text-align: center;
}

._1qAdG,
._2q1FD {
  display: table;
  vertical-align: top;
  width: 100%;
  box-sizing: border-box;
}

._1qAdG,
._3zxBY,
.vh_aj {
  width: 43%;
}

._1qAdG,
._3zxBY,
._2ZXtD {
  display: table-cell;
  vertical-align: middle;
}

._1qAdG,
._1prJF {
  vertical-align: top;
}

._1r85L {
  display: inline-block;
}

._1qAdG li,
._3zxBY li,
.vh_aj li {
  line-height: 8px;
}

._1qAdG li,
._3zxBY li,
._2ZXtD li {
  display: inline-block;
  vertical-align: middle;
}

._1qAdG li:first-child a,
._3zxBY li:first-child a,
._2ZXtD li:first-child a {
  margin: 0 12px 0 0;
}

._1qAdG li a,
._3zxBY li a,
._2ZXtD li a {
  margin: 0 12px;
}

._2GkDx {
  font-weight: 300;
  font-size: 12px;
}

.-I9Ex,
._3CF3_ {
  text-align: center;
  padding: 5px 0;
}

._2_sXK {
  color: #41434c;
}

._1prJF {
  vertical-align: top;
}

._1r85L {
  padding-left: 0px;
  margin: 0px;
  display: inline-block;
}

.nMDMO {
  float: right;
}

._2ZXtD {
  display: table-cell;
  vertical-align: middle;
}

.zqqtQ {
  display: inline-block;
  text-align: center;
}

._1qKMK li {
  border: 0;
}

._2ZXtD li {
  display: inline-block;
  vertical-align: middle;
}

.zqqtQ li {
  border: 0;
}

._1qKMK li:first-child a {
  margin: 0;
}

._2ZXtD li:first-child a {
  margin: 0 12px 0 0;
}

._2ZXtD li a {
  margin: 0 12px;
}

._2ZXtD li:last-child {
  border: none;
}

.zqqtQ a {
  padding: 0;
}

._2uycS {
  display: inline-block;
}

.links-list:last-child .list-seperator {
  display: none;
}

._2Eywc {
  width: 140px;
  height: 46px;
}

._1qKMK li:last-child a {
  margin: 0 12px 0 6px;
}

.R3gRW {
  width: 140px;
  height: 46px;
}

.B0xmQ {
  display: inline-block;
  text-align: right;
}

.tek6F {
  height: 43px;
  min-width: 300px;
  max-width: 400px;
  display: inline-block;
}

.tek6F input[type="submit"],
.tek6F input[type="text"] {
  height: 100%;
  outline: 0;
  appearance: none;
}

.tek6F input[type="text"] {
  width: 70%;
  float: left;
  padding-left: 10px;
  background-color: #fff;
  border: 1px solid #ccc;
  box-sizing: border-box;
  border-radius: 5px 0 0 5px;
}

._3JjKc {
  font-weight: 300;
  font-size: 14px;
}

.tek6F input[type="submit"] {
  width: 30%;
  background-color: #f5f5f5;
  border: 1px solid #ccc;
  border-radius: 0 5px 5px 0;
  padding: 9px;
  color: #41434c;
  border-left: 0;
  cursor: pointer;
}

._1qKMK {
  padding: 0px;
  margin: 0px;
}
.mobile-footer {
  display: none;
}
/* Mobile Footer */
.-q-Yp {
  background-color: #f8f8f8;
  margin-bottom: 10px;
  padding: 0 10px;
}

._1w44m ul {
  margin: 0;
  padding: 0;
}
._1w44m {
  display: inline-block;
  vertical-align: top;
  padding: 15px 0 10px;
}
._1w44m,
._2Wo8X,
._2hxtJ {
  width: 100%;
  text-align: center;
}

._2cZ-Z,
._2hxtJ {
  display: flex;
  justify-content: center;
}
._1w44m li {
  display: inline;
  padding: 0 5px;
}

._1w44m a {
  padding: 0;
}
._1w44m a img {
  width: 121px;
  height: 42px;
}

.icon {
  display: inline-block;
}

._2_cZ-Z {
  height: 43px;
  min-width: 300px;
  max-width: 400px;
}

._2cZ-Z input[type="text"] {
  width: 65%;
  float: left;
  height: 100%;
  padding-left: 10px;
  background-color: #fff;
  border: 1px solid #ccc;
  border-radius: 5px 0 0 5px;
  outline: 0;
}

._2w5-u a {
  padding: 0 6px;
  display: block;
}
.light-xs {
  font-size: 14px;
}

._2cZ-Z input[type="submit"] {
  height: 100%;
  width: 35%;
  background-color: #f5f5f5;
  border: 1px solid #ccc;
  border-radius: 0 5px 5px 0;
  padding: 9px;
  color: #41434c;
  border-left: 0;
  outline: 0;
  -webkit-appearance: none;
}
._2cZ-Z input[type="text"] {
  box-sizing: border-box;
}

._2Wo8X {
  padding: 12px 0 10px;
  vertical-align: top;
  border-bottom: 1px solid #e4e5e6;
}
._2NxGs,
._2Wo8X,
._2w5-u {
  display: inline-block;
}
._1w44m,
._2Wo8X,
._2hxtJ {
  width: 100%;
  text-align: center;
}
._2w5-u {
  vertical-align: top;
  border-right: 1px solid #898a93;
}

._2w5-u:last-child {
  border: none;
}
ul {
  margin: 0;
  padding: 0;
}
._2Wo8X {
  padding: 12px 0 10px;
  vertical-align: top;
  border-bottom: 1px solid #e4e5e6;
}
.-Mlx8,
._34WsE {
  text-align: center;
  padding: 5px 0;
}
.light-xxs {
  font-size: 13px;
}
@media (max-width: 800px) {
  .mobile-footer {
    display: block;
  }

  .desktop-footer {
    display: none;
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
  }
}
</style>
