<template>
  <div>
    <div class="desktop-header-container">
      <div class="desktop-header">
        <div class="main-header">
          <span>
            <fdk-link :link="'/'">
              <img class="fynd-logo" :src="logoUrl" />
            </fdk-link>
          </span>
          <fdk-search class="searchBox">
            <template slot-scope="searchData">
              <span>
                <input
                  class="searchInput"
                  :placeholder="global_config.props.search_placeholder"
                  autocomplete="off"
                  v-model="searchtext"
                  type="text"
                  id="search"
                  @keyup.enter="
                    selectedIndex === null
                      ? getEnterSearchData(searchData)
                      : getSearchData()
                  "
                  @keydown="onArrowKey"
                  @input="inputSearchResults(searchData)"
                  v-on:click="showlist = true"
                />
                <div
                  ref="searchAutoCompleteResult"
                  class="autocomplete autocompleteActive"
                  v-click-outside="clickOutside"
                >
                  <div v-if="searchData.suggestions.length > 0 && showlist">
                    <ul>
                      <li
                        v-for="(value, name, index) in getGroupedMobileResults(
                          searchData.suggestions.slice(0, 8)
                        )"
                        :key="name + index"
                        v-on:click="showlist = false"
                      >
                        <span class="prevSearch">{{ name }}</span>
                        <template v-for="(data, index) in value">
                          <div
                            @click="routeToPage(data.url)"
                            class="suggestion-data"
                            :key="data.display + index"
                            v-bind:class="{
                              focus:
                                isFocusedItem(data) && selectedIndex != null,
                            }"
                          >
                            <div class="suggestion-image">
                              <img :src="data.logo.url" />
                            </div>
                            <div>{{ data.display }}</div>
                          </div>
                        </template>
                      </li>
                    </ul>
                  </div>
                  <div>
                    <ul>
                      <li v-if="searchData.noResults && showlist">
                        <fdk-link
                          :link="'/products/?q=' + searchtext"
                          @click.stop.prevent="
                            showlist = false;
                            searchtext = '';
                          "
                          class="suggestion-data"
                          >Search for {{ searchtext }}</fdk-link
                        >
                      </li>
                    </ul>
                  </div>
                </div>
              </span>
            </template>
          </fdk-search>
          <span
            class="newsBox"
            v-if="
              context.offers && context.offers.active && context.offers.sub_text
            "
          >
            <span class="_3aFih">{{ context.offers.sub_text }}</span>
          </span>
          <div class="header-icons">
            <fdk-link
              :link="'/cart/bag'"
              class="wishlist-icon"
              v-if="isMounted && !global_config.props.disable_cart"
            >
              <div class="profile-icons">
                <img title="Cart" src="../../assets/images/shopping-bag1.svg" />
              </div>
              <div v-if="context.cart_item_count" class="cart-count">
                {{ context.cart_item_count }}
              </div>
            </fdk-link>
            <span class="seperator">|</span>
            <fdk-accounts>
              <template slot-scope="accountsData">
                <div
                  class="slide"
                  v-if="!accountsData.is_logged_in && isMounted"
                  @click="accountsData.openLogin"
                >
                  <fdk-link>
                    <div class="profile-icons">
                      <img title="Wishlist" src="../../assets/images/heart1.svg" />
                    </div>
                  </fdk-link>
                </div>
                <div v-else>
                  <fdk-link
                    :link="'/wishlist/'"
                    class="wishlist-icon"
                    v-if="isMounted"
                  >
                    <div class="profile-icons">
                      <img title="Wishlist" src="../../assets/images/heart1.svg" />
                    </div>
                    <div
                      v-if="
                        context.favourite_ids &&
                        context.favourite_ids.length > 0
                      "
                      class="favourite-count"
                    >
                      {{ context.favourite_ids.length }}
                    </div>
                  </fdk-link>
                </div>
              </template>
            </fdk-accounts>
            <span class="seperator">|</span>
            <fdk-accounts>
              <template slot-scope="accountsData">
                <div
                  class="slide"
                  v-if="!accountsData.is_logged_in && isMounted"
                  @click="accountsData.openLogin"
                >
                  <fdk-link>
                    <div class="profile-icons">
                      <img title="Profile" src="../../assets/images/user1.svg" />
                    </div>
                  </fdk-link>
                </div>
                <div v-else>
                  <fdk-link :link="'/profile/details'">
                    <div class="profile-icons">
                      <img title="Profile" src="../../assets/images/user-active1.svg" />
                    </div>
                  </fdk-link>
                </div>
              </template>
            </fdk-accounts>
            <span class="seperator">|</span>
            <a @click="routetoSettingPage" class="setting light-sm">
              <img title="Settings" src="../../assets/images/settings1.svg" />
            </a>
          </div>
        </div>
        <div class="sub-header">
          <div class="sub-header-menu">
            <div
              v-for="(menu, index) in context.navigation"
              :key="index"
              class="sub-header-menu-container"
            >
              <fdk-link class="header-nav-menu" :link="menu.link">{{
                menu.display
              }}</fdk-link>
              <div v-if="menu.sub_navigation">
                <div class="l2-category-container">
                  <div class="column-wrapper">
                    <ul
                      v-for="(submenu, index) in menu.sub_navigation"
                      :key="index"
                    >
                      <li class="l2-category-list">
                        <fdk-link :link="submenu.link" class="l2-category">{{
                          submenu.display
                        }}</fdk-link>
                        <ul v-if="submenu.sub_navigation">
                          <li
                            v-for="(menu, index) in submenu.sub_navigation"
                            :key="index"
                            class="l3-category-list"
                          >
                            <fdk-link :link="menu.link" class="l3-category">{{
                              menu.display
                            }}</fdk-link>
                          </li>
                        </ul>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--Mobile header  -->
    <div class="mobile-header">
      <div class="_3gra0">
        <div class="mobile-main-header">
          <div>
            <fdk-link :link="'/'" class="_2Ads9">
              <img :src="logoUrl" class="_1ReGX" :alt="context.name" />
            </fdk-link>
          </div>

          <div class="searchbar-align">
            <fdk-search class="mobileSearchBox">
              <template slot-scope="searchData">
                <input
                  class="mobileSearchInput"
                  placeholder="Search"
                  autocomplete="off"
                  v-model="mobileSearchtext"
                  type="text"
                  id="mobilesearch"
                  @keyup.enter="getEnterSearchDataMobile(searchData)"
                  @input="searchData.fetchSuggestions(mobileSearchtext)"
                  v-on:focus="mobileshowlist = true"
                />
                <div
                  class="mobile-autocomplete autocompleteActive"
                  v-click-outside="mobileclickOutside"
                >
                  <div
                    v-if="searchData.suggestions.length > 0 && mobileshowlist"
                  >
                    <ul v-if="searchData.suggestions.length > 0">
                      <li
                        v-for="(value, name, index) in getGroupedMobileResults(
                          searchData.suggestions.slice(0, 8)
                        )"
                        :key="name + index"
                        @click="mobileshowlist = false"
                      >
                        <span class="prevSearch">{{ name }}</span>
                        <template v-for="(data, index) in value">
                          <fdk-link
                            v-on:click="mobileshowlist = false"
                            :link="data.url"
                            :key="data.display + index"
                            >{{ data.display }}</fdk-link
                          >
                        </template>
                      </li>
                    </ul>
                  </div>
                  <div v-if="searchData.noResults && mobileshowlist">
                    <ul>
                      <li @click.stop="mobileshowlist = false">
                        <fdk-link :link="'/products/?q=' + mobileSearchtext"
                          >Search for {{ mobileSearchtext }}</fdk-link
                        >
                      </li>
                    </ul>
                  </div>
                </div>
              </template>
            </fdk-search>
          </div>

          <div class="_1P1HH">
            <fdk-link
              :link="'/cart/bag'"
              class="_216KH"
              v-if="isMounted && !global_config.props.disable_cart"
            >
              <div class="_3B-d0">
                <div class="icon">
                  <img src="../../assets/images/shopping-bag1.svg" />
                </div>
                <div
                  v-if="context.cart_item_count && isMounted"
                  class="cart-item"
                >
                  {{ context.cart_item_count }}
                </div>
              </div>
            </fdk-link>
            <fdk-link :link="'/wishlist'" class="_216KH">
              <div class="_3B-d0">
                <div class="icon">
                  <img src="../../assets/images/heart1.svg" />
                </div>
                <div
                  v-if="
                    context.favourite_ids &&
                    context.favourite_ids.length > 0 &&
                    isMounted
                  "
                  class="cart-item"
                >
                  {{ context.favourite_ids.length }}
                </div>
              </div>
            </fdk-link>
            <fdk-accounts class="mobile-account-popup">
              <template slot-scope="accountsData">
                <div
                  class="slide"
                  v-if="!accountsData.is_logged_in && isMounted"
                  @click="accountsData.openLogin"
                >
                  <fdk-link class="_216KH _31E2l">
                    <div class="icon">
                      <img src="../../assets/images/user1.svg" />
                    </div>
                  </fdk-link>
                </div>
                <div v-else>
                  <fdk-link :link="'/profile'" class="_216KH _31E2l">
                    <div class="icon">
                      <img src="../../assets/images/user-active1.svg" />
                    </div>
                  </fdk-link>
                </div>
              </template>
            </fdk-accounts>
            <a @click="routetoSettingPage" class="_216KH setting light-sm">
              <img src="../../assets/images/settings1.svg" />
            </a>
          </div>
        </div>
        <div>
          <div class="_2l50X" id="siteMenu">
            <ul class="_1gxW9">
              <li
                class="_1ua7g"
                v-for="(menu, index) in context.navigation"
                :key="index"
              >
                <fdk-link
                  class="_3Dmej clDarkGrey regular-xxxs"
                  :link="menu.link"
                  >{{ menu.display }}</fdk-link
                >
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import groupBy from "lodash/groupBy";
import map from "lodash/map";
import { detectMobileWidth, logoUrl } from "../../helper/utils";

export default {
  name: "fdk-header",
  props: {
    msg: String,
  },
  data() {
    return {
      searchtext: "",
      mobileSearchtext: "",
      showlist: false,
      mobileshowlist: false,
      accessibleItems: [],
      items: [],
      isMounted: false,
      selectedIndex: null,
    };
  },
  mounted() {
    this.isMounted = true;
  },
  computed: {
    getGroupedResults() {
      const grouped = groupBy(this.items, (data) => data.type);
      const results = map(grouped, (it) => it);
      this.accessibleItems = [];
      for (let i = 0; i < results.length; i++) {
        this.accessibleItems = this.accessibleItems.concat(results[i]);
      }
      return grouped;
    },
    logoUrl() {
      return logoUrl(this.context.logo, this.context.mobile_logo);
    },
  },
  methods: {
    routeToPage(url) {
      this.searchtext = "";
      this.$router.push(url);
    },
    getGroupedSearchResults(item) {
      this.items = item;
      return this.getGroupedResults;
    },
    getEnterSearchData(searchData) {
      if(this.searchtext.trim()) {
        this.showlist = false;
        searchData.executeQuery(this.searchtext);
      }
    },
    getEnterSearchDataMobile(searchData) {
      if(this.mobileSearchtext.trim()) {
        this.mobileshowlist = false;
        searchData.executeQuery(this.mobileSearchtext);
      }
    },
    inputSearchResults(searchData) {
      this.showlist = true;
      this.selectedIndex = null;
      searchData.fetchSuggestions(this.searchtext);
    },
    onArrowKey(event) {
      const KEY_UP = 38;
      const KEY_DOWN = 40;
      switch (event.keyCode) {
        case KEY_UP:
          if (this.selectedIndex === null) {
            this.selectedIndex = 0;
          } else if (this.selectedIndex > 0) {
            this.selectedIndex--;
          }
          break;
        case KEY_DOWN:
          if (this.selectedIndex === null) {
            this.selectedIndex = 0;
          } else if (this.selectedIndex < this.accessibleItems.length - 1) {
            this.selectedIndex++;
          }
          break;
      }
    },
    isFocusedItem(item) {
      const selectedItem = this.accessibleItems[this.selectedIndex];
      if (selectedItem) {
        return (
          item.display === selectedItem.display &&
          item.type === selectedItem.type
        );
      }
      return false;
    },
    getSearchData() {
      this.showlist = false;
      let path = this.accessibleItems[this.selectedIndex].url;
      this.$router.push({ path: path });
      this.searchtext = "";
    },
    clickOutside: function clickOutside(event) {
      if (event && event.target.id !== "search") {
        this.showlist = false;
      }
    },
    mobileclickOutside: function mobileclickOutside(event) {
      if (event && event.target.id !== "mobilesearch") {
        this.mobileshowlist = false;
      }
    },
    getGroupedMobileResults: function getGroupedMobileResults(item) {
      let grouped = groupBy(item, (data) => data.type);
      return grouped;
    },
    routetoSettingPage() {
      if (detectMobileWidth()) {
        this.$router.push("/setting");
      } else {
        this.$router.push("/setting/currency");
      }
    },
  },
};
</script>
<style lang="less" scoped>
body {
  margin: 0 auto;
}

ul,
li {
  margin: 0;
  padding: 0;
  list-style: none;
}

.main-header {
  max-width: 1200px;
  position: relative;
  height: 60px;
  margin: 0 auto;
  line-height: 60px;
  box-sizing: border-box;
  display: flex;
  align-items: center;
}
.desktop-header-container,
.mobile-header {
  .setting {
    // width: 50px;
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
    @media @tablet {
      align-items: flex-start;
      height: 24px;
    }
    svg {
      cursor: pointer;
      fill: #000000;
      width: 20px;
      height: 20px;
      @media @tablet {
        width: 21px;
        height: 21px;
      }
    }
  }
}
.fynd-logo {
  vertical-align: middle;
  height: 40px;
}

.suggestion-data {
  font-weight: 400;
  font-size: 12px;
  align-items: center;
  color: #41434c;
  white-space: nowrap;
  text-overflow: ellipsis;
  display: flex;
  overflow: hidden;
  height: 50px;
  border-bottom: 1px solid #f5f5f5;
  cursor: pointer;
  .suggestion-image {
    width: 30px;
    padding-right: 10px;
    img {
      width: 30px;
    }
  }
}

.header-nav-menu {
  text-decoration: none;
  white-space: nowrap;
  cursor: pointer;
  outline: 0;
  -webkit-tap-highlight-color: rgba(255, 255, 255, 0);
  text-transform: uppercase;
}
.header-icons {
  display: flex;
}
.header-nav-menu:hover:after {
  width: 100%;
  background: #41434c;
}

.header-nav-menu:after {
  content: "";
  display: block;
  margin: auto;
  height: 2px;
  width: 0;
  background: transparent;
  transition: width 0.3s ease, background-color 0.3s ease;
}
.sub-header-menu {
  position: relative;
}

.seperator {
  color: #ececec;
  padding: 0 11px;
  cursor: default;
  user-select: none;
}
.wishlist-icon {
  position: relative;
}
.favourite-count {
  top: 10px;
}

.favourite-count,
.cart-count {
  position: absolute;
  bottom: 10px;
  right: 12px;
  width: 15px;
  height: 15px;
  line-height: 15px;
  border-radius: 5px;
  font-size: 9px;
  text-align: center;
  padding: 2px;
  vertical-align: middle;
  background-color: #ee478d;
  color: #fff;
}

.autocomplete {
  position: absolute;
  top: 51px;
  background: #fff;
  width: 97%;
  border-top: 0;
  padding: 0;
  z-index: 5;
  left: -1px;
}

.autocomplete ul,
.mobile-autocomplete ul {
  padding: 0 14px;
}

.autocomplete li,
.mobile-autocomplete li {
  line-height: 10px;
}

.prevSearch {
  font-weight: 700;
  font-size: 12px;
  color: #41434c;
  height: 36px;
  display: flex;
  align-items: center;
  /*background: #f4f5f6;
  padding-left: 0.5em;*/
  margin: 5px 0;
  text-transform: capitalize;
}

.autocomplete li a {
  font-weight: 400;
  font-size: 12px;
  align-items: center;
  color: #41434c;
  white-space: nowrap;
  text-overflow: ellipsis;
  display: flex;
  overflow: hidden;
  height: 50px;
  border-bottom: 1px solid #f5f5f5;
}
.focus {
  background: #f4f5f6;
}
.mobile-autocomplete li a {
  font-size: 12px;
  line-height: 20px;
  height: 20px;
  font-weight: 400;
  color: #41434c;
  white-space: nowrap;
  padding: 10px;
  overflow: hidden;
  display: flex;
  align-items: center;
  border-bottom: 1px solid #e4e5e6;
}
.autocompleteActive {
  /*border-left: 1px solid #ececec;
  border-right: 1px solid #ececec;
  border-bottom: 1px solid #ececec;*/
  border-radius: 8px;
  box-shadow: 0px 10px 10px rgba(0, 0, 0, 0.07);
}

.l2-category {
  font-weight: 700;
  width: 240px;
  padding: 7px 0;
  color: #41434c;
  font-size: 13px;
}

.l2-category:hover {
  color: #33b2c1;
}

.l2-category-list,
.l3-category-list {
  line-height: 34px;
  text-align: left;
}

.l2-category-container {
  visibility: hidden;
  position: fixed;
  left: 0;
  z-index: 6;
  top: 104px;
  width: 100%;
  visibility: hidden;
  text-align: center;
  background: #fff;
  line-height: normal;
  box-shadow: 0 3px 5px -3px #ccc;
}

.sub-header-menu-container {
  display: flex;
  line-height: 42px;
  padding: 0 7px;
  font-size: 12px;
}

.sub-header-menu-container:first-child {
  padding-left: 0;
}

.sub-header-menu-container:last-child {
  padding-right: 0;
}

.hovered-content {
  display: flex;
}
.sub-header-menu div:hover .l2-category-container {
  visibility: visible;
  transition-delay: 300ms;
}

.column-wrapper {
  display: flex;
  width: 1200px;
  margin: 0 auto;
}

.l3-category {
  font-weight: 400;
  width: 240px;
  padding: 7px 0;
  color: #41434c;
  font-size: 13px;
}

.l3-category:hover {
  color: #33b2c1;
}

.searchBox {
  flex-grow: 1;
  display: inline-block;
  box-sizing: border-box;
  position: relative;
  margin-left: 10px;
}

.mobileSearchBox {
  display: inline-block;
  box-sizing: border-box;
  position: relative;
  margin-left: 10px;
  width: 100%;
}

.searchInput {
  background: #fff
    url(https://hdn-1.fynd.com/company/884/applications/000000000000000000000001/theme/pictures/free/original/theme-image-1599686580382.svg)
    no-repeat scroll 12px;
  padding-left: 40px;
  border-radius: 4px;
  width: 97%;
  height: 40px;
  outline: 0;
  min-height: 40px;
  border: 0;
  appearance: none;
  box-sizing: border-box;
  font-weight: 400;
  font-size: 12px;
  -webkit-font-smoothing: antialiased;
  background-color: #f2f2f2;
}

.mobileSearchInput {
  background: #fff
    url(https://hdn-1.fynd.com/company/884/applications/000000000000000000000001/theme/pictures/free/original/theme-image-1599686580382.svg)
    no-repeat scroll 8px;
  padding-left: 35px;
  border-radius: 4px;
  width: 100%;
  height: 40px;
  outline: 0;
  min-height: 40px;
  border: 0;
  appearance: none;
  box-sizing: border-box;
  font-weight: 400;
  font-size: 12px;
  -webkit-font-smoothing: antialiased;
}

.mobile-autocomplete {
  position: fixed;
  top: 52px;
  background: #fff;
  width: 100%;
  border-top: 0;
  padding: 0;
  z-index: 6;
  left: -1px;
}

.cart-icon {
  background-image: url(https://hdn-1.fynd.com/company/884/applications/000000000000000000000001/theme/pictures/free/original/theme-image-1598077746481.png);
}

.favourite-icon {
  background-image: url(https://hdn-1.fynd.com/company/884/applications/000000000000000000000001/theme/pictures/free/original/theme-image-1598078039525.png);
}

.account-icon {
  background-image: url(https://hdn-1.fynd.com/company/884/applications/000000000000000000000001/theme/pictures/free/original/theme-image-1598078039542.png);
}

.account-loggedIn-icon {
  background-image: url(https://hdn-1.fynd.com/company/884/applications/000000000000000000000001/theme/pictures/free/original/theme-image-1598079266707.png);
  background-position: center center;
  background-repeat: no-repeat;
}

.profile-icons {
  display: inline-flex;
  width: 24px;
  height: 24px;
  vertical-align: middle;
}

.newsBox {
  background: #fff
    url(https://hdn-1.fynd.com/company/884/applications/000000000000000000000001/theme/pictures/free/original/theme-image-1598078140005.png)
    no-repeat scroll 12px;
  padding-left: 40px;
  border-radius: 4px;
  width: 24%;
  height: 40px;
  outline: 0;
  min-height: 40px;
  line-height: 40px;
  border: 0;
  color: #ed365e;
  appearance: none;
  margin: -2px 15px 0 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 700;
  font-size: 14px;
  -webkit-font-smoothing: antialiased;
}

.sub-header {
  position: relative;
  width: 100%;
  margin: 0 auto;
  height: 44px;
  line-height: 44px;
  background: #fff;
  box-sizing: border-box;
}

.sub-header-menu {
  display: flex;
  justify-content: left;
  margin: 0 auto;
  max-width: 1200px;
}

.sub-header a {
  color: #41434c;
  padding: 0 6px;
}

.dropdown-content {
  background: #fff;
  width: 100%;
}
.mobile-header {
  display: none;
}

/* Mobile Header */

.mobile-main-header {
  display: flex;
  background: #fff;
  height: 50px;
  padding: 0 10px;
  align-items: center;
  position: fixed;
  left: 0;
  z-index: 5;
  width: 100%;
  border-bottom: 1px solid #f8f8f8;
  box-sizing: border-box;
}

._3gra0 {
  height: 84px;
  background: #f6f6f6;
}

.icon {
  display: inline-block;
  width: 24px;
  height: 24px;
}

.icon-categories {
  background: url(https://hdn-1.fynd.com/company/884/applications/000000000000000000000001/theme/pictures/free/original/theme-image-1598078286712.png);
}

.icon-bag {
  background: url(https://hdn-1.fynd.com/company/884/applications/000000000000000000000001/theme/pictures/free/original/theme-image-1598077746481.png);
}

.icon-profile {
  background: url(https://hdn-1.fynd.com/company/884/applications/000000000000000000000001/theme/pictures/free/original/theme-image-1598078039542.png);
}

.icon-profile-active {
  background: url(https://hdn-1.fynd.com/company/884/applications/000000000000000000000001/theme/pictures/free/original/theme-image-1598079266707.png);
}

.mobile-account-popup {
  display: inline-block;
}

._3B-d0 {
  position: relative;
  text-align: left;
}

.cart-item {
  position: absolute;
  bottom: -3px;
  right: -3px;
  width: 15px;
  height: 15px;
  line-height: 15px;
  border-radius: 5px;
  font-size: 9px;
  text-align: center;
  padding: 1px;
  vertical-align: middle;
  background-color: #ee478d;
  color: #fff;
}

._1fuQY {
  position: absolute;
  top: -6px;
  right: 13px;
  width: 15px;
  height: 15px;
  line-height: 15px;
  font-size: 9px;
  text-align: center;
  padding: 2px;
  vertical-align: middle;
  background-color: #ee478d;
  color: #fff;
}

.searchbar-align {
  display: flex;
  align-items: center;
  width: 56%;
}

._1fuQY,
._3m0XQ {
  border-radius: 50%;
}
._3MsjQ {
  top: 0;
  background-color: #fff;
}
._2l50X,
._3MsjQ {
  position: fixed;
  left: 0;
  width: 100%;
}

._2i0eM {
  display: table;
  width: 100%;
  padding: 10px 10px 5px;
}

._216KH {
  margin-left: 11px;
  display: inline-block;
}

._1ReGX,
._2i0eM {
  height: 30px;
}

// ._1ReGX,
// ._2Ads9 {
//   width: 30px;
// }
.bigBtns,
a {
  outline: 0;
  cursor: pointer;
  text-decoration: none;
}
._2whBD,
.clipped,
.ellip,
a {
  white-space: nowrap;
}

._2Ads9 {
  text-align: left;
}

._1P1HH {
  float: right;
  width: 40%;
  padding-right: 10px;
  display: flex;
  align-items: center;
  justify-content: flex-end;
}

/* sub-header */

._2l50X {
  overflow: hidden;
  border-top: 1px solid #e6e6e6;
  margin-bottom: 3px;
  box-shadow: 0 1px 3px 0 rgba(65, 67, 76, 0.2);
  background: #fff;
  top: 49px;
  z-index: 2;
}
._1gxW9 {
  overflow-x: scroll;
  -webkit-overflow-scrolling: touch;
}
._1gxW9,
._1x2K0,
._3fYtk {
  white-space: nowrap;
}

._1ua7g,
._1x2K0 > * {
  display: inline-block;
}

.regular-xxs {
  font-size: 13px;
}
.regular-lg,
.regular-md,
.regular-sm,
.regular-xl,
.regular-xs,
.regular-xxl,
.regular-xxs,
.regular-xxxl,
.regular-xxxs,
.regular-xxxxs,
.regular-xxxxsp {
  font-weight: 400;
  -webkit-font-smoothing: antialiased;
}
._3Dmej {
  display: block;
  padding: 15px 5px;
  margin: 0 3px;
  text-decoration: none;
  text-transform: uppercase;
}
.clDarkGrey {
  color: #41434c;
}

#siteMenu ul {
  margin: 0;
  padding: 0;

  &::-webkit-scrollbar {
    height: 0;
  }
}
.desktop-header-container {
  height: 104px;
  .desktop-header {
    z-index: 10;
    width: 100%;
    background: #ffffff;
    top: 0;
    position: fixed;
    box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.12);
  }
}

@media (max-width: 1024px) {
  .desktop-header-container {
    display: none;
  }
  .mobile-header {
    display: block;
  }
}
</style>
