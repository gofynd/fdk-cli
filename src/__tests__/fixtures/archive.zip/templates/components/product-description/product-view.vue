<template>
  <div>
    <div class="flex-container">
      <div class="product-left">
         <fdk-extension v-if="getTemplates('above_image_component').length" :templates="getTemplates('above_image_component')" />
        <hcarousel
          :medias="getMedias"
          :product="product"
          v-on:paint-canvas="showPreview"
        ></hcarousel>
         <fdk-extension v-if="getTemplates('below_image_component').length" :templates="getTemplates('below_image_component')" />
      </div>
      <div class="product-right" ref="info">
        <fdk-extension v-if="getTemplates('above_product_info').length" :templates="getTemplates('above_product_info')" />
        <canvas width="360" height="360" ref="preview" class="preview"></canvas>
        <product-info
          :product="product"
          :product_meta="product_meta"
          :context="context"
          :page_config="page_config"
          :global_config="global_config"
        ></product-info>
           <fdk-extension v-if="getTemplates('below_product_info').length" :templates="getTemplates('below_product_info')" />
      </div>
    </div>
  </div>
</template>

<style lang="less" scoped>
.flex-container {
  display: flex;
  width: inherit;
  background-color: @White;
  padding-bottom: 14px;
  @media @mobile {
    flex-direction: column;
  }
}
.product-left {
  margin: 7px;
  width: 65%;
  @media @mobile {
    width: inherit !important;
  }
  /deep/.carousel {
    @media @mobile {
      width: inherit;
    }
    .btn {
      display: none;
    }
  }
}
.product-right {
  margin: 0px 16px;
  margin-right: 24px;
  position: relative;
  width: 35%;
  .preview {
    display: none;
    position: absolute;
    z-index: @layer;
    margin-top: 15px;
    width: 100%;
  }
  @media @mobile {
    width: inherit !important;
  }
}
.details-cont {
  background: @White;
  padding: 40px 20px;
  .title {
    font-size: 20px;
    font-weight: 700;
    margin: 20px 0 20px 0px;
    text-transform: uppercase;
    display: flex;
    justify-content: flex-start;
    color: #41434c;
  }
}
/deep/ .product-long-description {
  background: @White;
  padding: 0;
  line-height: 20px;
  font-size: 14px;
  h2 {
    font-size: 20px;
    font-weight: 700;
    margin: 10px 0 10px 0;
    text-transform: uppercase;
    color: #41434c;
  }
  b {
    font-weight: 700;
    margin-top: 25px;
    display: block;
  }
  br {
    content: "";
    display: block;
    margin-bottom: 10px;
  }
  p {
    margin-bottom: 10px;
    line-height: 20px;
    img {
      margin: 10px 0;
    }
  }
  video {
    max-width: 100% !important;
  }
}
</style>

<script>
import hcarousel from "./hcarousel.vue";
import productinfo from "./product-info.vue";

export default {
  name: "product_view",
  components: {
    hcarousel: hcarousel,
    "product-info": productinfo,
  },
  computed: {
    getMedias() {
      let images = [];
      if (this.product?.medias.length > 0) {
        return this.product.medias;
      } else {
        images.push({
          type: "image",
          url:
            "https://hdn-1.fynd.com/company/884/applications/000000000000000000000001/theme/pictures/free/original/theme-image-1623307821127.png",
        });
        return images;
      }
    },
  },
  props: {
    product: {
      type: Object,
    },
    product_meta: {
      type: Object,
    },
    context: {
      type: Object,
    },
    page_config: {
      type: Object,
    },
    global_config: {
      type: Object,
    },
  },
  data() {
    return {
      isPreviewVisible: false,
    };
  },
  methods: {
     getTemplates(position) {
      return this.page_config.props?.extension?.[position] || [];
    },
    topPosition(domElt) {
      if (!domElt) {
        return 0;
      }
      return domElt.offsetTop + this.topPosition(domElt.offsetParent);
    },
    setCanvasDimension() {
      let canvas = this.$refs["preview"];
      canvas.style.top = window.scrollY + "px";
    },

    showPreview(data) {
      let canvas = this.$refs["preview"];
      if (canvas) {
        if (data.show) {
          this.setCanvasDimension();
          canvas.style.display = "block";
        } else {
          canvas.style.display = "none";
          return;
        }

        let ctx = canvas.getContext("2d");
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        ctx.drawImage(
          data.image,
          (data.image.naturalWidth * data.gridRect.left) /
            data.imageInGrid.width,
          (data.image.naturalHeight * data.gridRect.top) /
            data.imageInGrid.height,
          (data.image.naturalWidth * data.gridRect.width) /
            data.imageInGrid.width,
          (data.image.naturalHeight * data.gridRect.height) /
            data.imageInGrid.height,
          0,
          0,
          canvas.width,
          canvas.height
        );
      }
    },
  },
};
</script>
