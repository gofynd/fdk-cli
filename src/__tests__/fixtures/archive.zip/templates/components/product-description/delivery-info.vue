<template>
  <fdk-pincode ref="pdpPincode">
    <template slot-scope="pincodeAction">
      <div class="delivery-info">
        <div class="delivery" v-if="getPincode()">
          <span class="darker-xs">Delivery to {{ getPincode() }}</span>
          <span>
            <a class="ukt-links" @click="addressModal = true"
              >&nbsp;Edit Pincode</a
            >
          </span>
        </div>
        <template
          v-if="
            storeInfo && deliveryInfo && deliveryInfo.minDeliveryDate && !error
          "
        >
          <div
            v-if="deliveryInfo.minDeliveryDate === deliveryInfo.maxDeliveryDate"
          >
            <div class="delivery-date light-xxs">
              Expected delivery on
              {{ deliveryInfo.minDeliveryDate }}
            </div>
          </div>
          <div v-else>
            <div class="delivery-date light-xxs">
              Expected delivery between
              {{ deliveryInfo.minDeliveryDate }}
              -
              {{ deliveryInfo.maxDeliveryDate }}
            </div>
          </div>
        </template>
      </div>
      <address-list-modal
        :isOpen="showUserPincodeModal || addressModal"
        :tatInfo="tatInfo"
        :isExplicitelySelectedStore="isExplicitelySelectedStore"
        :id="id"
        :context="context"
        @closedialog="onCloseDialog"
        @newPincodeReceived="onNewPincodeReceived"
        @showTatError="onTatError"
        @hideTatError="onHideTatError"
      ></address-list-modal>
    </template>
  </fdk-pincode>
</template>

<style lang="less" scoped>
.delivery {
  margin-bottom: 8px;
}
.delivery-info {
  margin-top: 14px;
  .ukt-links {
    .user-select-none();
  }
}
.delivery-date {
  color: @Mako;
}
</style>

<script>
import AddressList from "./address-list-modal.vue";
import {
  LocalStorageService,
  STORAGE_KEYS,
} from "./../../services/localstorage.service";
import isEmpty from "lodash/isEmpty";

export default {
  name: "delivery-info",
  props: {
    storeInfo: {},
    productName: "",
    level: "",
    id: null,
    showUserPincodeModal: "",
    isExplicitelySelectedStore: "",
    context: {},
  },
  watch: {
    storeInfo() {
      if (this.storeInfo) {
        this.fromPincode = `${this.storeInfo.pincode}`;
        this.toPincode = LocalStorageService.getItem(STORAGE_KEYS.USER_PINCODE);
        this.getTatInfo();
      }
    },
  },
  data() {
    return {
      toPincode: LocalStorageService.getItem(STORAGE_KEYS.USER_PINCODE) || "",
      fromPincode: "",
      addressModal: false,
      tatInfo: {},
      deliveryInfo: {},
      error: false,
      pincodeFunction: null,
    };
  },
  components: {
    "address-list-modal": AddressList,
  },
  mounted() {
    if (this.toPincode && this.toPincode.length > 0) {
      this.getTatInfo();
    }
  },
  methods: {
    onCloseDialog() {
      this.addressModal = false;
      this.$emit("dialogClosed");
    },
    getPincode() {
      if (this.toPincode) {
        return this.toPincode;
      }
      return LocalStorageService.getItem(STORAGE_KEYS.USER_PINCODE);
    },
    onTatError(err) {

      this.$emit("showTatError", err.message);
    },
    onHideTatError() {
      this.$emit("hideTatError");
    },
    onNewPincodeReceived(obj) {
      let newPincode = obj.pincode_value;
      this.pincodeFunction = obj.pincode_act;
      LocalStorageService.addOrUpdateItem(
        STORAGE_KEYS.USER_PINCODE,
        newPincode
      );
      this.$emit("pincodeChanged", newPincode);
    },

    getTatInfo() {
      if (this.storeInfo?.store?.uid && this.$refs["pdpPincode"]) {
        this.tatInfo = {
          toPincode: this.toPincode,
          fromPincode: `${this.storeInfo.pincode}`,
          categoryId: this.id,
          store_id: this.storeInfo.store.uid,
        };
        this.$refs["pdpPincode"]
          ?.getTat(this.tatInfo)
          .then((res) => {
            this.deliveryInfo = res;
          })
          .catch((err) => {
            this.$emit("showTatError", err.message);
          });
      }
    },
  },
};
</script>
