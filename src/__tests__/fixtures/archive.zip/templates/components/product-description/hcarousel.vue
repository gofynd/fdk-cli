<template>
  <carousel :items="getMedias">
    <div
      class="item-wrapper"
      ref="itemwrapper"
      v-on:mousemove="onmousemove"
      v-on:mouseover="onmouseover"
      v-on:mouseleave="onmouseleave"
    >
      <pic-zoom
        :class="['image-item', 'type-' + item.type]"
        :source="item.url"
        :type="item.type"
        v-for="(item, index) in getMedias"
        :product="product"
        v-on:clickimage="openGallery"
        @onVideoHover="onmouseleave"
        :key="index"
      ></pic-zoom>
      <div class="mouse-cover" ref="grid"></div>
      <div class="clearfix"></div>
    </div>
    <LightBox
      :medias="carouselmedias"
      ref="lightbox"
      :show-caption="true"
      :show-light-box="false"
    ></LightBox>
  </carousel>
</template>

<style lang="less" scoped>
.item-wrapper {
  position: relative;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
  @media @mobile {
    overflow: hidden;
    flex-wrap: nowrap;
    -ms-overflow-style: none;
    overflow-x: scroll;
    -webkit-overflow-scrolling: touch;
    transition: 1s linear;
    justify-content: normal;
  }
}
.image-item {
  margin: 7px;
  width: calc(50% - 14px);
  @media @mobile {
    width: 65%;
  }
  &.type-3d_model {
     /deep/ model-viewer {
      width: 100%;
      min-height: 300px;
      min-width: 320px;
      @media @tablet {
        min-width: 190px;
      }
      @media @mobile {
        min-width: 230px;
      }
    }
  }
}
/deep/.pdp-image {
  @media @mobile {
    min-width: 230px;
    max-width: 230px;
  }
}
.mouse-cover {
  position: fixed;
  width: 100px;
  height: 100px;
  background-color: rgba(0, 0, 0, 0.5);
  cursor: pointer;
  pointer-events: none;
  display: none;
}
</style>

<script>
import { animate, easeInOutQuad } from "./../../../helper/animate.js";
import carousel from "./carousel.vue";
import LightBox from "./lightbox-image.vue";
import { getImageURL, ORIGINAL } from "./../../../helper/image-utils.js";
import piczoom from "./pic-zoom.vue";
import { isBrowser } from "browser-or-node";

export default {
  name: "hcarousel",
  components: {
    "pic-zoom": piczoom,
    carousel: carousel,
    LightBox,
  },
  props: {
    medias: {
      type: Array,
    },
    product: {},
  },
  data() {
    return {};
  },
  computed: {
    getMedias() {
      return this.medias.map((it) => {
        it.url = it.url;
        return it;
      });
    },
    carouselmedias() {
      return this.medias.map((img) => {
        let originalImageURL = getImageURL(ORIGINAL, img.url);
        return {
          thumb: originalImageURL,
          src: originalImageURL,
          type: img.type,
        };
      });
    },
  },
  methods: {
    openGallery(index) {
      this.$refs.lightbox.showImage(Number(index));
    },

    onmouseover(event) {
      let elm = this.$refs["grid"];
      if (elm) {
        // event.currentTarget.addEventListener(
        //     'DOMMouseScroll',
        //     function(ev) {
        //         ev.preventDefault();
        //     },
        //     false
        // );
      }
    },
    onmousemove(event) {
      let gridElm = this.$refs["grid"];
      let imageElm = event.srcElement;
      let containerElm = this.$refs["itemwrapper"];

      if (gridElm && imageElm && imageElm instanceof HTMLImageElement  && imageElm.classList.contains('pdp-image')) {
        gridElm.style.display = "block";
        function offset(curEle) {
          var totalLeft = null,
            totalTop = null,
            par = curEle.offsetParent;
          totalLeft += curEle.offsetLeft;
          totalTop += curEle.offsetTop;
          while (par) {
            if (isBrowser && navigator.userAgent.indexOf("MSIE 8.0") === -1) {
              totalLeft += par.clientLeft;
              totalTop += par.clientTop;
            }
            totalLeft += par.offsetLeft;
            totalTop += par.offsetTop;
            par = par.offsetParent;
          }

          return {
            left: totalLeft,
            top: totalTop,
          };
        }

        function getXY(eve) {
          return {
            x: eve.clientX - gridElm.offsetWidth / 2,
            y: eve.clientY - gridElm.offsetHeight / 2,
          };
        }

        let pos = getXY(event);

        let imgwrap = offset(containerElm);

        let range = {
          minX: imgwrap.left,
          maxX: imgwrap.left + containerElm.offsetWidth - gridElm.offsetWidth,
          minY: imgwrap.top - document.documentElement.scrollTop,
          maxY:
            imgwrap.top -
            document.documentElement.scrollTop +
            containerElm.offsetHeight -
            gridElm.offsetHeight,
        };
        if (pos.x > range.maxX) {
          pos.x = range.maxX;
        }
        if (pos.x < range.minX) {
          pos.x = range.minX;
        }
        if (pos.y > range.maxY) {
          pos.y = range.maxY;
        }
        if (pos.y < range.minY) {
          pos.y = range.minY;
        }
        gridElm.style.left = pos.x + "px";
        gridElm.style.top = pos.y + "px";

        let gridRectInImage = {
          left:
            gridElm.getBoundingClientRect().x -
            imageElm.getBoundingClientRect().x,
          top:
            gridElm.getBoundingClientRect().y -
            imageElm.getBoundingClientRect().y,
          height: 100,
          width: 100,
        };

        this.$emit("paint-canvas", {
          image:
            imageElm.nextElementSibling instanceof HTMLImageElement &&
            imageElm.nextElementSibling["data-loaded"]
              ? imageElm.nextElementSibling
              : imageElm,
          imageInGrid: imageElm,
          gridRect: gridRectInImage,
          show: true,
        });
      }
    },
    onmouseleave(event) {
      let elm = this.$refs["grid"];
      if (elm) {
        elm.style.display = "none";
        this.$emit("paint-canvas", { show: false });
      }
    },
  },
};
</script>
