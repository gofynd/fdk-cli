<template>
  <div class="bread-crumb-container regular-xxs">
    <span v-for="(item, index) in tree" :key="index">
      <fdk-link :link="item.link">
        <span>{{ item.display }}</span>
        <fdk-inline-svg
          :src="'arrow-right-black'"
          v-if="index !== tree.length - 1"
        ></fdk-inline-svg>
      </fdk-link>
    </span>
  </div>
</template>

<style lang="less" scoped>
.bread-crumb-container {
  display: flex;
  align-items: center;
  padding: 10px 6px;
  font-size:12px !important;
  @media @mobile{
    padding: 5px;
  }
  a {
    display: flex;
    justify-content: center;
    align-items: center;
    span {
      color: @Mako;
    }
  }
}
</style>

<script>
export default {
  props: {
    tree: {
      type: Array,
      required: true,
    },
  },
  methods: {},
};
</script>
