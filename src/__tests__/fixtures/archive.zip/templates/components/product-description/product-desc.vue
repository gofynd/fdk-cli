<template>
  <div class="desc-container">
    <div
      class="pdp-section"
      v-for="(item, index) in product.grouped_attributes"
      :key="index"
    >
      <div class="ukt-title">{{ item.title }}</div>
      <div class="pdp-detail" v-if="item.details.length > 0">
        <div
          class="pdp-table"
          v-for="(property, val) in item.details"
          :key="val + index"
        >
          <div class="prop regular-xs" v-if="property.type !== 'paragraph'">
            {{ property.key }} :
          </div>
          <!-- <div class="val regular-xxs" v-if="property.type === 'text'">
            {{ property.value }}
          </div> -->
          <fdk-html-content class="val regular-xxs" :content="property.value">
          </fdk-html-content>
        </div>
      </div>
    </div>

    <div class="ukt-title">Return Policy</div>

    <div v-if="storeInfo !== null">
      <template
        v-if="storeInfo.return_config && storeInfo.return_config.returnable"
      >
        <div class="return">
          Returnable within {{ storeInfo.return_config.time }}
          {{ storeInfo.return_config.unit }}
        </div>
      </template>
      <template v-else>
        <div class="return">Item is not returnable</div>
      </template>
    </div>
    <fdk-link class="ukt-links" :link="returnLink" target="_blank"
      >View Details</fdk-link
    >
    <template v-if="storeInfo !== null && storeInfo.marketplace_attributes">
      <div
        class="pdp-section space-top"
        v-for="(item, index) in storeInfo.marketplace_attributes"
        :key="index + 'mr'"
      >
        <div class="ukt-title">{{ item.title }}</div>
        <div class="pdp-detail" v-if="item.details.length > 0">
          <div
            class="pdp-table"
            v-for="(property, val) in item.details"
            :key="val + index + 'mr'"
          >
            <div class="prop regular-xs" v-if="property.type !== 'paragraph'">
              {{ property.key }} :
            </div>
            <div class="val regular-xxs" v-if="property.type === 'text'">
              {{ property.value }}
            </div>

            <fdk-html-content
              class="val regular-xxs"
              v-if="property.type === 'html'"
              :content="property.value"
            ></fdk-html-content>
          </div>
        </div>
      </div>
    </template>
  </div>
</template>

<style lang="less" scoped>
.ukt-links {
  font-weight: 500;
}
.return {
  font-size: 14px;

  margin: 8px auto;
}
.space-top {
  padding-top: 20px;
}
.desc-container {
  width: inherit;
  margin: 14px 0px;
  margin-bottom: 0px;
  background: @White;
  border-radius: @BorderRadius;
  line-height: 20px;
  .section-text {
    margin: 10px 0px;
    color: @Mako;
  }

  .pdp-section {
    width: 100%;
    padding: 10px 0;
    @media @tablet {
      width: 100%;
    }

    .pdp-detail {
      display: table;
      width: 100%;
      margin: 0px 0 18px 0px;

      .pdp-table {
        width: 100%;
        position: relative;
        display: inherit;
        font-weight: 300;
        box-sizing: border-box;
        border-bottom: 1px solid #efefef;
        padding: 8px 0px;

        .prop {
          display: table-cell;
          width: 50%;
          padding: 0px;
          font-size: 14px;
          text-transform: capitalize;
        }
        .val {
          display: table-cell;
          width: 50%;
          padding: 3px;
          color: @Mako;
          font-size: 14px;
        }
      }
    }
  }
  // .pdp-section:last-child {
  //   .pdp-detail .pdp-table {
  //     border-bottom: none;
  //   }
  // }
}
</style>

<script>
export default {
  name: "product_desc",
  props: {
    product: {
      type: Object,
    },
    storeInfo: null,
    page_config: {
      type: Object,
    },
  },
  computed: {
    returnLink() {
      if (this.page_config?.props?.returnLink) {
        return this.page_config?.props?.returnLink;
      }
      return "/faq";
    },
  },
  methods: {
    getRouteLink() {
      this.$router.push({
        path: "/faq",
      });
    },
  },
};
</script>