<template>
  <div class="carousel">
    <div class="prev-btn btn" v-on:click="previousClicked">
      <fdk-inline-svg :src="'arrow-pdp-left'"></fdk-inline-svg>
    </div>
    <div class="item-wrapper" ref="itemwrapper">
      <slot></slot>
    </div>
    <div class="next-btn btn" v-on:click="nextClicked">
      <fdk-inline-svg :src="'arrow-pdp'"></fdk-inline-svg>
    </div>
  </div>
</template>

<style lang="less" scoped>
.carousel {
  width: 100%;
  position: relative;

  .btn {
    position: absolute;
    top: 50%;
    width: auto;
    z-index: @layer;
    transform: translate(0%, -50%);
    background-color: transparent;
    padding: unset;
    cursor: pointer;
    @media @mobile {
      display: none;
    }
  }
  .next-btn {
    right: 0px;
  }
  .prev-btn {
    left: 0px;
  }
}
</style>

<script>
import { animate, easeInOutQuad } from "./../../../helper/animate.js";
export default {
  name: "carousel",
  components: {},
  props: {
    items: {
      type: Array,
    },
  },
  methods: {
    previousClicked(event) {
      this.moveCarousel("LEFT");
    },
    nextClicked(event) {
      this.moveCarousel("RIGHT");
    },
    moveCarousel(direction) {
      let itemsLength = this.items.length;
      let totalWidth = this.$refs["itemwrapper"].scrollWidth;

      let singleItemScroll = totalWidth / itemsLength;
      let currentLeft = this.$refs["itemwrapper"].scrollLeft;
      let tobeScroll = singleItemScroll;
      switch (direction) {
        case "LEFT": {
          if (currentLeft - singleItemScroll < 0) {
            tobeScroll = currentLeft;
          }
          this.sideScroll(-tobeScroll);
          break;
        }
        case "RIGHT": {
          if (currentLeft + singleItemScroll > totalWidth) {
            tobeScroll = totalWidth - currentLeft;
          }
          this.sideScroll(tobeScroll);
          break;
        }
      }
    },
    sideScroll(rangeInPixels) {
      let element = this.$refs["itemwrapper"];

      if (element) {
        var sequenceObj = {};
        var seconds = 0.8;
        var startingScrollPosition = element.scrollLeft;
        sequenceObj.progress = (percentage) => {
          element.scroll(
            startingScrollPosition + easeInOutQuad(percentage) * rangeInPixels,
            0
          );
        };
        animate(sequenceObj, seconds);
      }
    },
  },
  mounted() {},
};
</script>
