<template>
  <div>
    <div>
      <div class="product-info spaces">
        <div
          class="mark-fav"
          v-if="page_config && page_config.props && page_config.props.wishlist"
        >
          <no-ssr>
            <favourite :item="product"></favourite>
          </no-ssr>
        </div>
        <fdk-share
          v-click-outside="hideShare"
          v-if="page_config && page_config.props && page_config.props.share"
        >
          <template slot-scope="share">
            <div class="share-button" @click="getShareLink(share)">
              <fdk-inline-svg :src="'share'" class="share-img"></fdk-inline-svg>
              <transition name="fade">
                <share
                  :title="
                    `Spread the shopping delight! Scan QR & share this ${context.product.brand.name} product with
                          your loved ones`
                  "
                  :shareLoading="shareLoading"
                  :qr_code="qr_code"
                  @close-share="showShare = false"
                  v-if="showShare"
                  :share_link="share_link"
                />
              </transition>
            </div>
          </template>
        </fdk-share>
        <div>
          <fdk-link :action="getBrandlink" class="brand">
            <whitesplash-image
              :src="product.brand.logo && product.brand.logo.url"
              :sources="[{ width: 50 }]"
            />
          </fdk-link>
        </div>
        <div class="price">
          <div class="ukt-title">{{ product.brand.name }}</div>
          <rating
            v-if="
              product.rating &&
                page_config &&
                page_config.props &&
                page_config.props.rating
            "
            :rating="product.rating"
          ></rating>
          <div class="info regular-xs">{{ product.name }}</div>
          <div>
            <span
              class="effective-price regular-xxs"
              style="padding-right: 10px;"
              >{{ getProductPrice("effective") | currencyformat }}</span
            >
            <span
              class="marked-price regular-xxs"
              style="padding-right: 10px;"
              v-if="getProductPrice('effective') !== getProductPrice('marked')"
              >{{ getProductPrice("marked") | currencyformat }}</span
            >
            <span class="discount regular-xxxs">{{ getProductDiscount }}</span>
          </div>
           <fdk-extension v-if="getTemplates('below_price_component').length" :templates="getTemplates('below_price_component')" />
        </div>
      </div>


      <fdk-compare-action
        v-if="
          page_config && page_config.props && page_config.props.add_to_compare
        "
      >
        <template slot-scope="compare">
          <div
            class="compare-container compare-text ukt-links"
            @click="addCompareProducts(compare.addCompare, product.slug)"
          >
            <div class="compare-icon">
              <img src="./../../../assets/images/compare-icon.png" alt />
            </div>
            <p>Add to Compare</p>
          </div>
        </template>
      </fdk-compare-action>

      <promo-meta
        v-if="product.promo_meta && product.promo_meta.message && false"
        :promo_meta="product.promo_meta"
      ></promo-meta>
      <store-coupon
        :bulkPrices="context.bulk_prices"
        v-if="
          !context.bulk_prices.loading &&
            page_config &&
            page_config.props &&
            page_config.props.bulk_prices
        "
      ></store-coupon>
      <!-- Product Variant -->
      <product-variants
        class="spaces"
        v-if="
          context.product_variants &&
          context.product_variants.variants &&
          context.product_variants.variants.variants &&
            page_config &&
            page_config.props &&
            page_config.props.variants
        "
        :product="context.product"
        :variants="context.product_variants.variants.variants"
      ></product-variants>
      <!-- Size and Store List Section -->
      <fdk-pdp-size-stores ref="pdpSizeStores" class="product-size">
        <template slot-scope="sellerData">
          <size-guide-link
            :product="product"
            :product_meta="product_meta"
            :page_config="page_config"
          ></size-guide-link>
          <div class="sizes">
            <div
              class="item"
              tabindex="0"
              v-for="(item, index) in product_meta.sizes"
              :key="'p-size-' + index"
              :class="{
                sizeselected: selectedSize === item.display,
                inactive: !item.is_available,
              }"
              @click="
                selectedSize = item.display;
                onSizeClicked(sellerData);
                showMessage = false;
              "
            >
              {{ item.display }}
            </div>
          </div>
          <div
            class="spacing regular-xxs"
            v-if="
              isProductRequestEnabled &&
                page_config &&
                page_config.props &&
                page_config.props.product_request
            "
          >
            Couldn't find your size?
            <a class="ukt-links" @click="showProductRequestModal = true"
              >Product Request</a
            >
          </div>
          <div v-bind:class="[{ 'show-message': showMessage }, 'message']">
            <span class="error-msg regular-xxs">{{ message }}</span>
          </div>
          <div
            class="seller-info"
            v-if="
              showSoldByModal &&
                storeInfoSelected &&
                storeInfoSelected.store &&
                storeInfoSelected.store.name
            "
          >
            <div class="seller-name regular-xxs"
              v-if="showSellers">
              <div class="store-seller">
                Sold By:
                {{ storeInfoSelected.store.name + "," }}
                {{ storeInfoSelected.seller.name }}
                <span
                  class="ukt-links bold-xs"
                  v-if="
                    store_count > 1 &&
                      page_config &&
                      page_config.props &&
                      page_config.props.store_selection
                  "
                  @click="
                    showStoreModal = true;
                    loadStoreFunction = sellerData.loadStores;
                    getStores(sellerData.loadStores);
                  "
                >
                  & {{ store_count - 1 }} Others</span
                >
              </div>

              <store-modal
                :isOpen="showStoreModal"
                :activeStoreInfo="storeInfo"
                :all_stores_info="all_stores_info"
                :productName="product.name"
                :sellerData="sellerData"
                v-on:closedialog="showStoreModal = false"
                v-on:store-filter="updateStoreFilter"
                v-on:store-item-select="setStoreInfo"
              ></store-modal>
            </div>
          </div>
        </template>
      </fdk-pdp-size-stores>
      <!-- Product Request -->
      <product-request-modal
        :isOpen="showProductRequestModal"
        :productInfo="product"
        :isPdpPage="true"
        v-on:closedialog="showProductRequestModal = false"
      ></product-request-modal>
      <!-- Size Set Info -->
      <size-set-info v-if="isSizeSet" :storeInfo="storeInfo"></size-set-info>
      <fdk-extension v-if="getTemplates('below_size_component').length" :templates="getTemplates('below_size_component')" />
      <!-- Cart Button -->
      <fdk-cart>
        <template slot-scope="cart">
          <button
            class="secondary-btn btn bold-sm"
            v-if="product_meta.sellable && !global_config.props.disable_cart"
            :disabled="isButtonDisabled"
            @click="addToCart(cart)"
          >
            <fdk-inline-svg
              v-if="loadSpinner"
              class="spinner"
              :src="'button-spinner'"
            ></fdk-inline-svg>
            <span v-if="!loadSpinner">{{ buyText }}</span>
          </button>
        </template>
         <fdk-extension v-if="getTemplates('below_add_to_cart').length" :templates="getTemplates('below_add_to_cart')" />
      </fdk-cart>
        <fdk-notify
        v-if="
          product_meta &&
            product_meta.hasOwnProperty('sellable') &&
            !product_meta.sellable &&
            !global_config.props.disable_cart
        "
      >
        <template slot-scope="notifyProduct">
          <button
            class="secondary-btn btn bold-sm notify-btn"
            @click="productNotify(notifyProduct)"
          >
            <img src="../../../assets/images/bell.png" alt="" />
            <span>Notify Me</span>
          </button>
        </template>
      </fdk-notify>

      <!--Mini Cart-->
      <div v-if="processBagItems.length > 0" class="cart-group spaces">
        <div class="ukt-title lower-case">Edit Quantity</div>
        <div class="cart-group-items spaces">
          <transition-group name="slide-fade" mode="out-in">
            <div
              class="spaces"
              v-for="bagGroups in processBagItems"
              :key="'soldby_' + bagGroups.soldby"
            >
              <div class="soldby regular-xxs" v-if="showSellers">
                Sold By: {{ bagGroups.soldby }}
              </div>
              <transition-group name="slide-fade" mode="out-in" tag="div">
                <chip-item
                  v-for="(item, index) in bagGroups.items"
                  :key="index"
                  :item="item"
                  :chiptype="'pdp'"
                  @remove-cart="removeCart"
                  @update-cart="updateCart"
                ></chip-item>
              </transition-group>
            </div>
          </transition-group>
        </div>
        <fdk-link :link="'/cart/bag'">
          <button class="common-btn btn bold-sm">
            View Items in Bag
          </button>
        </fdk-link>
      </div>

      <!--Delivery Info-->
      <no-ssr>
        <delivery-info
          v-if="showUserPincodeModal || storeInfo"
          :showUserPincodeModal="showUserPincodeModal"
          :isExplicitelySelectedStore="isExplicitelySelectedStore"
          :storeInfo="storeInfo"
          :productName="product.product_name"
          level="l3"
          :id="getCategoryId"
          @dialogClosed="onDialogClosed"
          @pincodeChanged="onPincodeChanged($event)"
          @showTatError="onTatError($event)"
          @hideTatError="onHideTatError"
        ></delivery-info>
      </no-ssr>

      <compare-action-modal
        v-if="showCompareActionModal"
        :compare_slugs="context.compare_slugs"
        :compare_msg="compareMsg"
        :product_uid="context.product.slug"
        @hide-compare-action-modal="hideCompareModal"
      ></compare-action-modal>
      <!-- Product Description -->
      <product-desc :product="product" :storeInfo="storeInfo" :page_config="page_config"></product-desc>
    </div>
    <toast :id="'toast-message'" :content="toast_message"></toast>
  </div>
</template>

<style lang="less" scoped>
.notify-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  img {
    margin-right: 10px;
  }
}

.compare-container {
  display: flex;
  align-items: center;
  margin-bottom: 20px;
  height: 100%;
  justify-content: left;
  font-size: 14px;
  cursor: pointer;
  .compare-icon {
    padding: 0 5px;
    img {
      width: 18px;
    }
  }
}
.ukt-title {
  text-transform: uppercase;
}
.lower-case {
  text-transform: none;
}
/deep/ .ukt-links {
  font-weight: 500;
  .font-size(@font-xxs);
}
.spaces {
  margin: 14px 0px;
}
.spacing {
  padding: 4px 0px 20px 0px;
}
.soldby {
  color: @Mako;
  margin: 14px 0px;
  line-height: 20px;
}
.message {
  display: none;
  color: @Required;
  padding: 0px 0px 5px;
}
.show-message {
  display: flex;
  padding: 5px 0;
  height: 10px;
}
.error-msg {
  padding: 5px 0;
  display: flex;
  align-items: center;
}
.spinner {
  display: block;
  height: 25px;
  width: 10px;
  text-align: center;
  width: 100%;
}
.btn {
  border-radius: @BorderRadius;
  cursor: pointer;
  height: 50px;
  width: 100%;
  border: none;
  text-transform: uppercase;
  margin-bottom: 18px;
}
.product-info {
  display: flex;
  position: relative;
  .brand {
    display: block;
    /deep/ .fy__img {
      width: 50px;
      border-radius: @BorderRadius;
    }
  }
  .price {
    margin-left: 15px;
    padding-right: 25px;
    .info {
      line-height: 20px;
      margin: 2px 0px;
    }
    .discount {
      color: @Required;
    }
    .rating {
      margin: 5px 0 10px 0;
    }
  }
  .mark-fav {
    cursor: pointer;
    position: absolute;
    top: 35px;
    right: 0;
  }
  .share-button {
    position: absolute;
    right: 0;
    top: 0px;
    cursor: pointer;
    .share-img {
      position: relative;
    }
  }
}
.product-size {
  .sizes {
    margin: 10px 0px 5px 0px;
    display: flex;
    flex-wrap: wrap;
    &::-webkit-scrollbar {
      display: none;
    }
    .item {
      cursor: pointer;
      border: 1px solid @Mako;
      border-radius: 3px;
      text-align: center;
      margin: 0 7px 4px 0;
      padding: 9px 11px;
      color: @Mako;
      min-width: 20px;
      .user-select-none();
    }
    .sizeselected {
      background: @PrimaryColor;
      border: 1px solid @PrimaryColor;
      color: @White;
      box-sizing: content-box;
    }
    .inactive {
      opacity: 0.4;
      cursor: auto;
      pointer-events: none;
    }
  }
}
.seller-info {
  margin-bottom: 5px;
  line-height: 20px;
  .seller-name {
    color: #41434c;
    padding: 5px 0;
    .store-seller {
      text-overflow: ellipsis;
      overflow: hidden;
    }
  }
}
</style>

<script>
import promometa from "./promo-meta.vue";
import productVariants from "./product-variants.vue";
import productdesc from "./product-desc.vue";
import Favourite from "./favourite.vue";
import Rating from "./../../../global/components/fy-rating.vue";
import root from "window-or-global";
import {
  LocalStorageService,
  STORAGE_KEYS,
} from "./../../services/localstorage.service";
import storemodal from "./store/store-modal.vue";
import { copyToClipboard } from "./../../../helper/utils";
import productRequestModal from "./../product-description/product-request/product-request-modal.vue";
import sizeGuideLink from "./size/size-guide-link.vue";
import toast from "./../../../global/components/toast.vue";
import deliveryInfo from "./delivery-info.vue";
import sizeSetInfo from "./size/size-set-info.vue";
import storeCoupon from "./store/coupon.vue";
import share from "./../../../global/components/share.vue";
import compareActionModalVue from "./../../../global/components/compare-action-modal.vue";
import chipItem from "./../../../global/components/cart/cart-chip-item.vue";
import fyImage from "../../../global/components/common/whitesplash-image.vue";
import NoSSR from "vue-no-ssr";
import isEqual from 'lodash/isEqual';

export default {
  name: "product-info",
  components: {
    "product-variants": productVariants,
    "product-desc": productdesc,
    "promo-meta": promometa,
    "store-modal": storemodal,
    "product-request-modal": productRequestModal,
    "compare-action-modal": compareActionModalVue,
    "size-guide-link": sizeGuideLink,
    "delivery-info": deliveryInfo,
    "size-set-info": sizeSetInfo,
    "store-coupon": storeCoupon,
    "chip-item": chipItem,
    "whitesplash-image": fyImage,
    favourite: Favourite,
    rating: Rating,
    toast,
    share,
    "no-ssr": NoSSR,
  },
  props: {
    product: {
      type: Object,
    },
    product_meta: {
      type: Object,
    },
    context: {
      type: Object,
    },
    page_config: {
      type: Object,
    },
    global_config: {
      type: Object,
    },
  },
  mounted() {
    this.isMounted = true;
    this.message = "";
    if (this.checkNoSizesAvailable()) {
      this.message = "No sizes available. Product Out of Stock";
      this.isAddToCart = false;
    }
  },
  watch: {
    storeInfo() {
      this.storeInfoSelected = Object.assign(
        {},
        this.storeInfoSelected,
        this.storeInfo
      );
    },
    context(newValue, oldValue) {
      if (!isEqual(newValue,oldValue)) {
          this.context = newValue;
        if (newValue.product.uid !== oldValue.product.uid || !this.selectedSize ) {
          this.preSizeSelect();
        }
      }
    },
    loadStoreFunction(newValue) {
      this.loadStoreFunction = newValue;
    },
    loadSellerFunction(newValue) {
      this.loadSellerFunction = newValue;
    },
    pincode(newValue) {
      this.pincode = newValue;
    },
    $route(to, from) {
      if (to.path != from.path) {
        (this.buyText = "Add To Bag"),
          (this.loadSpinner = false),
          (this.message = ""),
          (this.showMessage = false),
          (this.showUserPincodeModal = false),
          (this.isExplicitelySelectedStore = false),
          (this.selectedSize = ""),
          (this.storeInfoSelected = {}),
          (this.storeInfo = null),
          (this.isAddToCart = true);
      }
    },
  },
  data() {
    return {
      compareMsg: {
        title: "",
      },
      shareLoading: false,
      showShare: false,
      share_link: "",
      qr_code: "",
      buyText: "Add To Bag",
      showMoreProductDetails: false,
      showShippingDetails: false,
      selectedSize: "",
      isMounted: false,
      showSizeGuide: false,
      showStoreModal: false,
      pincodeError: false,
      pincodeSuccess: false,
      pincode: LocalStorageService.getItem(STORAGE_KEYS.USER_PINCODE) || "",
      showSoldByModal: false,
      all_stores_info: null,
      storeCompanyFilter: null,
      storeInfo: null,
      storeInfoSelected: {},
      loadStoreFunction: null,
      loadSellerFunction: null,
      toast_message: "",
      showProductRequestModal: false,
      loadSpinner: false,
      message: "",
      showMessage: false,
      isAddToCart: true,
      showUserPincodeModal: false,
      isExplicitelySelectedStore: false,
      showCompareActionModal: false,
      notifMsg: "Saved, We'll notify you when this product is back in Stock",
      store_count: null,
    };
  },
  computed: {
    showSellers(){
      return this.page_config?.props?.show_sellers
    },
    isSizeSet() {
      return this.storeInfo && this.storeInfo.is_set;
    },
    getCategoryId() {
      if (this.product.categories && this.product.categories.length) {
        return this.product.categories[0].id;
      }
      return "";
    },
    getBrandlink() {
      return this.product.brand.action;
    },
    getProductDiscount() {
      return this.storeInfo
        ? this.storeInfo.discount
        : this.product_meta.discount;
    },
    isProductRequestEnabled() {
      if (
        this.isMounted &&
        this.context.is_logged_in &&
        this.context.app_features &&
        this.context.app_features.feature &&
        this.context.app_features.feature.product_detail &&
        this.context.app_features.feature.product_detail.request_product
      ) {
        return true;
      }
      return false;
    },
    isButtonDisabled() {
      if (this.checkNoSizesAvailable() || this.showMessage) {
        return true;
      }
      return false;
    },
    processBagItems() {
      if (this.context.bag_data && Array.isArray(this.context.bag_data.items)) {
        let arrBags = this.context.bag_data.items.map((item, index) => {
          item.item_index = index;
          return item;
        });
        arrBags = arrBags.filter(
          (item) => item.product.uid === this.product.uid
        );

        let grpBySoldBy = arrBags.reduce((result, item) => {
          result["" + item.article.seller.uid + item.article.store.uid] = (
            result["" + item.article.seller.uid + item.article.store.uid] || []
          ).concat(item);
          return result;
        }, []);

        let updateArr = [];
        for (let key in grpBySoldBy) {
          updateArr.push({
            soldby:
              grpBySoldBy[key][0].article.store.name +
              " ," +
              grpBySoldBy[key][0].article.seller.name,
            items: grpBySoldBy[key],
          });
        }
        return updateArr;
      }
      return [];
    },
  },
  methods: {
     getTemplates(position) {
      return this.page_config.props?.extension?.[position] || [];
    },
    productNotify(notifyProduct) {
      let payload = {
        id: this.context.product.uid,
      };
      notifyProduct.notify(payload);
      this.$toasted.success(this.notifMsg, {
        position: "bottom-center",
        duration: 2000,
      });
    },
    preSizeSelect() {
      if (
        this.context?.product_meta?.sizes?.length === 1 &&
        this.context.product_meta.sizes[0]?.is_available
      ) {
        if (LocalStorageService.getItem(STORAGE_KEYS.USER_PINCODE)) {
          this.selectedSize = this.context.product_meta.sizes[0]?.display;
          this.sizeClicked(this.$refs?.pdpSizeStores?.loadSellers);
        }
        this.sizeError = false;
      }
    },
    hideShare() {
      this.showShare = false;
    },
    onPincodeChanged(event) {
      this.pincode = event;
      this.sizeClicked(this.loadSellerFunction);
    },
    addCompareProducts(promiseFn, productUid) {
      if (this.context.compare_slugs.length < 3) {
        promiseFn(productUid)
          .then((res) => {
            //todo
          })
          .catch((err) => {
            this.compareMsg.title = err.message || "Something went wrong";
            this.showCompareActionModal = true;
          });
      } else {
        this.compareMsg.title = "You can only compare 3 products at a time";
        this.showCompareActionModal = true;
      }
    },
    hideCompareModal() {
      this.showCompareActionModal = false;
      this.compareMsg.title = "";
    },
    onDialogClosed() {
      this.showUserPincodeModal = false;
      if (
        LocalStorageService.getItem(STORAGE_KEYS.USER_PINCODE) &&
        this.selectedSize
      ) {
        this.sizeClicked(this.loadSellerFunction);
      } else if (!LocalStorageService.getItem(STORAGE_KEYS.USER_PINCODE)) {
        this.selectedSize = "";
      }
    },
    onTatError(err) {
      this.message = err;
      this.showMessage = true;
    },
    onHideTatError() {
      this.message = "";
      this.showMessage = false;
    },
    getShareLink(share) {
      this.shareLoading = true;
      this.showShare = true;
      share.getShareLink(window.location.href).then((res) => {
        share.generateQRCode(res).then((data) => {
          this.qr_code = `
                <div style="width: 250px;">
                  ${data.svg}
                </div>
                `;
          this.share_link = res;
          this.shareLoading = false;
        });
      });
    },
    onSizeClicked(sellerData) {
      this.isExplicitelySelectedStore = false;
      this.loadSellerFunction = sellerData.loadSellers;
      if (!LocalStorageService.getItem(STORAGE_KEYS.USER_PINCODE)) {
        this.showUserPincodeModal = true;
      } else {
        this.sizeClicked(sellerData.loadSellers);
      }
    },
    copyToClipboard(data) {
      copyToClipboard(data);
      this.$toasted.global.showToaster("Link Copied to Clipboard", 1000);
    },
    getProductPrice(key) {
      if (this.storeInfo && this.storeInfo.price) {
        const { is_set } = this.storeInfo;
        if (is_set) {
          return this.storeInfo.price_per_piece[key];
        }
        return this.storeInfo.price[key];
      }
      if (this.product_meta.price) {
        return this.product_meta.price[key].min !==
          this.product_meta.price[key].max
          ? this.$options.filters.currencyformat(
              this.product_meta.price[key].min
            ) +
              "-" +
              this.$options.filters.currencyformat(
                this.product_meta.price[key].max
              )
          : this.product_meta.price[key].max;
      }
    },
    updateStoreFilter(filtertype) {
      this.storeCompanyFilter = filtertype;
      this.getStores(this.loadStoreFunction);
    },
    setStoreInfo(store) {
      this.storeInfoSelected = Object.assign({}, this.storeInfoSelected, store);
      this.storeInfo = this.storeInfoSelected;
      this.showStoreModal = false;
      this.isExplicitelySelectedStore = true;
    },
    checkPincode(validatePincode) {
      validatePincode(this.pincode)
        .then((valid) => {
          this.pincodeError = !valid;
          this.pincodeSuccess = true;
          if (this.selectedSize && valid) {
            this.sizeClicked(this.loadSellerFunction);
          }
        })
        .catch((err) => {
          this.pincodeSuccess = false;
          this.pincodeError = true;
        });
    },
    sizeClicked(loadSellers) {
      let options = {
        size: this.selectedSize,
        slug: this.product.slug,
        pincode: this.pincode,
      };
      this.loadSellerFunction = loadSellers;
      this.loadSpinner = true;
      loadSellers(options)
        .then((res) => {
          this.storeInfo = res;
          this.store_count = res?.store?.count || null;
          this.showSoldByModal = true;
          this.loadSpinner = false;
        })
        .catch((err) => {
          console.log(err);
        });
    },
    getStores(loadStores) {
      let options = {
        strategy: this.storeCompanyFilter || "",
        page: 1,
      };
      loadStores(options)
        .then((res) => {
          this.all_stores_info = res;
        })
        .catch((err) => {
          console.log(err);
        });
    },
    checkNoSizesAvailable() {
      if (this.product_meta.sizes && this.product_meta.sizes.length == 0) {
        return true;
      } else if (this.product_meta.sizes?.length > 0) {
        let bAvail = false;
        for (let i = 0; i < this.product_meta.sizes.length; i++) {
          bAvail = bAvail || this.product_meta.sizes[i].is_available;
        }
        return !bAvail;
      }
      return false;
    },
    checkValidBuy() {
      if (this.checkNoSizesAvailable()) {
        this.message = "No sizes available. Product Out of Stock";
        this.showMessage = true;
        return false;
      } else if (!this.selectedSize) {
        this.message = "Please select size";
        this.showMessage = true;
        return false;
      }
      return true;
    },

    addToCart(cart) {
      if (this.checkValidBuy()) {
        this.loadSpinner = true;
        this.showMessage = false;
        this.message = "";
        let { article_assignment, seller, store } = this.storeInfo;
        let orderData = {
          items: [
            {
              item_id: this.product.uid,
              item_size: this.selectedSize,
              quantity: 1,
              article_assignment: article_assignment,
              seller_id: seller.uid,
              store_id: store.uid,
            },
          ],
        };
        cart
          .addToCart(orderData)
          .then((data) => {
            if (data.success) {
              this.showToast(data.message);
            } else {
              this.showToast(data.message || "Something went wrong");
            }
          })
          .catch((err) => {
            this.showToast(err.message);
          })
          .finally(() => {
            this.loadSpinner = false;
          });
      }
    },
    updateCart(params) {
      this.loadSpinner = true;
      let item = this.context.bag_data.items[params.item.item_index];
      if (params.operation === "inc") item.quantity++;
      else if (params.operation === "dec") item.quantity--;
      else if (params.operation === "del") item.quantity = 0;
      else if (params.operation === "qty") item.quantity = params.item.quantity;

      if (item.quantity <= 0) {
        item.quantity = 0;
      }
      params
        .func([item])
        .then(({ data }) => {
          this.loadSpinner = false;
        })
        .catch((err) => {
          console.log(err);
          this.loadSpinner = false;
        });
    },
    removeCart(params) {
      this.isLoading = true;
      let item = this.context.bag_data.items[params.item.item_index];
      params
        .func([item])
        .then(({ data }) => {
          this.isLoading = false;
        })
        .catch((err) => {
          console.log(err);
          this.isLoading = false;
        });
    },
    showToast(message) {
      if (message) {
        this.toast_message = message;
      }
      var x = document.getElementById("toast-message");
      x.className = "toast show";
      setTimeout(function() {
        x.className = x.className.replace("toast show", "toast hide");
      }, 3000);
    },
  },
};
</script>
