<template>
  <div>
    <div class="bold-xs">OFFERS</div>
    <div class="promo_meta">{{ promo_meta.message }}</div>
  </div>
</template>

<script>
export default {
  name: "promo-meta",
  props: {
    promo_meta: {},
  },
};
</script>

<style lang="less" scoped>
.promo_meta {
  border: 1px dashed #6b6b6b;
  margin-bottom: 15px;
  margin-top: 5px;
  padding: 10px;
}
</style>
