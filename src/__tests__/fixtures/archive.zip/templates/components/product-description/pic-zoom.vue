<template>
  <div>
    <div v-if="type === 'image'" class="load-image">
      <img
        slot="image"
        :src="getPDPImageURL"
        class="pdp-image"
        :style="{ backgroundColor: getProductColor }"
        :class="{ bgopacity: !imageFullyLoaded }"
        @mouseover="onMouseOver"
        @click="openGallery"
        @load="OriginalImageLoaded"
      />
      <img
        class="img-loader"
        v-show="isLoading"
        src="../../../assets/images/loader.gif"
      />
    </div>
    <div
      v-if="type === 'video'"
      class="video-container"
      @mouseover="mouseover"
      @click="openGallery"
    >
      <video
        v-if="!source.includes('youtube')"
        class="originalVideo"
        :src="source"
        data-loaded="false"
      ></video>
      <img
        v-else
        class="youtube"
        :src="getYoutubeImageURL(source)"
        allowfullscreen
      />
      <div class="thumbnail"></div>
    </div>
    <div v-if="type === '3d_model' && isMounted" class="type-3d_model">
      <no-ssr>
        <viewer-3d :src="getOriginalImage()" prompt="none"></viewer-3d>
      </no-ssr>
      <div class="overlay-icon" @click="openGallery">
        <img src="../../../assets/images/3D.svg" />
      </div>
    </div>
  </div>
</template>

<script>
import { getImageURL, ORIGINAL } from "./../../../helper/image-utils.js";
import { isBrowser, isNode } from "browser-or-node";
import NoSSR from "vue-no-ssr";
const PLACEHOLDER_SRC =
  "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANsAAAFWAQMAAADaFHqxAAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAACBJREFUaN7twTEBAAAAwqD1T20LL6AAAAAAAAAAAADgbSa+AAGGhRJaAAAAAElFTkSuQmCC";

export default {
  name: "piczoom",
  props: {
    source: {
      type: String,
      required: true,
    },
    type: {
      type: String,
    },
    product: {},
  },
  components: {
    "no-ssr": NoSSR,
    "viewer-3d": () =>
      isNode ? Promise.resolve(null) : Promise.resolve(require("./viewer-3d")),
  },
  data() {
    return {
      isLoading: false,
      imageFullyLoaded: true,
      imageLoading: false,
      isMounted: false,
    };
  },
  mounted() {
    this.loader = true;
    this.isMounted = true;
  },
  watch: {
    source(newValue, oldValue) {
      if (newValue !== oldValue) {
        this.isLoading = true;
      }
    },
  },
  computed: {
    getProductColor() {
      if (!this.imageFullyLoaded) {
        return this.product.attributes
          ? "#" + this.product.attributes.primary_color_hex
          : "";
      }
      return "";
    },
    getPDPImageURL() {
      if (this.imageFullyLoaded || !isBrowser) {
        return this.source.replace("resize-w:540", "original");
      }
      if (this.source && !this.imageLoading) {
        this.imageFullyLoaded = false;
        let img = new Image();
        img.src = this.source;
        img.onload = this.imageLoaded.bind(this);
        this.imageLoading = true;
      }
      return PLACEHOLDER_SRC;
    },
  },
  methods: {
    imageLoaded(event) {
      this.imageFullyLoaded = true;
      this.isLoading = false;
    },
    getYoutubeImageURL(src){
      return `http://img.youtube.com/vi/${src?.substr(src?.lastIndexOf("/")+1)}/0.jpg`
    },
    getOriginalImage() {
      return this.source.replace("resize-w:540", "original");
    },
    openGallery() {
      this.$emit("clickimage", this.$vnode.key);
    },
    onMouseOver() {
      let originalElm = this.$refs["original_" + this.$vnode.key];
      if (originalElm) {
        originalElm.src = this.getOriginalImage(this.source);
      }
    },
    OriginalImageLoaded(event) {
      let originalElm = this.$refs["original_" + this.$vnode.key];
      if (originalElm) {
        originalElm["data-loaded"] = true;
      }
      this.isLoading = false;
    },
    mouseover() {
      this.$emit("onVideoHover");
    },
  },
};
</script>

<style lang="less" scoped>
.load-image {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  .img-loader {
    position: absolute;
  }
}
.bgopacity {
  opacity: 0.5;
}
.pdp-image {
  width: 100%;
  background-image: linear-gradient(
    to bottom,
    rgba(0, 0, 0, 0.14),
    rgba(0, 0, 0, 0.2)
  );
}
.originalImg {
  left: 0;
  position: absolute;
  top: 0;
  opacity: 0;
  pointer-events: none;
  visibility: hidden;
  max-width: 720px;
}
.video-container {
  position: relative;
  cursor: pointer;
  .originalVideo {
    width: 100%;
    height: 430px;
    cursor: pointer;
    @media @mobile {
      min-width: 230px;
      max-width: 230px;
      height: auto;
    }
  }
  .youtube{
    width: 100%;
    height: auto;
    cursor: pointer;
    @media @mobile {
      min-width: 230px;
    }
  }

  .thumbnail {
    &::after {
      background-image: url(../../../assets/images/play-button.svg);
      width: 60px;
      background-size: contain;
      content: "";
      display: block;
      height: 60px;
      position: absolute;
      background-repeat: no-repeat;
      top: 50%;
      left: 50%;
      margin-left: -30px;
      margin-top: -30px;
    }
  }
}
.type-3d_model {
  position: relative;
  .overlay-icon {
    cursor: pointer;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.6);
    display: flex;
    align-items: center;
    justify-content: center;
    img {
      width: 24px;
    }
  }
}
</style>
