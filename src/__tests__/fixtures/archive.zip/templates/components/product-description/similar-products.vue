<template>
  <div>
    <div
      v-for="(items, index) in similars"
      :key="index"
      class="similiar-container"
    >
      <div class="similiar-title bold-lg">{{ items.title }}</div>
      <div class="similiar-desc regular-xxs">
        {{ items.subtitle }}
      </div>
      <carousel :items="items.items">
        <div class="item" v-for="(item, index) in items.items" :key="index">
          <fdk-link :link="`/product/${item.slug}`"> 
            <fy-product-card
              :product="item"
            ></fy-product-card>
          </fdk-link>
        </div>
      </carousel>
    </div>
  </div>
</template>

<style lang="less" scoped>
/deep/.card-item {
  /*border: 1px solid @Iron;*/
  border-radius: 8px;
  box-sizing: border-box;
  margin: 10px 0px;
}
/deep/.item {
  margin: 0px !important;
  margin-right: 30px !important;
}
/deep/.card-desc {
  padding-left: 8px;
  padding-right: 8px;
  width: calc(100% - 16px) !important;
  margin-top: 8px !important;
}
/deep/.bg-gradient {
  background-image: none !important;
}
/deep/.item-wrapper {
  overflow: hidden;
  display: flex;
  flex-wrap: nowrap;
  position: relative;
  -ms-overflow-style: none;
  overflow-x: scroll;
  -webkit-overflow-scrolling: touch;
  transition: 1s linear;
  &::-webkit-scrollbar {
    display: none;
  }
}
.carousel {
  .item {
    margin: 0px 10px;
    min-width: 16%;
    /deep/.card-item {
      width: auto;
    }
    @media @mobile {
      min-width: 50%;
    }
  }
  @media @mobile {
    width: inherit;
  }
}

.similiar-container {
  background-color: @White;
  color: @Mako;
  border-radius: @BorderRadius;
  margin: 14px 0px;
  padding: 14px;
  .similiar-title {
    text-transform: uppercase;
    font-size:16px;
  }
  .similiar-desc {
    margin: 5px 0 14px 0;
    font-size: 14px;
  }
}
</style>

<script>
import carousel from "./carousel.vue";
// import groupItem from "./../../../global/components/group-item.vue";
import fyProductCard from "../../../global/components/fy-product-card";

export default {
  name: "similiar-product",
  components: {
    "fy-product-card": fyProductCard,
    "carousel": carousel,
  },
  props: {
    similars: {
      type: Array,
    },
  },
  data() {
    return {
      imagesize: {
        width: 135,
        height: 211,
      },
    };
  },
};
</script>
