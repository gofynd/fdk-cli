<template>
  <div
    class="hero-image-cont"
    :class="{
      'section-main-container': !settings.props.full_width.value,
      'full-width-section': settings.props.full_width.value,
    }"
  >
    <div>
      <!-- <img
        v-if="settings.props.image.value"
        :src="settings.props.image.value"
        alt=""
        onerror="this.style.display='none'"
        class="hero__image"
      /> -->
      <whitesplash-image
        v-if="settings.props.image.value"
        class="hero__image"
        :src="settings.props.image.value"
        :sources="[
          { breakpoint: { min: 1441, max: 1920 }, width: 1920 },
          { breakpoint: { min: 1367, max: 1440 }, width: 1440 },
          { breakpoint: { min: 1281, max: 1366 }, width: 1366 },
          { breakpoint: { min: 1025, max: 1280 }, width: 1280 },
          { breakpoint: { min: 769, max: 1024 }, width: 1024 },
          { breakpoint: { min: 541, max: 768 }, width: 768 },
          { breakpoint: { min: 481, max: 540 }, width: 540 },
          { breakpoint: { min: 361, max: 480 }, width: 480 },
          { breakpoint: { max: 360 }, width: 360 },
        ]"
      />
      <fdk-placeholder v-else type="banner-2" />
      <div class="overlay">
        <div
          class="overlay__content"
          :class="{
            overlay__left: settings.props.overlayLayout.value === 'left',
            overlay__center: settings.props.overlayLayout.value === 'center',
            overlay__right: settings.props.overlayLayout.value === 'right',
          }"
        >
          <whitesplash-image
            class="overlay__image"
            :src="settings.props.overlayImage.value"
            :sources="[{}]"
          />
          <h2
            class="overlay__text"
            :style="{ color: settings.props.text_color.value }"
          >
            {{ settings.props.text.value }}
          </h2>
          <button
            class="btn cta-btn"
            v-if="settings.props.ctaLink.value || settings.props.ctaText.value"
            :style="
              'border-color: ' +
              settings.props.text_color.value +
              ';color:' +
              settings.props.text_color.value
            "
          >
            <fdk-link :link="settings.props.ctaLink.value">
              {{ settings.props.ctaText.value }}
            </fdk-link>
          </button>
        </div>
      </div>
    </div>
  </div>
</template>
<settings>
{
  "name": "heroImage",
  "label": "Hero Image",
  "props": [
    {
      "id": "image",
      "type": "image_picker",
      "label": "Hero Image",
      "default": ""
    },
     {
      "type":"checkbox",
      "id":"full_width",
      "default": false,
      "label": "Full width",
      "info":"Check to allow items to take entire width of the viewport"
    },
    {
      "id": "overlayLayout",
      "type": "select",
      "options": [
        {
          "value": "left",
          "text" : "Align Left"
        },
        {
          "value": "center",
          "text" : "Align Center"
        },
        {
          "value": "right",
          "text": "Align Right"
        }
      ],
      "default": "center",
      "label": "Overlay Layout",
      "info":"Alignment of overlay content"
    },
    {
      "type": "image_picker",
      "id": "overlayImage",
      "default": "",
      "label": "Overlay image",
      "info":"Overlay Image"
    },
    
    {
      "type": "text",
      "id": "text",
      "default": "",
      "label": "Overlay Text"
    },
    {
      "type":"color",
      "id":"text_color",
      "default":"#000",
      "label":"Text Color"
    },
    {
      "type": "url",
      "id": "ctaLink",
      "default": "",
      "label": "Redirect Link"
    },
    {
      "type": "text",
      "id": "ctaText",
      "default": "",
      "label": "Button Text"
    }
  ]
}
</settings>
<style scoped lang="less">
.btn {
  border: 0;
  background: none;
  a {
    display: inline-block;
    font-size: 14px;
    width: 100%;
    text-align: center;
    cursor: pointer;
    font-weight: 700;
    text-transform: uppercase;
    -webkit-appearance: none;
    -webkit-border-radius: 0;
    padding: 10px 40px;
    letter-spacing: 1px;
    color: inherit;
    width: 200px;
    border-width: 2px;
    border-color: inherit;
    background-color: transparent;
    border-style: solid;
    @media (min-width: 320px) and (max-width: 768px) {
      width: 150px;
    }
  }
}
.btn:hover {
  filter: invert(1);
}

.hero__image {
  width: 100%;
}
.overlay {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 100%;
  transform: translate(-50%, -50%);
  &__content {
    display: flex;
    flex-direction: column;
    padding: 20px;
  }
  &__left {
    align-items: flex-start;
    justify-content: flex-start;
  }
  &__center {
    align-items: center;
    justify-content: center;
  }
  &__right {
    align-items: flex-end;
    justify-content: flex-end;
  }
  &__image {
    max-width: 35%;
    margin-bottom: 10px;
    @media @mobile {
      width: 100px;
    }
  }
  &__text {
    font-size: 40px;
    font-weight: 700;
    margin-bottom: 10px;
    @media @mobile {
      font-size: 25px;
    }
  }
}
</style>

<script>
// import turbtn from './../global/components/tur-button';
import fyImage from "../global/components/common/whitesplash-image.vue";
export default {
  components: {
    "whitesplash-image": fyImage,
  },
  props: ["settings"],
  watch: {
    settings: function (newVal, oldVal) {},
  },
  mounted() {},
  data: function () {
    return {
      // url: ""
    };
  },
};
</script>
