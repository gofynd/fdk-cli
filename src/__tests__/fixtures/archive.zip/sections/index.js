
            import * as component0 from './brands-template.vue';
import * as component1 from './categories-template.vue';
import * as component2 from './collection-template.vue';
import * as component3 from './custom-html.vue';
import * as component4 from './extension.vue';
import * as component5 from './featured-products.vue';
import * as component6 from './gallery.vue';
import * as component7 from './hero-banner.vue';
import * as component8 from './hero-image.vue';
import * as component9 from './hero-video.vue';
import * as component10 from './image-banner.vue';
import * as component11 from './infinite-listing.vue';
import * as component12 from './points.vue';
import * as component13 from './product-list.vue';
import * as component14 from './refer-and-earn.vue';
import * as component15 from './slideshow.vue';
import * as component16 from './testimonials.vue';
import * as component17 from './video-carousel.vue';
import * as component18 from './wishlist-template.vue';

            function exportComponents(components) {
            return [
                {"name":"brands-listing","label":"Brands Listing","component": components[0].default},
{"name":"categoryListPage","label":"Category List ","component": components[1].default},
{"name":"collections-listing","label":"Collections Listing","component": components[2].default},
{"name":"customHtml","label":"Custom HTML","component": components[3].default},
{"name":"section_extension","label":"Extensions","component": components[4].default},
{"name":"featuredProducts","label":"Featured Products","component": components[5].default},
{"name":"gallery","label":"Gallery","component": components[6].default},
{"name":"heroBanner","label":"Hero Banner","component": components[7].default},
{"name":"heroImage","label":"Hero Image","component": components[8].default},
{"name":"heroVideoBanner","label":"Hero Video","component": components[9].default},
{"name":"imageBanner","label":"Image Banner","component": components[10].default},
{"name":"infiniteProductListing","label":"Recomended Products","component": components[11].default},
{"name":"points","label":"Points","component": components[12].default},
{"name":"productList","label":"Collection Product List","component": components[13].default},
{"name":"refer-and-earn","label":"Refer And Earn","component": components[14].default},
{"name":"image-slideshow","label":"Image Slideshow","component": components[15].default},
{"name":"testimonials","label":"Testimonial","component": components[16].default},
{"name":"videoCarousel","label":"Video Carousel","component": components[17].default},
{"name":"infiniteWishlistListing","label":"Wishlist page","component": components[18].default}
            ];
            }

            export default exportComponents([component0,component1,component2,component3,component4,component5,component6,component7,component8,component9,component10,component11,component12,component13,component14,component15,component16,component17,component18]);
            