<template>
  <div class="section-main-container">
    <div class="top-items">
      <fdk-link
        :link="(settings.props.ctaLink && settings.props.ctaLink.value) || ''"
      >
        <whitesplash-image
          :src="banner_image"
          :sources="[
            { breakpoint: { min: 1441, max: 1920 }, width: 1920 },
            { breakpoint: { min: 1367, max: 1440 }, width: 1440 },
            { breakpoint: { min: 1281, max: 1366 }, width: 1366 },
            { breakpoint: { min: 1025, max: 1280 }, width: 1280 },
            { breakpoint: { min: 769, max: 1024 }, width: 1024 },
            { breakpoint: { min: 541, max: 768 }, width: 768 },
            { breakpoint: { min: 481, max: 540 }, width: 540 },
            { breakpoint: { min: 361, max: 480 }, width: 480 },
            { breakpoint: { max: 360 }, width: 360 },
          ]"
          :placeholder="''"
          v-if="banner_image"
        />
        <fdk-placeholder v-else type="banner-1" />
      </fdk-link>
    </div>
  </div>
</template>
<settings>
{
  "name": "heroBanner",
  "label": "Hero Banner",
  "props": [
    {
      "type": "url",
      "id": "ctaLink",
      "default": "",
      "label": "Redirect Link"
    }
  ]
}
</settings>
<script>
import fyImage from "../global/components/common/whitesplash-image.vue";

export default {
  props: ["settings", "context"],
  mounted() {
    console.log(this.context, "HERO BANNER CONTEXT");
  },
  components: {
    "whitesplash-image": fyImage,
  },
  data() {
    return {
      banner_image:
        (this.context.app_config.application.banner &&
          this.context.app_config.application.banner.secure_url) ||
        "",
    };
  },
  methods: {},
};
</script>
<style lang="less" scoped>
.card-container {
  margin: 0;
}
.top-items {
  border-radius: @BorderRadius;
  background: @White;
  padding: 14px;
  @media @mobile {
    padding: 0;
  }
  /deep/ .fy__img {
    width: 100%;
  }
}
</style>
