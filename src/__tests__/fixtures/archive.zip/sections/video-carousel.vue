<template>
  <div
    :class="{
      'section-main-container': !settings.props.full_width.value,
      'full-width-section': settings.props.full_width.value,
    }"
    v-if="settings.blocks.length > 0"
  >
    <button
      type="button"
      class="prev-arrow"
      ref="prevArrow"
      @click="prevSlide"
    ></button>
    <button
      type="button"
      class="next-arrow"
      ref="nextArrow"
      @click="nextSlide"
    ></button>
    <VueSlickCarousel ref="slick" v-bind="slickOptions">
      <div
        class="slick-slide"
        v-for="(block, index) in settings.blocks"
        :key="index"
      >
        <div class="video-container" :class="settings.props.slide_height.value">
          <video
            :muted="!block.props.showcontrols.value"
            :loop="!block.props.showcontrols.value"
            :autoplay="!block.props.showcontrols.value"
            :poster="block.props.coverUrl.value"
            preload="auto"
            :controls="block.props.showcontrols.value"
            v-if="
              block.props.videoUrl.value && isMp4(block.props.videoUrl.value)
            "
          >
            <source :src="block.props.videoUrl.value" type="video/mp4" />
          </video>

          <div
            class="yt-video"
            v-if="
              block.props.videoUrl.value &&
                isYoutube(block.props.videoUrl.value)
            "
            :id="'yt-video-' + getYTVideoID(block.props.videoUrl.value)"
            :data-videoid="getYTVideoID(block.props.videoUrl.value)"
            :data-videometa="JSON.stringify(block.props)"
          ></div>
        </div>
      </div>
    </VueSlickCarousel>
  </div>
</template>
<settings>
{
  "name": "videoCarousel",
  "label": "Video Carousel",
  "blocks": [
    {
      "type": "video_item",
      "name": "Video Slide",
      "props": [
        {
          "id": "videoUrl",
          "type": "url",
          "label": "Video URL",
          "default": ""
        },
      
        {
          "type": "checkbox",
          "id": "showcontrols",
          "default": false,
          "label": "Show Controls on Video",
          "info":"Check to show controls on video"

        }
      ]
    }
  ],
  "props": [
    {
      "type": "select",
      "id": "slide_height",
      "options": [
        {
          "value": "adapt",
          "text": "Adapt to first video"
        },
        {
          "value": "small",
          "text": "Small"
        },
        {
          "value": "medium",
          "text": "Medium"
        },
        {
          "value": "large",
          "text": "Large"
        }
      ],
      "default": "adapt",
      "label": "Slide height",
      "info":"Size of the slide"

    },
    {
      "type":"checkbox",
      "id":"full_width",
      "default": false,
      "label": "Full width",
      "info":"Check to allow items to take entire width of the viewport"
    },
    {
      "type": "checkbox",
      "id": "autoplay",
      "default": false,
      "label": "AutoPlay Slides",
            "info":"Check to autoplay slides"
    },
    {
      "type": "range",
      "id": "slide_interval",
      "min": 1,
      "max": 10,
      "step": 1,
      "unit": "sec",
      "label": "Change slides every",
      "default": 2,
      "info": "Autoplay slide duration"
    }
  ]
}
</settings>
<script>
import VueSlickCarousel from "vue-slick-carousel";

export default {
  props: ['settings'],
  components: {
    VueSlickCarousel,
  },
  mounted() {
    this.loadYTScript();
  },
  data: function() {
    return {
      slickOptions: {
        autoplaySpeed: this.settings.props.autoplay.value
          ? this.settings.props.slide_interval.value * 1000
          : undefined, //convert to ms
        autoplay: this.settings.props.autoplay.value,
        arrows: true,
        dots: true,
        swipeToSlide: true,
        prevArrow: this.$refs.prevArrow,
        nextArrow: this.$refs.nextArrow,
      },
    };
  },
  methods: {
    prevSlide() {
      this.$refs.slick.prev();
    },
    nextSlide() {
      this.$refs.slick.next();
    },
    loadYTScript() {
      var self = this;
      if (typeof YT == 'undefined' || typeof YT.Player == 'undefined') {
        var tag = document.createElement('script');
        tag.src = 'https://www.youtube.com/iframe_api';
        var firstScriptTag = document.getElementsByTagName('script')[0];
        firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
        tag.onload = () => {
          if (!window.onYouTubeIframeAPIReady) {
            window.onYouTubeIframeAPIReady = function() {
              setTimeout(self.onYouTubeIframeAPIReady.bind(self), 500);
            };
          } else {
            setTimeout(self.onYouTubeIframeAPIReady.bind(self), 500);
          }
        };
      }
    },
    isMp4(url) {
      if (!url) {
        return false;
      }
      let ext = url.split('.').pop() || '';
      if (ext && ext.toLowerCase() === 'mp4') {
        return true;
      } else {
        return false;
      }
    },
    isYoutube(url) {
      let urlObj = new URL(url);

      if (
        urlObj.host.includes('youtu.be') ||
        urlObj.host.includes('youtube.com')
      ) {
        return true;
      }
      return false;
    },

    getYTVideoID(url) {
      let urlObj = new URL(url);
      let searchParams = urlObj.searchParams;
      let v = searchParams.get('v');
      if (urlObj.host.includes('youtu.be')) {
        v = urlObj.pathname.split('/').pop();
      }
      return v;
    },
    onYouTubeIframeAPIReady() {
      var ytVideos = document.querySelectorAll('.yt-video');
      if (!window.players) {
        window.players = {};
      }
      var players = window.players;
      ytVideos.forEach((node) => {
        let videoID = node.dataset.videoid;
        players[videoID] = {};
        let videoMeta = JSON.parse(node.dataset.videometa);
        let controls = videoMeta.showcontrols.value;
        let qautoplay = 0,
          qcontrols = 1,
          qmute = 0;

        if (!controls) {
          qautoplay = 1;
          qcontrols = 0;
          qmute = 1;
        }

        players[videoID].onReady = function(e) {
          if (qmute) {
            e.target.mute();
          }
          // e.target.setVolume(50); // For max value, set value as 100.
        };

        players[videoID].onStateChange = function(event) {
          if (event.data == YT.PlayerState.ENDED) {
            players[videoID].inst.seekTo(0);
            players[videoID].inst.playVideo();
          }
        };
        players[videoID].inst = new YT.Player('yt-video-' + videoID, {
          videoId: videoID, // The video id.
          width: '100%',
          height: '100%',
          playerVars: {
            autoplay: qautoplay, // Autoplay when page loads.
            controls: qcontrols,
            modestbranding: 1,
            loop: 1,
            fs: 0,
            cc_load_policty: 0,
            iv_load_policy: 3,
          },
          events: {
            onReady: players[videoID].onReady,
            onStateChange: players[videoID].onStateChange,
          },
        });
      });
    },
  },
};
</script>

<style lang="less" scoped>
@import "../../node_modules/vue-slick-carousel/dist/vue-slick-carousel.css";
@import "../../node_modules/vue-slick-carousel/dist/vue-slick-carousel-theme.css";

.section-main-container {
  background-color: #ffffff;
  overflow: hidden;
}
.full-width-section{
  background-color: #ffffff;
}
.slick-next {
  right: 0;
}
.next-arrow,
.prev-arrow {
  position: absolute;
  top: 50%;
  background: transparent;
  border: none;
  transform: translateY(-50%);
  z-index: 1;
  cursor: pointer;
}
.next-arrow {
  right: 25px;
  @media @mobile {
    right: 10px;
  }
  &::before {
    color: gray;
    content: '→';
    font-family: slick;
    font-size: 25px;
  }
}
.prev-arrow {
  left: 25px;
  @media @mobile {
    left: 10px;
  }
  &::before {
    color: gray;

    content: '←';
    font-family: slick;
    font-size: 25px;
  }
}
</style>
