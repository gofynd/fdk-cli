<template>
  <div class="section-main-container">
    <div class="section-container slot-margin">
      <h1 class="section-heading" v-if="settings && settings.props.heading.value">
      {{ settings.props.heading.value }}
    </h1>
      <div
        class="gallery-container"
        v-if="settings.props.layout.value === 'gallery'"
      >
        <fdk-link
          :link="block.props.link.value"
          class="gallery-item"
          :class="{
            'gallery-item__one-item': settings.props.item_count.value === 1,
            'gallery-item__two-item': settings.props.item_count.value === 2,
            'gallery-item__three-item': settings.props.item_count.value === 3,
            'gallery-item__four-item': settings.props.item_count.value === 4,
            'gallery-item__five-item': settings.props.item_count.value === 5,
            overlay:
              block.props.link.value.length > 0 ||
              block.props.caption.value.length > 0,
          }"
          v-for="(block, index) in settings.blocks"
          :key="index"
        >
        <whitesplash-image
          :src="block.props.image.value"
          :alt="'galleryImage'+index"
          class="gallery-img"
          :sources="[
              { breakpoint: { min: 1367 }, width: 480, height: 508 },
              { breakpoint: { min: 720 }, width: 360, height: 508  },
              { breakpoint: { min: 481 }, width: 300, height: 508  },
              { breakpoint: { max: 480 }, width: 240, height: 508  },
            ]"
          />
          <h3
            class="gallery-img-caption"
            v-if="block.props.caption && block.props.caption.value.length > 0"
          >
            {{ block.props.caption.value }}
          </h3>
        </fdk-link>
        <div
          class="placeholder-item"
          :class="{
            'gallery-item__one-item': settings.props.item_count.value === 1,
            'gallery-item__two-item': settings.props.item_count.value === 2,
            'gallery-item__three-item': settings.props.item_count.value === 3,
            'gallery-item__four-item': settings.props.item_count.value === 4,
            'gallery-item__five-item': settings.props.item_count.value === 5,
          }"
          v-for="index in placeholderBlock"
          :key="index"
        >
        <whitesplash-image
          :alt="'galleryImage'+index"
          class="gallery-img"
          :sources="[
              { breakpoint: { min: 1367 }, width: 480, height: 508 },
              { breakpoint: { min: 720 }, width: 360, height: 508  },
              { breakpoint: { min: 481 }, width: 300, height: 508  },
              { breakpoint: { max: 480 }, width: 240, height: 508  },
            ]"
          />
        </div>
      </div>
      <div
        class="h-slider-items"
        v-if="settings.props.layout.value === 'horizontal'"
      >
        <VueSlickCarousel ref="slick" v-bind="slickOptions">
          <fdk-link
            :link="block.props.link.value"
            v-for="(block, index) in settings.blocks"
            :key="index"
            class="h-slider-item"
          >
            <div class="carousel-cell">
              <whitesplash-image
                :src="block.props.image.value"
                class="imgClass"
                :alt="block.props.caption.value"
              />
              <div class="carousel-details">
                <div class="desc">
                  <span class="ukt-title">{{ block.props.caption.value }}</span>
                </div>
                <!-- <img class="item__logo" :src="brand.logo.url" alt /> -->
              </div>
            </div>
            <!-- <p class="item__name">{{ brand.name }}</p> -->
          </fdk-link>
        </VueSlickCarousel>
        <div class="arrows">
          <div
            class="prev-btn btn-nav-gallery"
            ref="prevArrow"
            @click="prevSlide"
          >
            <img src="../assets/images/arrow-left.png" />
          </div>
          <div
            class="next-btn btn-nav-gallery"
            ref="nextArrow"
            @click="nextSlide"
          >
            <img src="../assets/images/arrow-right.png" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<settings>
{
  "name": "gallery",
  "label": "Gallery",
  "props": [
        {
          "type": "text",
          "id": "heading",
          "default": "Featured Products",
          "label": "Section Heading"
        },
        {
          "id": "layout",
          "type": "select",
          "options": [
            {
              "value": "gallery",
              "text" : "Gallery View"
            },
            {
              "value": "horizontal",
              "text" : "Horizontal View"
            }
          ],
          "default": "gallery",
          "label": "Layout",
          "info":"Alignment of content"
        },
        {
            "type": "range",
            "id": "item_count",
            "min": 1,
            "max": 5,
            "step": 1,
            "unit": "",
            "label": "No of items",
            "default": 4,
            "info": "Maximum items allowed per row for Horizontal view, for gallery max 5 are viewable and only 5 blocks are required"
        }
    ],
    "blocks": [
        {
        "type": "gallery_image",
        "name": "Image",
        "props": [
            {
                "type": "image_picker",
                "id": "image",
                "label": "Gallery Image",
                "default": "https://hdn-1.fynd.com/company/884/applications/000000000000000000000001/theme/pictures/free/original/theme-image-1598448644345.png"
            },
            {
                "type": "text",
                "id": "caption",
                "label": "Image Caption",
                "default": ""
            },
            {
              "type": "url",
              "id": "link",
              "label": "Link",
              "default":"",
              "info":"Link to redirect"
            }
        ]
    }
  ],
 "preset":{
    "blocks":[
      {
        "name":"Image"
      },
       {
        "name":"Image"
      },
       {
        "name":"Image"
      },
       {
        "name":"Image"
      }
    ]
  }
}
</settings>

<style scoped lang="less">
/deep/.imgClass {
  .fy__img {
    border-radius: 8px !important;
    box-shadow: 9px 6px 10px rgba(0, 0, 0, 0.2);
  }
}
/deep/.gallery-img {
  .fy__img {
    object-fit: cover;
    height: 100%;
    object-position: center;
  }
}
.section-container {
  position: relative;
  overflow: hidden;
  list-style: none;
  padding: 10px;
  z-index: 1;

  @media @mobile{
    padding: 0;
  }
}
// code for gallery view
.gallery-container {
  display: flex;
  flex-wrap: wrap;
  @media @tablet {
    flex-wrap: wrap;
  }
  .placeholder-item {
    &:last-child {
      border-left: none;
    }
    @media @tablet {
      &:last-child {
        border-left: 1px solid #00000026;
      }
      width: 50% !important;
    }
    @media @mobile {
      width: 100% !important;
    }
  }
  .overlay {
    position: relative;
    &::before {
      content: "";
      background: black;
      opacity: 0.3;
      position: absolute;
      width: 100%;
      height: 100%;
    }
    &:hover {
      cursor: pointer;
      &::before {
        opacity: 0.5;
      }
    }
  }
  .gallery-item {
    @media @tablet {
      width: 50% !important;
    }
    @media @mobile {
      width: 100% !important;
    }
  }

  .gallery-item,
  .placeholder-item {
    height: 500px;
    overflow: hidden;
    box-sizing: border-box;
    background-repeat: no-repeat;
    background-position: 50% 50%;
    background-size: cover;
    &__one-item {
      width: 100%;
    }
    &__two-item {
      width: 50%;
    }
    &__three-item {
      width: 33.3333333334%;
    }
    &__four-item {
      width: 25%;
    }
    &__five-item {
      width: 20%;
    }
    .gallery-img-caption {
      top: 50%;
      position: absolute;
      left: 50%;
      transform: translate(-50%, -50%);
      color: white;
      font-size: 25px;
      font-weight: 700;
    }
  }
}

// code for horizontal view
.h-slider-items {
  position: relative;
  @media @mobile {
    padding: 0;
  }
  .h-slider-item {
    width: auto !important;
  }
  .carousel-cell {
    cursor: pointer;
    height: auto;
    margin-right: 30px;
    @media @mobile {
      margin-right: 10px;
    }
    position: relative;
    img.carousel-image {
      border-radius: 8px;
      /*border: 1px solid #aba3a333;*/
      // height: 328px;
      width: 100%;
      box-shadow: 9px 6px 10px rgba(0, 0, 0, 0.2);
      // @media @mobile {
      //   height: 250px;
      // }
    }

    .carousel-details {
      top: 76%;
      position: absolute;
      display: flex;
      width: 100%;
      left: 50%;
      height: 80px;
      background: transparent linear-gradient(180deg, transparent, #000) 0 0
        no-repeat padding-box;
      color: #fff;
      border-radius: 8px;
      box-sizing: border-box;
      left: 0;
      right: 0;
      .desc {
        font-size: 16px;
        margin-top: 18px;
        font-weight: 700;
        color: #ffffff;
        width: 100%;
        justify-content: center;
        display: flex;
        .ukt-title {
          text-transform: uppercase;
          width: 100%;
          display: block;
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;
          text-align: center;
          color: #fff;
          margin: 0 auto;
          padding: 0 10px;
          @media @mobile {
            width: 50%;
          }
        }
      }
    }
  }

  .btn-nav-gallery {
    position: absolute;
    top: 50%;
    z-index: @layer;
    transform: translate(0%, -50%);
    background-color: transparent;
    padding: unset;
    cursor: pointer;
    @media @mobile {
      width: 30px;
    }
  }
  .next-btn {
    right: 0;
    @media @mobile {
      right: 15px;
    }
  }
  .prev-btn {
    left: 0;
  }
}
</style>
<script>
import { isBrowser } from "browser-or-node";
import { detectMobileWidth } from "../helper/utils";
import fyImage from "./../global/components/common/whitesplash-image.vue";
import VueSlickCarousel from "vue-slick-carousel";

export default {
  props: ["settings"],
  components: {
    "whitesplash-image": fyImage,
    VueSlickCarousel,
  },
  computed: {
    placeholderBlock() {
      if (
        this.settings.props.item_count.value >= 5 &&
        this.settings.blocks.length >= 5
      ) {
        return 0;
      }
      if (this.settings.props.item_count.value >= this.settings.blocks.length) {
        return (
          this.settings.props.item_count.value - this.settings.blocks.length
        );
      }
      if (this.settings.props.item_count.value < this.settings.blocks.length) {
        return 0;
      }
    }
  },
  data: function () {
    return {
      slickOptions: {
        arrows: false,
        dots: false,
        swipeToSlide: true,
        slidesToShow: this.settings.props.item_count.value,
        slidesToScroll: this.settings.props.item_count.value
      },
    };
  },
  mounted() {
    this.slickOptions = {
      ...this.slickOptions,
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 3,
          },
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2,
          },
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2,
          },
        },
      ],
    };
  },
  methods: {
    setActiveSlide(index) {
      this.$refs.slick.goTo(index);
    },
    prevSlide() {
      if (detectMobileWidth()) {
        this.$refs.slick.goTo(
          this.$refs.slick.$refs.innerSlider.currentSlide - 1
        );
      } else {
        this.$refs.slick.goTo(
          this.$refs.slick.$refs.innerSlider.currentSlide - 4
        );
      }
    },
    nextSlide() {
      if (detectMobileWidth()) {
        this.$refs.slick.goTo(
          this.$refs.slick.$refs.innerSlider.currentSlide + 1
        );
      } else {
        this.$refs.slick.goTo(
          this.$refs.slick.$refs.innerSlider.currentSlide + 4
        );
      }
    },
  },
};
</script>
