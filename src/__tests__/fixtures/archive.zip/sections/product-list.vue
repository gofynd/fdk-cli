<template>
  <div
    :class="{
      'section-main-container': !settings.props.full_width.value,
      'full-width-section': settings.props.full_width.value,
    }"
  >
    <h2 v-if="settings.props.heading.value" class="section-heading">
      {{ settings.props.heading.value }}
    </h2>
    <div class="section__items" v-if="products.length > 0">
      <div
        class="item"
        :class="{
          'item__two-item': settings.props.item_count.value === 2,
          'item__three-item': settings.props.item_count.value === 3,
          'item__four-item': settings.props.item_count.value === 4,
          'item__five-item': settings.props.item_count.value === 5,
        }"
        v-for="(product, index) in products"
        :key="'prod-item-' + index"
      >
        <!-- {{ block }} -->
        <fdk-link :link="`/product/${product.slug}`" v-if="product">
          <whitesplash-image
            alt="Shop Now"
            class="product-image"
            :src="product.medias.length > 0 ? product.medias[0].url : ''"
            :title="product.name"
            :sources="[
              {breakpoint: {max: 480}, width: 240},
              {breakpoint: {min: 481}, width: 300},
              { breakpoint: { min: 720 }, width: 360 },
              { breakpoint: { min: 1367 }, width: 480 },
            ]"
          />
        </fdk-link>
        <fdk-placeholder v-else type="product-2" />
        <p class="product-brand">
          {{ product ? product.brand.name : `Brand ${index}` }}
        </p>
        <h3 class="product-name">
          {{ product ? product.name : `Product ${index}` }}
        </h3>
        <div class="price" v-if="product">
          <span>
            <meta v-if="hasDiscount(product)" />
            <span class="strike-through list" v-if="hasDiscount(product)">
              <span class="value">
                {{ product.price.marked.currency_symbol }}
                {{ product.price.marked.max }}
              </span>
            </span>
            <span
              class="product-total-discount list"
              v-if="hasDiscount(product)"
            >
              <span class="value">{{ product.discount }}</span>
            </span>
            <meta />
            <span class="sales">
              <span class="value">
                {{ product.price.effective.currency_symbol }}
                {{ getPrice(product, "effective") }}
              </span>
            </span>
          </span>
        </div>
        <div class="price" v-else>
          <span class="sales">
            <span class="value">
              {{ 100 | currencyformat }}
            </span>
          </span>
        </div>
      </div>
    </div>
    <div class="section__items" v-else-if="products.length === 0">
      <div
        class="item"
        :class="{
          'item__two-item': settings.props.item_count.value === 2,
          'item__three-item': settings.props.item_count.value === 3,
          'item__four-item': settings.props.item_count.value === 4,
          'item__five-item': settings.props.item_count.value === 5,
        }"
        :key="index"
        v-for="index in 4"
      >
        <fdk-link :link="`#`" class="product-link">
          <fdk-placeholder type="product-2" />
        </fdk-link>
        <p class="product-brand">
          {{ `Brand ${index}` }}
        </p>
        <h3 class="product-name">
          {{ `Product ${index}` }}
        </h3>
        <div class="price">
          <span class="sales">
            <span class="value">
              {{ 100 | currencyformat }}
            </span>
          </span>
        </div>
      </div>
    </div>
  </div>
</template>
<settings>
{
    "name":"productList",
    "label":"Collection Product List",
    "props":[
        {
            "type": "text",
            "id": "heading",
            "default": "",
            "label": "Collection Heading"
        },
        {
            "type": "range",
            "id": "item_count",
            "min": 2,
            "max": 5,
            "step": 1,
            "unit": "",
            "label": "Collections per row",
            "default": 4,
            "info": "Maximum items allowed per row"
        },
        {
            "type": "collection",
            "id": "collection",
            "label": "Collection",
            "info":"Select a collection to display its products"
        },
        {
          "type":"checkbox",
          "id":"full_width",
          "default": false,
          "label": "Full width",
          "info":"Check to allow items to take entire width of the viewport"
        }
    ]
}

</settings>
<script>
import fyImage from "./../global/components/common/whitesplash-image.vue";
export default {
  props: ["settings", "apiSDk", "serverProps"],
  components: {
    "whitesplash-image": fyImage,
  },
  initializeServerProps({ apiSDk, settings }) {
    const collection = settings?.props?.collection?.value;
    return apiSDk.catalog
      .getCollectionItemsBySlug({
        slug: collection,
      })
      .then((res) => {
        return res?.items || [];
      })
      .catch((e) => console.log(e));
  },
  watch: {
    settings(n, o) {
      if (n?.props?.collection?.value !== o?.props?.collection?.value) {
        const collection = n?.props?.collection?.value;
        this.getProducts(collection);
      }
    },
  },
  mounted() {
    if (this.products.length == 0) {
      const collection = this.settings?.props?.collection?.value;
      this.getProducts(collection);
    }
  },
  data() {
    return {
      products: this.serverProps || [],
    };
  },
  methods: {
    getProducts(slug) {
      if (!slug) return;
      this.$apiSDK.catalog
        .getCollectionItemsBySlug({
          slug: slug,
        })
        .then((res) => {
          this.products = res?.items || [];
        });
    },
    getPrice(product, key) {
      if (product && product.price) {
        return product.price[key].min !== product.price[key].max
          ? product.price[key].min + " - " + product.price[key].max
          : product.price[key].min;
      }
    },
    hasDiscount(product) {
      return (
        this.getPrice(product, "effective") !== this.getPrice(product, "marked")
      );
    },
  },
};
</script>

<style lang="less" scoped>
.item {
  display: flex;
  flex-direction: column;
  .product-image {
    width: 100%;
  }
  .product-brand {
    font-size: 12px;
    margin-top: 10px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }
  .product-name {
    font-size: 18px;
    margin-top: 5px;
    font-weight: 700;
    color: #41434c;
  }

  .price {
    margin-top: 10px;
    font-size: 14px;
    .strike-through {
      text-decoration: line-through;
      color: #cacaca;
    }
    .product-total-discount {
      padding: 0 10px;
    }
    .sales {
      font-weight: 400;
      .value {
        font-size: 15px;
        font-weight: bold;
        color: #41434c;
      }
    }
  }
}
</style>
