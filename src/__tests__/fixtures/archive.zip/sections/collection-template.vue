<template>
  <div class="section-main-container" v-if="collections">
    <div class="collections__template">
      <template>
        <fdk-infinite-scrolling
          @loadmore="loadMoreData()"
          :loadingData="loading"
        >
          <template v-if="collections.length > 0">
            <div class="card-container">
              <div class="top-items">
                <div class="title-block">
                  <div
                    class="ukt-title bold-md"
                    v-if="
                      settings.props.title.value &&
                        settings.props.title.value.length > 0
                    "
                  >
                    {{ settings.props.title.value }}
                  </div>
                  <fdk-link
                    :link="'/collections/'"
                    class="ukt-links bold-sm"
                    v-if="
                      collections.length > 0 && settings.props.view_all.value
                    "
                    >View All</fdk-link
                  >
                </div>
                <div v-if="settings.props.layout.value === 'grid'">
                  <group-list
                    :cardlist="collections"
                    :cardtype="'COLLECTIONS'"
                    :itemcount="settings.props.item_count.value"
                  ></group-list>
                </div>
                <div
                v-if="
                  settings.props.layout.value === 'horizontal'
                "
              >

                  <div class="collection-items">
                    <div :class="'glide' + _uid" ref="glide">
                      <div data-glide-el="track" class="glide__track">
                        <div
                          class="glide__slides ssr-slides-collection"
                          :data-count="settings.props.item_count.value"
                          :class="{
                            'big-slide-item':
                              settings.props.item_count.value < 5,
                          }"
                        >
                          <div
                            class="glide__slide"
                            v-for="(collection, index) in collections"
                            :key="index"
                          >
                            <fdk-link :link="`/collection/${collection.slug}`">
                              <div class="carousel-cell">
                                <whitesplash-image
                                  :src="collection.banners.portrait.url"
                                  :sources="[
                                    { breakpoint: { min: 1025 }, width: 220 },
                                    { breakpoint: { min: 769 }, width: 316 },
                                    { breakpoint: { min: 768 }, width: 231 },
                                    { breakpoint: { min: 481 }, width: 220 },
                                    { breakpoint: { min: 376 }, width: 190 },
                                    { breakpoint: { min: 361 }, width: 162 },
                                    { breakpoint: { min: 321 }, width: 154 },
                                    { breakpoint: { max: 320 }, width: 136 },
                                  ]"
                                  class="imgClass"
                                  :alt="collection.name"
                                />
                                <div class="carousel-details">
                                  <div
                                    class="card-logo"
                                    v-if="
                                      brand &&
                                        collection.logo &&
                                        collection.logo.url
                                    "
                                  >
                                    <whitesplash-image
                                      :src="collection.logo.url"
                                      :sources="[{ width: 50 }]"
                                      :placeholder="''"
                                    />
                                  </div>
                                  <div class="collection_desc">
                                    <div class="card-desc cl-content">
                                      <span class="ukt-title">{{
                                        collection.name
                                      }}</span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </fdk-link>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div
                      :class="{
                        'hide-slider-nav':
                          collections.length <= glideOptions.perView,
                      }"
                    >
                      <div
                        class="prev-btn btn-nav-coll"
                        ref="prevArrow"
                        @click="prevSlide"
                      >
                        <img src="../assets/images/arrow-left.png" />
                      </div>
                      <div
                        class="next-btn btn-nav-coll"
                        ref="nextArrow"
                        @click="nextSlide"
                      >
                        <img src="../assets/images/arrow-right.png" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </template>
          <template v-else-if="collections.length === 0 && isMounted">
            <placeholder-items
              :count="10"
              type="collection-3"
              text="Collection"
              :layout="settings.props.layout.value"
            />
          </template>
          <fdk-loader v-if="isLoading" class="infi-loader" />
        </fdk-infinite-scrolling>
      </template>
    </div>
  </div>
</template>
<settings>
{
    "name":"collections-listing",
    "label":"Collections Listing",
    "props":[
    {
      "type": "text",
            "id": "title",
            "default": "",
            "label": "Title"
    },
    {
          "type":"radio",
          "id": "collection_type",
          "default":"all",
          "options": [
            {
              "value": "all",
              "text": "All"
            },
            {
              "value": "handpicked",
              "text": "Handpicked"
            }
          ]
    },
    {
      "type": "range",
      "id": "item_count",
      "min": 3,
      "max": 5,
      "step": 1,
      "unit": "",
      "label": "Items per row",
      "default": 5,
      "info": "Maximum items allowed per row"
    },
    {
      "id": "layout",
      "type": "select",
      "options": [
        {
          "value": "grid",
          "text" : "Grid View"
        },
        {
          "value": "horizontal",
          "text" : "Horizontal View"
        }
      ],
      "default": "horizontal",
      "label": "Layout",
      "info":"Alignment of content"
    },

    {
        "type": "checkbox",
        "id": "view_all",
      "default": false,
        "label": "Show View All"
    }
    ],
    "blocks": [
      {
        "type": "collection-item",
        "name": "collection Item",
        "props": [
          {
            "type": "collection",
            "id": "collection",
            "label":"Select Collection"
          }
        ]
      }
  ]
}
</settings>
<script>
import placeholderImage from "./../assets/images/placeholder.png";
import { isBrowser, isNode } from "browser-or-node";
import groupList from "./../global/components/group-list.vue";
import { detectMobileWidth } from "../helper/utils";
import Glide from "@glidejs/glide";
import fyImage from "./../global/components/common/whitesplash-image.vue";
import placeholderItemsVue from "../global/components/sections/placeholder-items.vue";
import "../../node_modules/@glidejs/glide/dist/css/glide.core.min.css";
import "../../node_modules/@glidejs/glide/dist/css/glide.theme.min.css";

export default {
  props: ["settings", "serverProps"],
  data() {
    return {
      collections: this.serverProps?.collections || [],
      isLoading: false,
      collectionsLoaded: this.serverProps?.collectionsLoaded || 0,
      isMounted: false,
      isMountedCarousel: false,
      page: this.serverProps?.page || { current: 0, has_next: true },
      glideOptions: {
        type: "slider",
        bound: true,
        rewind: false,
        startAt: 0,
        gap: 30,
        perView: this.settings.props.item_count.value,
        breakpoints: {
          768: {
            perView: 3,
          },
          600: {
            perView: 2,
          },
          480: {
            perView: 2,
          },
        },
      },
      carouselHandle: null,
    };
  },
  components: {
    "group-list": groupList,
    "whitesplash-image": fyImage,
    "placeholder-items": placeholderItemsVue,
  },
  computed: {
    imageWidth: function() {
      let w = 312;
      if (isBrowser) {
        if (window.screen.width >= 1280) {
          w = 275;
        } else if (window.screen.width >= 768) {
          w = 312;
        } else if (window.screen.width > 360) {
          w = 184;
        } else if (window.screen.width <= 360) {
          w = 160;
        }
      }
      return w;
    },
  },
  watch: {
    settings(newVal, oldVal) {
      if (
        newVal.props.layout.value !== oldVal.props.layout.value ||
        newVal.props.collection_type.value !==
          oldVal.props.collection_type.value ||
        newVal.props.item_count.value !== oldVal.props.item_count.value ||
        this.isBlocksChanged(newVal.blocks, oldVal.blocks)
      ) {
        this.collections = [];
        this.collectionsLoaded = 0;
        this.page = { current: 0, has_next: true };
        this.settings = newVal;
        this.cleanupComponent();
        this.initializeComponent();
      }
    },
  },
  beforeDestroy() {
    this.cleanupComponent();
  },
  methods: {
    isBlocksChanged(newBlocks, oldBlocks) {
      return JSON.stringify(newBlocks) === JSON.stringify(oldBlocks)
        ? false
        : true;
    },
    cleanupComponent() {
      if (isBrowser && this.carouselHandle) {
        this.carouselHandle.destroy();
        this.carouselHandle = null;
      }
    },
    checkisBrowser() {
      return isBrowser;
    },
    prevSlide() {
      // item_count variable holds the value of number of items to show
      let item_count = this.settings.props.item_count.value;

      if (detectMobileWidth()) {
        if (this.carouselHandle.index - 1 >= 0) {
          this.carouselHandle.go(`=${this.carouselHandle.index - 1}`);
        }
      } else {
        if (this.carouselHandle.index - item_count >= 0) {
          this.carouselHandle.go(`=${this.carouselHandle.index - item_count}`);
        } else {
          this.carouselHandle.go(`<<`);
        }
      }
    },
    nextSlide() {
      let item_count = this.settings.props.item_count.value - 1;
      if (detectMobileWidth()) {
        ///this.categories.length has to be replaced by the length of items in carousel
        if (this.carouselHandle.index + 1 < this.collections.length - 1) {
          this.carouselHandle.go(`=${this.carouselHandle.index + 1}`);
        }
      } else {
        if (this.carouselHandle.index + item_count < this.collections.length) {
          this.carouselHandle.go(`=${this.carouselHandle.index + item_count}`);
        } else {
          this.carouselHandle.go(`>>`);
        }
      }
    },
    initCarousel() {
      //if IsNode OR Layout is horizontal(optional flag) OR carouselHandle(carousel) is not already initialized
      if (
        !isBrowser||
        this.settings.props.layout.value !== "horizontal" ||
        this.carouselHandle
      ) {
        return;
      }
      if (!this.$refs.glide) {
        setTimeout(() => {
          this.initCarousel();
        }, 1000);
        return;
      }
      // waiting for data to render, hence nextTick
      this.$nextTick(() => {
        try {
          if (window.screen.width <= 480) {
            this.glideOptions.gap = 10;
          }
          if (this.collections.length <= this.glideOptions.perView) {
            this.glideOptions.type = "slider";
          } else {
            this.glideOptions.type = "carousel";
          }
          this.carouselHandle = new Glide(this.$refs.glide, this.glideOptions);
          this.carouselHandle.on("mount.after", function () {
            let elt = document.querySelector(".ssr-slides-collection");
            elt.style.display = "flex";
            elt.style["grid-column-gap"] = 0;
            elt.style['touch-action'] = "pan-Y";
            elt.style.overflow = "hidden";
          });
          this.carouselHandle.mount();
        } catch (ex) {
          //There is an exception logged, due to rendering delay, so this try,catch is required
        }
      });
    },
    initializeComponent() {
      if (window.screen.width > 600 && window.screen.width <= 768) {
        this.glideOptions.perView = 3;
      } else if (window.screen.width <= 600) {
        this.glideOptions.perView = 2;
      }
      this.glideOptions.perView = this.settings.props.item_count.value;
      if (this.collections.length == 0) {
        const { props, blocks } = this.settings;
        const options = {
          pageNo: this.page.current + 1,
        };
        this.fetchCollections(options);
      } else {
        this.isMountedCarousel = true;
        this.initCarousel();
      }
    },
    replaceByDefault(e) {
      e.target.src = placeholderImage;
    },
    loadMoreData() {
      let options = {
        pageNo: this.page.current + 1,
      };
      if (this.settings.props.layout.value === "grid") {
        !this.isLoading && this.fetchCollections(options);

      }
    },
       fetchCollections(options) {
      if (this.settings.props.collection_type.value !== "handpicked") {
        if (this.page && this.page.has_next) {
          this.isLoading = true;
          this.$apiSDK.catalog
            .getCollections(options)
            .then((data) => {
              this.collections = [...this.collections, ...data.items];
              this.page = data.page;
              this.isMounted = true;
              this.isLoading = false;
              this.initCarousel();
            })
            .catch((ex) => {
              this.isLoading = false;
            });
        } else {
          this.isLoading = false;
        }
      } else {
        if (this.collections.length === 0) {
          let allPromises = [];
          this.settings.blocks.forEach((block) => {
            if (block.props.collection && block.props.collection.value) {
              this.isLoading = true;
              allPromises.push(
                this.$apiSDK.catalog
                  .getCollectionDetailBySlug({
                    slug: block.props.collection.value,
                  })
                  .then((data) => {
                    if (data && data.banners) {
                      return data;
                    }
                  })
              );
            } else {
              allPromises.push(null);
            }
          });
          Promise.all(allPromises).then((data) => {
            this.collections = data;
            this.isMounted = true;
            this.isLoading = false;
            this.collectionsLoaded = this.collections.length;
            this.initCarousel();
          });
        }
      }
    },
  },
  mounted() {
    this.initializeComponent();
  },
  initializeServerProps({ apiSDK, settings, route }) {
    const options = {
      pageNo: 1,
    };
    if (settings.props.collection_type.value !== "handpicked") {
      return apiSDK.catalog.getCollections(options).then((data) => {
        return {
          collections: data?.items,
          page: data?.page,
        };
      });
    } else {
      const promises = settings.blocks.map((block) => {
        return apiSDK.catalog.getCollectionDetailBySlug({
          slug: block.props.collection.value,
        });
      });
      return Promise.all(promises).then((res) => {
        let collections = [];
        let collectionsLoaded = 0;
        res.forEach((data) => {
          if (data && data.banners) {
            collections.push(data);
          }
          collectionsLoaded++;
        });
        return {
          collections,
          collectionsLoaded,
        };
      });
    }
  },
};
</script>

<style lang="less" scoped>
/deep/.imgClass {
  width: 100%;
  .fy__img {
    border-radius: 8px;
    height: 100%;
    width: 100%;
  }
}
.glide__slide {
  height: auto;
  a {
    display: flex;
    height: 100%;
    min-height: 290px;
    @media only screen and (max-width: 1024px) {
      min-height: 215px;
    }
    @media only screen and (max-width: 768px) {
      min-height: 280px;
    }
    @media only screen and (max-width: 600px) {
      min-height: 270px;
    }
    @media only screen and (max-width: 480px) {
      min-height: 230px;
    }
    @media only screen and (max-width: 360px) {
      min-height: 215px;
    }
  }
}

.glide__slides.ssr-slides-collection {
  touch-action: unset;
  overflow: scroll;

  display: inline-grid;
  grid-column-gap: 30px;
  grid-auto-flow: column;
  grid-template-columns: repeat(5, minmax(17.9%, 1fr));

  @media @tablet {
    grid-template-columns: repeat(auto-fill, minmax(30%, 1fr));
  }

  @media @mobile {
    grid-template-columns: repeat(auto-fill, minmax(48%, 1fr));
    grid-column-gap: 10px;
  }

  &:big-slide-item {
    display: grid;
    grid-column-gap: 30px;
  }

  &.big-slide-item[data-count="3"] {
    grid-template-columns: repeat(3, minmax(31.5%, 1fr));

    @media @mobile {
      grid-template-columns: repeat(auto-fill, minmax(48%, 1fr));
      grid-column-gap: 10px;
    }
  }

  &.big-slide-item[data-count="4"] {
    grid-template-columns: repeat(4, minmax(23%, 1fr));

    @media @tablet {
      grid-template-columns: repeat(auto-fill, minmax(30%, 1fr));
    }

    @media @mobile {
      grid-template-columns: repeat(auto-fill, minmax(48%, 1fr));
      grid-column-gap: 10px;
    }
  }
  .glide__slide {
    border-radius: 8px;
    min-height: 290px;
    @media only screen and (max-width: 1024px) {
      min-height: 215px;
    }
    @media only screen and (max-width: 768px) {
      min-height: 280px;
    }
    @media only screen and (max-width: 600px) {
      min-height: 270px;
    }
    @media only screen and (max-width: 480px) {
      min-height: 230px;
    }
    @media only screen and (max-width: 360px) {
      min-height: 215px;
    }
  }
}
.btn-nav-cat {
  z-index: @layer;
  transform: translate(0%, -50%);
  background-color: transparent;
  padding: unset;
  cursor: pointer;
  width: 50px;
  @media @mobile {
    width: 30px;
  }
}
.icon {
  display: inline-block;
  width: 47px;
  height: 19px;
  background-size: cover;
}
.icon-next {
  background-image: url(../assets/images/arrow-right.png);
}
.icon-prev {
  background-image: url(../assets/images/arrow-left.png);
  transform: rotate(180deg);
}
.collection-carousel-items {
  position: relative;
  @media @mobile {
    padding: 0;
  }
}

.hide-slider-nav {
  display: none;
  @media @tablet {
    display: block;
  }
}

::-webkit-scrollbar {
  display: none;
}
.collections {
  &__template {
    .section-heading {
      font-size: 18px;
      text-align: left;
      color: #41434c;
      margin-bottom: 6px;
      @media @mobile {
        font-size: 14px;
        margin-bottom: 6px;
        margin-left: 9px;
      }
    }
  }
  &__content {
    top: 92%;
    position: absolute;
    display: flex;
    width: 100%;
    left: 50%;
    transform: translate(-50%, -50%);
    /* flex-direction: column; */
    /* justify-content: center; */
    /* align-items: center; */
    /* opacity: 0; */
    transition: all 0.5s;
    background: transparent linear-gradient(180deg, transparent, #000) 0 0
      no-repeat padding-box;
    color: #ffffff;
    border-radius: 8px;
  }
}

.card-container {
  margin: 0;
}
.top-items {
  padding: 14px;
  border-radius: @BorderRadius;
  background: transparent;
}

.title-block {
  display: flex;
  align-items: baseline;
  text-transform: uppercase;
  margin: 0px 0 15px 0;
}
.ukt-links {
  margin-left: auto;
  right: 15px;
  text-transform: uppercase;
  position: relative;
}
.brands {
  justify-content: left;
}

// Horizontal View CSS

.collection-items {
  position: relative;
  @media @mobile {
    padding: 0;

    // a {
    //   margin-right: 0 !important;
    // }
  }
  .carousel-cell {
    cursor: pointer;
    height: 100%;
    display: flex;
    width: 100%;
    align-items: center;
    background-color: #f2f2f2;
    border-radius: 8px;
    box-shadow: 9px 6px 10px rgba(0, 0, 0, 0.2);
    position: relative;
    /deep/ .fy__img {
      border-radius: 8px;
      width: 100%;
      height: 100%;
      // box-shadow: 9px 6px 10px rgba(0, 0, 0, 0.2);
      @media @mobile {
        height: unset;
      }
    }

    .carousel-details {
      bottom: 0px;
      position: absolute;
      display: flex;
      width: 100%;
      left: 50%;
      height: 80px;
      background: transparent linear-gradient(180deg, transparent, #000) 0 0
        no-repeat padding-box;
      color: #fff;
      border-radius: 8px;
      /* padding: 20px 0 0 0; */
      box-sizing: border-box;
      left: 0;
      right: 0;
      .logo-wrapper {
      }
      .card-logo {
        /* position: absolute; */
        bottom: 30px;
        width: 50px;
        /* left: 50%; */
        /* transform: translate(-50%,-50%); */
        height: 50px;
        margin-left: 3px;
        /deep/ .fy__img {
          width: 50px;
          border-radius: 8px;
          @media @mobile {
            width: 40px;
            height: 40px;
            margin-left: 8px;
          }
        }
      }
      .collection_desc {
        font-size: 16px;
        margin-top: 18px;
        font-weight: 700;
        margin-left: 10px;
        color: #fff;
        width: 100%;
        justify-content: center;
        display: flex;
        @media @mobile {
          margin-left: 0;
        }
        .ukt-title {
          width: 94%;
          display: block;
          text-align: center;
          color: #fff;
          line-height: 20px;
          font-size: 16px;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
          text-overflow: ellipsis;
          overflow: hidden;
          display: -webkit-box;
          @media @mobile {
            font-size: 13px;
          }
        }
        .cl-img {
          width: 50px;
          left: 50%;
          transform: translate(-50%, 0%);
          height: 50px;
          position: relative;
        }
        .cl-content {
          white-space: normal !important;
          margin: 0 10px;
          width: 94%;
          box-sizing: border-box;
          @media @tablet {
            padding: 0 18px;
          }
          @media @mobile {
            padding: 0;
          }
          .card-count {
            padding: 0px;
            margin-top: 10px;
          }
        }
      }
    }
  }
}

.btn-nav-coll {
  position: absolute;
  top: 50%;
  z-index: @layer;
  transform: translate(0%, -50%);
  background-color: transparent;
  padding: unset;
  width: 50px;
  cursor: pointer;
  @media @mobile {
    width: 30px;
  }
}
.next-btn {
  right: 0px;
  @media @mobile {
    right: 20px;
  }
}
.prev-btn {
  left: 0px;
}
</style>
