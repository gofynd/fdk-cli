<template>
  <div class="section-main-container">
    <h2 v-if="settings.props.heading.value" class="section-heading">
      {{ settings.props.heading.value }}
    </h2>
    <div>
      <fdk-infinite-scrolling
        @loadmore="loadMoreWLData()"
        :loadingData="loading"
      >
        <div v-if="products.length > 0" class="grid-wrapper">
          <div class="group-cards">
            <div v-for="(product, index) in products" :key="`p-wl-${index}`">
              <fdk-link :link="`/product/${product.slug}`" class="wl-link">
                <fy-product-card
                  :isWishListPage="true"
                  :product="product"
                />
              </fdk-link>
            </div>
          </div>
        </div>
        <fdk-loader class="loader-ws" v-else-if="isLoading" />
        <fdk-empty-state
          v-else-if="products.length === 0 && isMounted"
          :title="'No wishlist items found'"
        ></fdk-empty-state>
      </fdk-infinite-scrolling>
    </div>
  </div>
</template>
<settings>
{
    "name":"infiniteWishlistListing",
    "label":"Wishlist page",
    "pages": ["wishlist"],
    "props":[
        {
            "type": "text",
            "id": "heading",
            "default": "",
            "label": "Wishlist List Heading"
        }
    ]
}
</settings>
<script>
import fyProductCard from "./../global/components/fy-product-card.vue";
export default {
  data() {
    return {
      products: [],
      isLoading: false,
      isMounted: false,
      page: { current: 0, has_next: true },
      context: {},
    };
  },
  props: ["settings", "apiSDK"],
  mounted() {
    this.isMounted = true;
    this.fetchWishlist();
  },
  components: {
    "fy-product-card": fyProductCard,
  },
  watch: {
    settings: function(newVal, oldVal) {},
  },
  methods: {
    loadMoreWLData() {
      this.fetchWishlist();
    },
    fetchWishlist() {
      if (this.page && this.page.has_next && !this.isLoading) {
        this.isLoading = true;
        let pageObj = {};
        pageObj.collectionType = "products";
        if (this.page.next_page) {
          pageObj.page = this.page.next_page; //NOTe: this is custom code for wishlist
        }
        this.$apiSDK.catalog.getFollowedListing(pageObj).then((data) => {
          this.page = data.page;
          data.items.map((item) => {
            item.follow = true;
          });
          this.products = [...this.products, ...data.items];
          this.isLoading = false;
        });
      }
    },
  },
};
</script>
<style lang="less" scoped>
.section-main-container {
  position: relative;
  padding-bottom: 50px;
  background-color: transparent;
}
.section-heading {
  padding: 20px 0 0 0;
  font-size: 30px;
  font-weight: 700;
  text-transform: uppercase;
  margin-bottom: 30px;
  text-align: left;
}
.wl-link {
  -webkit-tap-highlight-color: transparent;
}
.grid-wrapper {
  margin: 0 20px;
}
.group-cards {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(15%, 1fr));
  grid-auto-rows: auto;
  grid-gap: 2em;
}
@media screen and (max-width: 768px) {
  .group-cards {
    grid-template-columns: repeat(auto-fill, minmax(40%, 1fr));
    grid-gap: 0.5em;
  }
}
</style>
