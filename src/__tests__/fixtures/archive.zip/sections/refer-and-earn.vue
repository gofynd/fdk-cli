<template>
  <div
    class="section-main-container rne-container"
    v-if="isMounted && context && context.is_logged_in"
  >
    <div :class="{ 'place-holder': isLoading }">
      <fdk-link :link="'/profile/refer-earn'" v-if="showRnE">
        <whitesplash-image
          :src="banner_src"
          :sources="[
            { breakpoint: { max: 480 }, width: 600 },
            { breakpoint: { max: 768 }, width: 1280 },
            { breakpoint: { max: 1366 }, width: 1640 },
            { breakpoint: { max: 1920 }, width: 2300 },
          ]"
        />
      </fdk-link>
    </div>
  </div>
</template>
<settings>
{
    "name": "refer-and-earn",
    "label": "Refer And Earn",
    "props":[]
}
</settings>
<script>
import fyImage from "../global/components/common/whitesplash-image.vue";

export default {
  props: ["apiSDK", "context"],
  components: {
    "whitesplash-image": fyImage,
  },
  mounted() {
    this.isMounted = true;
    if (this.context.is_logged_in) {
      this.isLoading = true;
      this.fetchRewardsInfo();
    } else {
      this.isLoading = false;
    }
  },
  data() {
    return {
      isMounted: false,
      isLoading: false,
      showRnE: false,
      banner_src: "",
    };
  },
  methods: {
    fetchRewardsInfo() {
      this.$apiSDK.rewards
        .getUserReferralDetails()
        .then((res) => {
          if (!res.referral.active) {
            return;
          }
          this.banner_src = res.referral.banner_image.secure_url;
          this.showRnE = true;
        })
        .catch((err) => {
          console.log(err);
        })
        .finally(() => {
          this.isLoading = false;
        });
    },
  },
};
</script>
<style lang="less" scoped>
.rne-container {
  .place-holder {
    min-height: 150px;
  }
  /deep/ .fy__img {
    border-radius: 8px;
  }
}
</style>
