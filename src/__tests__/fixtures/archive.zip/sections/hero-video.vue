<template>
  <div
    :class="{
      'section-main-container': !settings.props.full_width.value,
      'full-width-section': settings.props.full_width.value,
    }"
  >
    <div class="video-container" :class="settings.props.size.value">
      <video
        ref="mp4video"
        style="width: 100%"
        :muted="settings.props.autoplay.value"
        :autoplay="settings.props.autoplay.value"
        :poster="settings.props.coverUrl.value"
        preload="auto"
        :controls="settings.props.showcontrols.value"
        v-if="
          settings.props.videoUrl.value && isMp4(settings.props.videoUrl.value)
        "
      >
        <source :src="settings.props.videoUrl.value" type="video/mp4" />
      </video>

      <div
        class="yt-video"
        ref="yt-video"
        v-if="isYoutube(settings.props.videoUrl.value)"
        :id="'yt-video-' + getYTVideoID(settings.props.videoUrl.value)"
        :data-videoid="getYTVideoID(settings.props.videoUrl.value)"
        :data-videometa="JSON.stringify(settings.props)"
      ></div>
      <div class="close-video-box" @click="closeVideo">
        <svg
          version="1.1"
          id="Layer_1"
          xmlns="http://www.w3.org/2000/svg"
          xmlns:xlink="http://www.w3.org/1999/xlink"
          x="0px"
          y="0px"
          viewBox="0 0 512 512"
          style="enable-background: new 0 0 512 512"
          xml:space="preserve"
        >
          <path
            d="M278.6,256l68.2-68.2c6.2-6.2,6.2-16.4,0-22.6c-6.2-6.2-16.4-6.2-22.6,0L256,233.4l-68.2-68.2c-6.2-6.2-16.4-6.2-22.6,0
          c-3.1,3.1-4.7,7.2-4.7,11.3c0,4.1,1.6,8.2,4.7,11.3l68.2,68.2l-68.2,68.2c-3.1,3.1-4.7,7.2-4.7,11.3c0,4.1,1.6,8.2,4.7,11.3
          c6.2,6.2,16.4,6.2,22.6,0l68.2-68.2l68.2,68.2c6.2,6.2,16.4,6.2,22.6,0c6.2-6.2,6.2-16.4,0-22.6L278.6,256z"
          />
        </svg>
      </div>
    </div>
    <div
      class="overlay animated fadeIn"
      v-if="showPoster"
      :style="`background: #ccc url(${settings.props.coverUrl.value}) center center / cover no-repeat;`"
    >
      <div class="overlay__content center-center">
        <div class="overlay__text">
          <h2
            v-if="settings.props.heading.value"
            :style="{ color: settings.props.heading_color.value }"
          >
            {{ settings.props.heading.value }}
          </h2>
          <p
            v-if="settings.props.subHeading.value"
            :style="{ color: settings.props.subheading_color.value }"
          >
            <span>{{ settings.props.subHeading.value }} </span>
          </p>
        </div>
        <div @click="playVideo" class="play-button">
          <svg
            version="1.1"
            id="Layer_1"
            xmlns="http://www.w3.org/2000/svg"
            xmlns:xlink="http://www.w3.org/1999/xlink"
            x="0px"
            y="0px"
            viewBox="0 0 512 512"
            style="enable-background: new 0 0 512 512"
            xml:space="preserve"
          >
            <g>
              <path
                d="M256,48C141.1,48,48,141.1,48,256c0,114.9,93.1,208,208,208c114.9,0,208-93.1,208-208C464,141.1,370.9,48,256,48z
                  M339.8,259.9l-137.2,83c-2.9,1.8-6.7-0.4-6.7-3.9V173c0-3.5,3.7-5.7,6.7-3.9l137.2,83C342.7,253.8,342.7,258.2,339.8,259.9z"
              />
            </g>
          </svg>
        </div>
        <button
          class="btn"
          v-if="settings.props.ctaLink.value || settings.props.ctaText.value"
        >
          <fdk-link :link="settings.props.ctaLink.value">
            {{ settings.props.ctaText.value }}
          </fdk-link>
        </button>
      </div>
    </div>
  </div>
</template>
<settings>
{
  "name": "heroVideoBanner",
  "label": "Hero Video",
  "props": [
    {
      "id": "videoUrl",
      "type": "url",
      "label": "Video URL",
      "default": ""
    },
    {
      "type":"checkbox",
      "id":"full_width",
      "default": false,
      "label": "Full width",
      "info":"Check to allow items to take entire width of the viewport"
    },
    {
      "id": "coverUrl",
      "type": "image_picker",
      "label": "Video Cover Image URL",
      "default": ""
    },
    {
      "type": "checkbox",
      "id": "autoplay",
      "default": false,
      "label": "Autoplay",
      "info":"Check to enable autoplay of video"
    },
    {
      "type": "checkbox",
      "id": "showcontrols",
      "default": false,
      "label": "Show Controls on Video",
      "info":"Check to show controls on video"
    },
     
     {
      "type": "select",
      "id": "size",
      "options": [
        {
          "value": "small",
          "text": "Small"
        },
        {
          "value": "medium",
          "text": "Medium"
        },
        {
          "value": "large",
          "text": "Large"
        }
      ],
      "default": "small",
      "label": "Video Height",
      "info":"Height of Video"
    },
    {
      "type": "text",
      "id": "heading",
      "default": "",
      "label": "Heading"
    },
      {
      "type":"color",
      "id":"heading_color",
      "default":"#000",
      "label":"Headin Text Color"
    },
    {
      "type": "text",
      "id": "subHeading",
      "default": "",
      "label": "Sub-heading"
    },
   {
      "type":"color",
      "id":"subheading_color",
      "default":"#000",
      "label":"Subheading Text Color"
    },
    {
      "type": "url",
      "id": "ctaLink",
      "default": "",
      "label": "Redirect Link"
    },
    {
      "type": "text",
      "id": "ctaText",
      "default": "ShopNow",
      "label": "Button Text"
    }
  ]
}
</settings>
<style scoped lang="less">
.section-main-container {
  background-color: #ffffff;
}
.full-width-section {
  background-color: #ffffff;
}

.btn {
  border: 0;
  background: none;
  a {
    display: inline-block;
    font-size: 14px;
    width: 100%;
    text-align: center;
    cursor: pointer;
    font-weight: 700;
    text-transform: uppercase;
    -webkit-appearance: none;
    -webkit-border-radius: 0;
    padding: 10px 40px;
    letter-spacing: 1px;
    color: inherit;
    width: 200px;
    border-width: 2px;
    border-color: inherit;
    background-color: transparent;
    border-style: solid;
    @media (min-width: 320px) and (max-width: 768px) {
      width: 150px;
    }
  }
}
.btn:hover {
  filter: invert(1);
}
.video-container {
  position: relative;
  z-index: 1;
  display: flex;
  .close-video-box {
    background: white;
    position: absolute;
    top: 10px;
    right: 10px;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    svg {
      width: 30px;
      height: 30px;
      cursor: pointer;
    }
  }
}

.center-overlay {
  left: unset;
  right: unset;
  align-items: center;
  text-align: center;
}

.overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  // transform: translate(-50%, -50%);
  z-index: 2;
  display: flex;
  justify-content: center;
  align-items: center;
  &__content {
    display: flex;
    flex-direction: column;
    height: 120px;
    padding: 20px;
    justify-content: center;
    align-items: center;
    position: absolute;
    max-width: 350px;
    &.center-center {
      top: unset;
      bottom: unset;
      text-align: center;
      .center-overlay();
    }
  }
  &__text {
    text-align: center;
    h2 {
      font-size: 40px;
      font-weight: 700;
      @media @mobile {
        font-size: 25px;
      }
      margin-bottom: 10px;
    }
    p {
      font-size: 20px;
      @media @mobile {
        font-size: 16px;
      }
      margin-bottom: 10px;
    }
  }
  .play-button {
    svg {
      width: 40px;
      height: 40px;
      cursor: pointer;
      fill: #000000;
    }
    margin-bottom: 18px;
  }
}
</style>

<script>
// import turbtn from './../global/components/tur-button';
export default {
  components: {
    // 'tur-button': turbtn,
  },
  props: ["settings"],
  watch: {
    settings(n, o) {
      if (JSON.stringify(n) !== JSON.stringify(o)) {
        this.showPoster = !n.settings.props.autoplay.value;
        this.removeYTScript();
        this.$nextTick(() => {
          this.loadYTScript();
        });
      }
    },
  },
  mounted() {
    this.showPoster = !this.settings.props.autoplay.value;
    this.loadYTScript();
  },
  data: function () {
    return {
      // url: ""
      showPoster: true,
    };
  },
  methods: {
    loadYTScript() {
      var self = this;
      let nodes = document.querySelectorAll("[data-ytscript]");
      if (nodes.length === 0) {
        var tag = document.createElement("script");
        tag.src = "https://www.youtube.com/iframe_api";
        tag.dataset.ytscript = "true";
        var firstScriptTag = document.getElementsByTagName("script")[0];
        firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
        tag.onload = () => {
          if (!window.onYouTubeIframeAPIReady) {
            window.onYouTubeIframeAPIReady = function () {
              setTimeout(self.onYouTubeIframeAPIReady.bind(self), 500);
            };
          } else {
            setTimeout(self.onYouTubeIframeAPIReady.bind(self), 500);
          }
        };
      } else {
        if (window.onYouTubeIframeAPIReady) {
          setTimeout(self.onYouTubeIframeAPIReady.bind(self), 500);
        }
      }
    },
    removeYTScript() {
      var players = window.players;
      if (players) {
        Object.keys(players).forEach((item) => {
          players[item].inst && players[item].inst.destroy();
        });
        window.players = null;
      }
      let nodes = document.querySelectorAll("[data-ytscript]");

      if (nodes.length > 0) {
        nodes.forEach((element) => {
          element.parentNode.removeChild(element);
        });
      }
      if (typeof YT !== "undefined") {
        window.YT = undefined;
      }
    },
    isMp4(url) {
      if (!url) {
        return false;
      }
      let ext = url.split(".").pop() || "";
      if (ext && ext.toLowerCase() === "mp4") {
        return true;
      } else {
        return false;
      }
    },
    isYoutube(url) {
      if (url) {
        let urlObj = new URL(url);

        if (
          urlObj.host.includes("youtu.be") ||
          urlObj.host.includes("youtube.com")
        ) {
          return true;
        }
      }

      return false;
    },
    playMp4() {
      this.showPoster = false;
      this.$refs.mp4video.play();
    },
    playYT() {
      this.showPoster = false;
      let videoID = this.$refs["yt-video"].dataset.videoid;
      var p = window.players;
      p[videoID].inst.playVideo();
    },
    playVideo() {
      if (this.isMp4(this.settings.props.videoUrl.value)) {
        this.playMp4();
      } else {
        this.playYT();
      }
    },
    stopMp4() {
      this.$refs.mp4video.pause();
      this.$refs.mp4video.currentTime = 0;
      this.$refs.mp4video.setAttribute("data-icon", "P");
    },
    stopYT() {
      let videoID = this.$refs["yt-video"].dataset.videoid;
      var p = window.players;
      p[videoID].inst.pauseVideo();
      p[videoID].inst.seekTo(0);
    },
    closeVideo() {
      this.showPoster = true;
      if (this.isMp4(this.settings.props.videoUrl.value)) {
        this.stopMp4();
      } else {
        this.stopYT();
      }
    },
    getYTVideoID(url) {
      let urlObj = new URL(url);
      let searchParams = urlObj.searchParams;
      let v = searchParams.get("v");
      if (urlObj.host.includes("youtu.be")) {
        v = urlObj.pathname.split("/").pop();
      }
      return v;
    },
    onYouTubeIframeAPIReady() {
      let ytVideos = document.querySelectorAll(".yt-video");

      window.players = {};
      let players = window.players;
      for (let i = 0; i < ytVideos.length; i++) {
        let node = ytVideos[i];
        let videoID = node.dataset.videoid;
        if (players[videoID]) {
          continue;
        }

        players[videoID] = {};

        let videoMeta = JSON.parse(node.dataset.videometa);
        let controls = videoMeta.showcontrols.value;
        let qautoplay = videoMeta.autoplay.value,
          qcontrols = 1,
          qmute = videoMeta.autoplay.value;

        if (!controls) {
          qcontrols = 0;
        }

        players[videoID].onReady = function (e) {
          if (qmute) {
            e.target.mute();
          }
          if (qautoplay) {
            e.target.playVideo();
          }
        };
        players[videoID].onStateChange = function (event) {
          var p = window.players;
          if (event.data == YT.PlayerState.ENDED) {
            p[videoID].inst.seekTo(0);
            p[videoID].inst.playVideo();
          }
        };
        players[videoID].inst = new YT.Player("yt-video-" + videoID, {
          videoId: videoID, // The video id.
          width: "100%",
          height: "100%",
          playerVars: {
            autoplay: qautoplay,
            controls: qcontrols,
            modestbranding: 1,
            loop: 1,
            fs: 0,
            cc_load_policty: 0,
            iv_load_policy: 3,
            origin: document.location.origin,
          },
          events: {
            onReady: players[videoID].onReady,
            onStateChange: players[videoID].onStateChange,
          },
        });
      }
    },
  },
};
</script>
