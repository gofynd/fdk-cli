<template>
  <div class="section-main-container">
    <fdk-infinite-scrolling @loadmore="loadMoreData()" :loadingData="loading">
      <div v-if="products.length > 0">
        <div class="banner text-spacing">
          <div v-if="settings.props.heading.value" class="title">
            {{ settings.props.heading.value }}
          </div>
        </div>
        <div class="product-container">
          <fdk-link
            v-for="(product, index) in products"
            :key="index"
            :link="`/product/${product.slug}`"
            target="_blank"
          >
            <product-card
              :product="product"
              class="infinite-list"
            ></product-card>
          </fdk-link>
        </div>
      </div>
      <fdk-loader v-else-if="isLoading" />
      <div v-else class="product-container placeholder-cards">
        <placeholder-product-card
          v-for="index in 10"
          :key="index"
          :name="`Product ${index}`"
          :brand="`Brand ${index}`"
        />
      </div>
    </fdk-infinite-scrolling>
  </div>
</template>
<settings>
{
    "name":"infiniteProductListing",
    "label":"Recomended Products",
    "props":[
        {
            "type": "text",
            "id": "heading",
            "default": "",
            "label": "Product List Heading"
        }
    ]
}
</settings>
<script>
import productCard from "./../global/components/fy-product-card.vue";
import { detectMobileWidth } from "./../helper/utils";
import placeholderProductCardVue from "../global/components/sections/placeholder-product-card.vue";

export default {
  data() {
    return {
      products: this.serverProps?.products || [],
      isLoading: false,
      page: this.serverProps?.page || { current: 0, has_next: true },
      context: {},
      isMobile: false,
    };
  },
  props: ["settings", "apiSDK", "serverProps"],
  initializeServerProps({ apiSDK }) {
    return apiSDK.catalog
      .getHomeProducts({
        pageSize: 20,
      })
      .then(( data ) => {
        return {
          products: data.items,
          page: data.page,
        };
      })
      .catch((err) => {
        console.log(err);
      });
  },
  mounted() {
    if (this.products.length === 0) {
      this.fetchInfiniteProduct();
    }
    this.isMobile = detectMobileWidth();
  },
  components: {
    "product-card": productCard,
    "placeholder-product-card": placeholderProductCardVue,
  },
  methods: {
    loadMoreData() {
      this.fetchInfiniteProduct();
    },
    getPrice(product, key) {
      if (product && product.price) {
        return product.price[key].min !== product.price[key].max
          ? product.price[key].min + " - " + product.price[key].max
          : product.price[key].min;
      }
    },
    getProductLink(item) {
      this.$router.push({
        path: "/product/" + item.slug,
      });
    },
    fetchInfiniteProduct() {
      /*
        case 1: page object is undefined
        case 2:  page object does not have item_total ==> item_total is undefined
        case 3: item_total > 0 && item_total > products.length
      */
      let item_total = this.page && this.page.item_total;
      if (
        (typeof this.page === "undefined" ||
          typeof item_total === "undefined" ||
          (item_total > 0 && item_total > this.products.length)) &&
        !this.isLoading
      ) {
        this.isLoading = true;
        let options = {
          pageSize: 20,
          pageId: (this.page && this.page.next_id) || "",
        };
        this.$apiSDK.catalog
          .getHomeProducts(options)
          .then((data) => {
            this.page = data.page;
            this.products = [...this.products, ...data.items];
            this.isLoading = false;
          })
          .catch((err) => {
            this.isLoading = false;
            console.log(err);
          });
      }
    },
  },
};
</script>
<style lang="less" scoped>
.infinite-listing {
  @media @mobile {
    padding: 0 10px;
    box-sizing: border-box;
  }
}
.product-container {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(16%, 1fr));
  grid-auto-rows: auto;
  grid-gap: 4em;
  @media @tablet {
    grid-template-columns: repeat(auto-fill, minmax(40%, 1fr)) !important;
    grid-gap: 0.5em !important;
  }
}

@media @mobile {
  .product-container {
    grid-template-columns: repeat(auto-fill, minmax(40%, 1fr)) !important;
    grid-gap: 0.5em !important;
  }
}
.banner {
  color: #41434c;
  .title {
    font-weight: 700;
    font-size: 18px;
    text-transform: uppercase;
    @media @mobile {
      font-size: 14px;
    }
  }
}
.text-spacing {
  margin: 1px 0 15px 0;
}
.placeholder-cards {
  grid-gap: 1em;
}
</style>
