<template>
  <div class="section-main-container">
    <div class="collection__template">
      <fdk-loader v-if="isLoading"></fdk-loader>
      <template v-if="!isLoading && categories.length > 0">
        <div class="card-container">
          <div class="top-items">
            <div class="banner text-spacing">
              <div v-if="settings.props.heading.value" class="title">
                {{ settings.props.heading.value }}
              </div>
              <fdk-link
                v-if="settings.props.view_all.value"
                :link="'/categories/'"
                class="ukt-links bold-sm"
                >VIEW ALL</fdk-link
              >
            </div>
            <group-list
              v-if="settings.props.layout.value === 'grid'"
              :cardlist="getCategories"
              :cardtype="'CATEGORIES'"
              :itemcount="settings.props.item_count.value"
            ></group-list>
            <div
              class="category-border"
              v-if="settings.props.layout.value === 'horizontal'"
            >
              <div class="category-items">
                <div :class="'glide' + _uid" ref="glide">
                  <div data-glide-el="track" class="glide__track">
                    <div
                      class="glide__slides ssr-slides-box"
                      :data-count="settings.props.item_count.value"
                      :class="{
                        'big-slide-item': settings.props.item_count.value < 5,
                      }"
                    >
                      <div
                        class="glide__slide def-margin"
                        v-for="(category, index) in getCategories"
                        :key="index"
                      >
                        <fdk-link
                          :link="`/products/?category=${category.slug}`"
                          class="item"
                        >
                          <div class="carousel-cell">
                            <whitesplash-image
                              v-if="
                                category &&
                                  category.banners &&
                                  category.banners.portrait &&
                                  category.banners.portrait.url
                              "
                              :src="category.banners.portrait.url"
                              class="imgClass"
                            />
                            <img
                              v-else
                              src="./../assets/images/placeholder.png"
                            />

                            <div class="carousel-details">
                              <p class="title">{{ category.name }}</p>
                            </div>
                          </div>
                        </fdk-link>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  class="arrows"
                  :class="{
                    'hide-slider-nav':
                      categories.length <= glideOptions.perView,
                  }"
                >
                  <div
                    class="prev-btn btn-nav-cat"
                    ref="prevArrow"
                    @click="prevSlide"
                  >
                    <img src="../assets/images/arrow-left.png" />
                  </div>
                  <div
                    class="next-btn btn-nav-cat"
                    ref="nextArrow"
                    @click="nextSlide"
                  >
                    <img src="../assets/images/arrow-right.png" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </template>
      <template v-else-if="!isLoading && categories.length === 0">
        <placeholder-items
          :count="10"
          type="collection-2"
          text="Category"
          :layout="settings.props.layout.value"
        />
      </template>
    </div>
  </div>
</template>
<settings>
{
  "name": "categoryListPage",
  "label": "Category List ",
  "props": [
    {
      "type": "text",
      "id": "heading",
      "default": "",
      "label": "Category List Heading"
    },
    {
      "id": "layout",
      "type": "select",
      "options": [
        {
          "value": "grid",
          "text" : "Grid View"
        },
        {
          "value": "horizontal",
          "text" : "Horizontal View"
        }
      ],
      "default": "horizontal",
      "label": "Layout",
      "info":"Alignment of content"
    },
     {
      "type": "range",
      "id": "item_count",
      "min": 3,
      "max": 5,
      "step": 1,
      "unit": "",
      "label": "Items per row",
      "default": 5,
      "info": "Maximum items allowed per row"
    },
    {
      "type":"checkbox",
      "id":"view_all",
      "default": false,
      "label": "Show View All",
      "info":"Check to show View All Button"
    }
  ]
}

</settings>
<script>
import groupList from "./../global/components/group-list.vue";
import { isBrowser, isNode } from "browser-or-node";
import { detectMobileWidth } from "../helper/utils";
import placeholderImage from "./../assets/images/placeholder.png";
import fyImage from "./../global/components/common/whitesplash-image.vue";
import placeholderItemsVue from "../global/components/sections/placeholder-items.vue";
import uniqBy from "lodash/uniqBy";
import Glide from "@glidejs/glide";
import "../../node_modules/@glidejs/glide/dist/css/glide.core.min.css";
import "../../node_modules/@glidejs/glide/dist/css/glide.theme.min.css";

export default {
  props: ["settings", "apiSDK", "serverProps"],
  data() {
    return {
      categories: this.serverProps || [],
      isMounted: false,
      isLoading: false,
      glideOptions: {
        type: "slider",
        bound: true,
        rewind: false,
        startAt: 0,
        gap: 30,
        perView: this.settings.props.item_count.value,
        breakpoints: {
          768: {
            perView: 3,
          },
          600: {
            perView: 2,
          },
          480: {
            perView: 2,
          },
        },
      },
      carouselHandle: null,
    };
  },
  components: {
    "group-list": groupList,
    "whitesplash-image": fyImage,
    "placeholder-items": placeholderItemsVue,
  },
  computed: {
    imageWidth: function() {
      let w = 312;
      if (isBrowser) {
        if (window.screen.width >= 1280) {
          w = 275;
        } else if (window.screen.width >= 768) {
          w = 312;
        } else if (window.screen.width > 360) {
          w = 184;
        } else if (window.screen.width <= 360) {
          w = 160;
        }
      }
      return w;
    },
    getCategories() {
      return uniqBy(this.categories, (e) => {
        return e.uid;
      });
    },
  },
  initializeServerProps({ apiSDK, settings, route }) {
    const params = Object.assign({}, route.params);
    return apiSDK.catalog.getCategories(params).then((data) => {
      const raw_data = data.data;
      let categories = [];
      Object.keys(raw_data).forEach((slug) => {
        let categoryData = raw_data[slug].items;
        let firstChilds = [];
        categoryData.forEach((item) => {
          firstChilds = [...firstChilds, ...item.childs];
        });
        let secondChilds = [];
        firstChilds.forEach((item) => {
          secondChilds = [...secondChilds, ...item.childs];
        });
        categories = [...categories, ...secondChilds];
      });
      return categories;
    });
  },
  watch: {
    settings(newVal, oldVal) {
      if (
        newVal.props.layout.value != oldVal.props.layout.value ||
        newVal.props.item_count.value !== oldVal.props.item_count.value ||
        this.isBlocksChanged(newVal.blocks, oldVal.blocks)
      ) {
        this.categories = [];
        this.settings = newVal;
        this.cleanupComponent();
        this.initializeComponent();
      }
    },
  },
  mounted() {
    this.initializeComponent();
  },
  beforeDestroy() {
    this.cleanupComponent();
  },
  methods: {
    detectMobileWidth,
    isBlocksChanged(newBlocks, oldBlocks) {
      return JSON.stringify(newBlocks) === JSON.stringify(oldBlocks)
        ? false
        : true;
    },
    cleanupComponent() {
      if (isBrowser && this.carouselHandle) {
        this.carouselHandle.destroy();
        this.carouselHandle = null;
      }
    },
    checkisBrowser() {
      return isBrowser;
    },
    prevSlide() {
      // item_count variable holds the value of number of items to show
      let item_count = this.settings.props.item_count.value;

      if (detectMobileWidth()) {
        if (this.carouselHandle.index - 1 >= 0) {
          this.carouselHandle.go(`=${this.carouselHandle.index - 1}`);
        }
      } else {
        if (this.carouselHandle.index - item_count >= 0) {
          this.carouselHandle.go(`=${this.carouselHandle.index - item_count}`);
        } else {
          this.carouselHandle.go(`<<`);
        }
      }
    },
    nextSlide() {
      let item_count = this.settings.props.item_count.value - 1;
      if (detectMobileWidth()) {
        ///this.categories.length has to be replaced by the length of items in carousel
        if (this.carouselHandle.index + 1 < this.categories.length - 1) {
          this.carouselHandle.go(`=${this.carouselHandle.index + 1}`);
        }
      } else {
        if (this.carouselHandle.index + item_count < this.categories.length) {
          this.carouselHandle.go(`=${this.carouselHandle.index + item_count}`);
        } else {
          this.carouselHandle.go(`>>`);
        }
      }
    },
    initCarousel() {
      //if IsNode OR Layout is horizontal(optional flag) OR carouselHandle(carousel) is not already initialized
      if (
        !isBrowser ||
        this.settings.props.layout.value !== "horizontal" ||
        this.carouselHandle
      ) {
        return;
      }
      if (!this.$refs.glide) {
        setTimeout(() => {
          this.initCarousel();
        }, 1000);
        return;
      }
      // waiting for data to render, hence nextTick
      this.$nextTick(() => {
        try {
          if (window.screen.width <= 480) {
            this.glideOptions.gap = 10;
          }
          if (this.categories.length <= this.glideOptions.perView) {
            this.glideOptions.type = "slider";
          } else {
            this.glideOptions.type = "carousel";
          }
          this.carouselHandle = new Glide(this.$refs.glide, this.glideOptions);
          this.carouselHandle.on("mount.after", function () {
            let elt = document.querySelector(".ssr-slides-box");
            elt.style.display = "flex";
            elt.style["grid-column-gap"] = 0;
            elt.style['touch-action'] = "pan-Y";
            elt.style.overflow = "hidden";
          });
          this.carouselHandle.mount();
        } catch (ex) {
          //There is an exception logged, due to rendering delay, so this try,catch is required
        }
      });
    },
    initializeComponent() {
      if (window.screen.width > 600 && window.screen.width <= 768) {
        this.glideOptions.perView = 3;
      } else if (window.screen.width <= 600) {
        this.glideOptions.perView = 2;
      }
      this.glideOptions.perView = this.settings.props.item_count.value;
      if (this.categories.length == 0) {
        this.isLoading = true;
        this.fetchCategories();
      } else {
        this.isMounted = true;
        this.initCarousel();
      }
    },
    replaceByDefault(e) {
      e.target.src = placeholderImage;
    },
    fetchCategories() {
      const params = Object.assign({}, this.$route.params);
      this.$apiSDK.catalog.getCategories(params).then((data) => {
        let raw_data = data.data;
        Object.keys(raw_data).forEach((slug) => {
          let categoryData = raw_data[slug].items;
          let firstChilds = [];
          categoryData.forEach((item) => {
            firstChilds = [...firstChilds, ...item.childs];
          });
          let secondChilds = [];
          firstChilds.forEach((item) => {
            secondChilds = [...secondChilds, ...item.childs];
          });
          this.categories = [...this.categories, ...secondChilds];
          this.isMounted = true;
          this.isLoading = false;
          this.initCarousel();
        });
      });
    },
  },
};
</script>

<style lang="less" scoped>
/deep/.imgClass {
  width: 100%;
  .fy__img {
    border-radius: 8px;
    height: 100%;
    width: 100%;
  }
}
.glide__slide {
  height: auto;
  a {
    display: flex;
    height: 100%;

    min-height: 290px;
    @media only screen and (max-width: 1024px) {
      min-height: 215px;
    }
    @media only screen and (max-width: 768px) {
      min-height: 280px;
    }
    @media only screen and (max-width: 600px) {
      min-height: 270px;
    }
    @media only screen and (max-width: 480px) {
      min-height: 230px;
    }
    @media only screen and (max-width: 360px) {
      min-height: 215px;
    }
  }
}

.glide__slides.ssr-slides-box {
  touch-action: unset;
  overflow: scroll;

  display: grid;
  grid-column-gap: 30px;
  grid-auto-flow: column;
  grid-template-columns: repeat(auto-fill, minmax(17.9%, 1fr));

  @media @tablet {
    grid-template-columns: repeat(auto-fill, minmax(30%, 1fr));
  }

  @media @mobile {
    grid-template-columns: repeat(auto-fill, minmax(48%, 1fr));
    grid-column-gap: 10px;
  }

  &:big-slide-item {
    display: grid;
    grid-column-gap: 30px;
  }

  &.big-slide-item[data-count="3"] {
    grid-template-columns: repeat(auto-fill, minmax(31.5%, 1fr));

    @media @mobile {
      grid-template-columns: repeat(auto-fill, minmax(48%, 1fr));
      grid-column-gap: 10px;
    }
  }

  &.big-slide-item[data-count="4"] {
    grid-template-columns: repeat(auto-fill, minmax(23%, 1fr));

    @media @tablet {
      grid-template-columns: repeat(auto-fill, minmax(30%, 1fr));
    }

    @media @mobile {
      grid-template-columns: repeat(auto-fill, minmax(48%, 1fr));
      grid-column-gap: 10px;
    }
  }

  .glide__slide {
    border-radius: 8px;
    min-height: 290px;
    @media only screen and (max-width: 1024px) {
      min-height: 215px;
    }
    @media only screen and (max-width: 768px) {
      min-height: 280px;
    }
    @media only screen and (max-width: 600px) {
      min-height: 270px;
    }
    @media only screen and (max-width: 480px) {
      min-height: 230px;
    }
    @media only screen and (max-width: 360px) {
      min-height: 215px;
    }
  }
}
.btn-nav-cat {
  z-index: @layer;
  transform: translate(0%, -50%);
  background-color: transparent;
  padding: unset;
  cursor: pointer;
  width: 50px;
  @media @mobile {
    width: 30px;
  }
}
.icon {
  display: inline-block;
  width: 47px;
  height: 19px;
  background-size: cover;
}
.icon-next {
  background-image: url(../assets/images/arrow-right.png);
}
.icon-prev {
  background-image: url(../assets/images/arrow-left.png);
  transform: rotate(180deg);
}
.collection-carousel-items {
  position: relative;
  @media @mobile {
    padding: 0;
  }
}

.hide-slider-nav {
  display: none;
  @media @tablet {
    display: block;
  }
}

/deep/.imgClass {
  .fy__img {
    border-radius: 8px;
    box-shadow: 9px 6px 10px rgba(0, 0, 0, 0.2);
  }
}

::-webkit-scrollbar {
  display: none;
}
.card-container {
  margin: 0;
}
.top-items {
  padding: 14px;
  border-radius: @BorderRadius;
  background: transparent;
}

.title-block {
  display: flex;
  margin-bottom: 4px;
  margin-left: 10px;
  align-items: baseline;
}
.ukt-links {
  margin-left: auto;
  right: 15px;
  text-transform: uppercase;
  position: relative;
}
.categories {
  justify-content: left;
}
.text-spacing {
  margin: 1px 0 15px 0;
  @media @mobile {
    margin: 0 0 10px 0;
  }
}
.banner {
  display: flex;
  justify-content: space-between;
  color: #41434c;
  text-transform: uppercase;
  .title {
    font-weight: 700;
    font-size: 18px;
    @media @mobile {
      font-size: 14px;
    }
  }
}
.category-items {
  position: relative;
  @media @mobile {
    padding: 0;
  }
  .carousel-cell {
    cursor: pointer;
    height: auto;
    width: 100%;
    // margin-right: 10px;
    // @media @mobile {
    //   margin-right: 10px;
    // }
    position: relative;
    img {
      border-radius: 5px;
      border: 1px solid #aba3a333;
      // height: 100%;
      // height: 350px;
      width: 100%;
      // @media @mobile {
      //   height: 248px;
      // }
    }
    .carousel-details {
      bottom: 0px;
      height: 130px;
      background: transparent
        linear-gradient(180deg, #00000000 0%, #000000 100%) 0% 0% no-repeat
        padding-box;
      border-radius: 3px;
      opacity: 1;
      width: 100%;
      color: white;
      font-size: 12px;
      border-bottom-left-radius: 5px;
      border-bottom-right-radius: 5px;
      position: absolute;
      @media @mobile {
        width: 100%;
      }
      .title {
        font-weight: 700;
        padding: 10px;
        bottom: 0;
        width: 90%;
        text-align: center;
        display: inline-block;
        letter-spacing: 0;
        color: #fafafa;
        opacity: 1;
        position: absolute;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
    }
  }
}

// Horizontal View CSS

// .slick-slide img {
//   display: unset !important;
// }

.btn-nav-cat {
  position: absolute;
  top: 50%;
  z-index: @layer;
  transform: translate(0%, -50%);
  background-color: transparent;
  padding: unset;
  cursor: pointer;
  width: 50px;
  @media @mobile {
    width: 30px;
  }
}
.next-btn {
  right: 0;
  @media @mobile {
    right: 15px;
  }
}
.prev-btn {
  left: 0;
}

.item {
  &__image {
    position: relative;
    min-height: 300px;
    margin: 10px;
    @media @mobile {
      min-height: 230px;
    }
  }
  &__category-image {
    width: 100%;
    background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANsAAAFWAQMAAADaFHqxAAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAACBJREFUaN7twTEBAAAAwqD1T20LL6AAAAAAAAAAAADgbSa+AAGGhRJaAAAAAElFTkSuQmCC");
  }
  .overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 99.5%;
    background-color: black;
    opacity: 0.3;
    border-radius: 3px;
    &:hover {
      opacity: 0.7;
    }
  }
  &__logo {
    top: 70%;
    position: absolute;
    width: 50px;
    left: 50%;
    transform: translateX(-50%);
  }
  &__name {
    font-weight: bold;
    color: #41434c;
    font-size: 14px;
    text-align: center;
    @media @mobile {
      font-size: 12px;
    }
  }
}
</style>
