<template>
  <div v-if="isMounted && (context && context.is_logged_in) && showPoints" class="points-container noselect">
    <div class="points-right">
      <span class="credits">POINTS</span>
      <span>
        <fdk-link class="points" :link="'/profile/refer-earn'">
          <span class="rupee-symbol">&#8377;</span>
          <span id="point">{{ refPoints }}</span>
        </fdk-link>
      </span>
    </div>
  </div>
</template>
<settings>
{
    "name": "points",
    "label": "Points",
    "props":[]
}
</settings>
<script>
import fyImage from "../global/components/common/whitesplash-image.vue";

export default {
  props: ["apiSDK", "context"],
  components: {
    "whitesplash-image": fyImage,
  },
  mounted() {
    this.isMounted = true;
    if (this.context.is_logged_in) {
      this.isLoading = true
      this.fetchRewardsPoints();
    } else {
      this.isLoading = false
    }
  },
  data() {
    return {
      isMounted: false,
      isLoading: false,
      showPoints: false,
      refPoints: 0,
      banner_src:
        "",
    };
  },
  methods: {
    fetchRewardsPoints() {
      this.$apiSDK.rewards.getUserPoints()
        .then((res) => {
          this.refPoints = Math.floor(res.points)
          this.showPoints = true
        })
        .catch((err) => {
          console.log(err);
        })
    },
    
  },
};
</script>
<style lang="less" scoped>
.points-container {
  z-index: 2;
  padding: 0px 20px;
  margin: 10px 0;
  font-size: 17px;
  font-weight: bold;
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 35px;
  &:active {
    transition: none;
  }
  @media @tablet {
    margin: 5px 0;
  }
  @media @mobile {
    padding: 0px 10px;
  }
  .for-you {
    color: #41434c;
  }
  .points-right {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 2px;
    margin-left: auto;
  }
  .credits {
    font-weight: lighter;
    color: #929292;
    margin-right: 10px;
    font-size: 12px;
    margin-left: auto;
  }
  .points {
    background: #ffe36f;
    color: #41434c;
    border-radius: 5px;
    padding: 3px;
    min-width: 70px;
    font-size: 14px;
    min-height: 1.5em;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    .rupee-symbol {
      font-family: monospace;
      font-size: 12px;
      padding-right: 3px;
    }
  }

}


</style>
