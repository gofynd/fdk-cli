<template>
  <div class="section-main-container">
    <div class="collections-container">
      <div
        class="banner"
        :class="{
          'text-spacing':
            settings.props.heading.value &&
            settings.props.heading.value.length > 0,
        }"
      >
        <div
          v-if="
            settings.props.heading.value &&
            settings.props.heading.value.length > 0
          "
          class="title"
        >
          {{ settings.props.heading.value }}
        </div>
        <fdk-link
          v-if="settings.props.view_all.value"
          :link="'/collections/'"
          class="ukt-links bold-sm"
          >VIEW ALL</fdk-link
        >
      </div>
      <div class="section-container" v-if="settings.blocks.length > 0">
        <VueSlickCarousel ref="slick" v-bind="slickOptions">
          <fdk-link
            :link="block.props.slide_link.value"
            v-for="(block, index) in settings.blocks"
            :key="index"
            :class="`slide ${settings.props.slide_height.value}`"
          >
            <whitesplash-image
              v-if="block.props.image.value"
              class="imgClass"
              :src="block.props.image.value"
              :sources="[
                { breakpoint: { min: 1441, max: 1920 }, width: 1740 },
                { breakpoint: { min: 1367, max: 1440 }, width: 1320 },
                { breakpoint: { min: 1281, max: 1366 }, width: 1220 },
                { breakpoint: { min: 1025, max: 1280 }, width: 1050 },
                { breakpoint: { min: 769, max: 1024 }, width: 820 },
                { breakpoint: { min: 541, max: 768 }, width: 620 },
                { breakpoint: { min: 481, max: 540 }, width: 520 },
                { breakpoint: { min: 361, max: 480 }, width: 380 },
                { breakpoint: { max: 360 }, width: 340 },
              ]"
            />
            <fdk-placeholder v-else type="banner-1" />
          </fdk-link>
        </VueSlickCarousel>
        <div
          class="arrows"
          v-if="settings && settings.blocks && settings.blocks.length > 1"
        >
          <div
            class="prev-btn btn-nav-slider hide-mobile"
            ref="prevArrow"
            @click="prevSlide"
          >
            <img src="../assets/images/arrow-left.png" />
          </div>
          <div
            class="next-btn btn-nav-slider hide-mobile"
            ref="nextArrow"
            @click="nextSlide"
          >
            <img src="../assets/images/arrow-right.png" />
          </div>
        </div>
      </div>
      <div class="section-container" v-if="settings.blocks.length === 0">
        <VueSlickCarousel ref="slick" v-bind="slickOptions">
          <fdk-link
            :link="`#`"
            v-for="(block, index) in settings.preset.blocks"
            :key="index"
            :class="` ${settings.props.slide_height.value}`"
          >
            <fdk-placeholder type="banner-1" />
          </fdk-link>
        </VueSlickCarousel>
        <div class="arrows" v-if="settings.preset.blocks.length > 1">
          <div
            class="prev-btn btn-nav-slider hide-mobile"
            ref="prevArrow"
            @click="prevSlide"
          >
            <img src="../assets/images/arrow-left.png" />
          </div>
          <div
            class="next-btn btn-nav-slider hide-mobile"
            ref="nextArrow"
            @click="nextSlide"
          >
            <img src="../assets/images/arrow-right.png" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<settings>
{
  "name": "image-slideshow",
  "label": "Image Slideshow",
  "props": [
      {
        "type": "text",
        "id": "heading",
        "default": "",
        "label": "Heading"
      },
      {
        "type": "checkbox",
        "id": "view_all",
        "default": false,
        "label": "Show View All"
      },
       {
        "type": "checkbox",
        "id": "slide_width",
        "default": false,
        "label": "Overlap Slides"
    },
    {
      "type": "select",
      "id": "slide_height",
      "options": [
        {
          "value": "adapt",
          "text": "Adapt to first image"
        },
        {
          "value": "small",
          "text": "Small"
        },
        {
          "value": "medium",
          "text": "Medium"
        },
        {
          "value": "large",
          "text": "Large"
        }
      ],
      "default": "adapt",
      "label": "Slide height",
      "info":"Size of the slide"

    },
    {
        "type": "checkbox",
        "id": "autoplay",
        "default": false,
        "label": "AutoPlay Slides",
        "info":"Check to autoplay slides"
    },
    {
      "type": "range",
      "id": "slide_interval",
      "min": 1,
      "max": 10,
      "step": 1,
      "unit": "sec",
      "label": "Change slides after every",
      "default": 2,
      "info": "Autoplay slide duration"
    }
  ],
     "blocks": [
        {
        "type": "gallery_image",
        "name": "Image",
        "props": [
            {
                "type": "image_picker",
                "id": "image",
                "label": "Gallery Image"
            },
            {
              "type": "url",
              "id": "slide_link",
              "label": "Slide Link"
            }
        ]
    }
  ],
   "preset":{
    "blocks": [
      {
        "name": "Image"
      },
      {
        "name": "Image"
      }
    ]
  }
}
</settings>
<style scoped lang="less">
@import "../../node_modules/vue-slick-carousel/dist/vue-slick-carousel.css";
@import "../../node_modules/vue-slick-carousel/dist/vue-slick-carousel-theme.css";

/deep/ .slick-track {
  @media @mobile {
    padding-bottom: 0;
  }
}
/deep/ .slick-dots {
  position: initial !important;
  button:before {
    content: "" !important;
    height: 5px !important;
    margin-top: 5px;
    background: #000;
  }
}
/deep/.imgClass > .fy__img {
  width: 100%;
  border-radius: 8px !important;
  box-shadow: 9px 6px 10px rgba(0, 0, 0, 0.2);
}
.collections-container {
  min-height: 100px;
  .banner {
    color: #41434c;
    display: flex;
    justify-content: space-between;
    .title {
      font-weight: 700;
      font-size: 18px;
      text-transform: uppercase;
      @media @mobile {
        font-size: 14px;
      }
    }
  }
  .section-container {
    position: relative;
    overflow: hidden;
    list-style: none;
    padding: 0;
    z-index: 1;
    margin-left: auto;
    margin-right: auto;
    /deep/.slick-track {
      // display: flex;
    }
    .slide {
      position: relative;
      // max-height: 80vh;
      display: table-cell !important;
      vertical-align: middle;
      // padding-right: 20px;
      @media @mobile {
        // padding-right: 10px;
        height: auto !important;
      }
      &.small {
        height: 475px;
      }
      &.medium {
        height: 650px;
      }
      &.large {
        height: 775px;
      }
      @media only screen and (max-width: 360px) {
        &.small {
          height: 175px;
        }
        &.medium {
          height: 270px;
        }
        &.large {
          height: 375px;
        }
      }
    }
  }
}
.text-spacing {
  margin: 1px 0 15px 0;
}
.btn-nav-slider {
  position: absolute;
  top: 50%;
  z-index: @layer;
  transform: translate(0%, -50%);
  background: #ffffff;
  border-radius: 50%;
  padding: unset;
  cursor: pointer;
  width: 52px;
  height: 52px;
  @media @tablet {
    width: 30px;
    height: 30px;
    img {
      width: 30px;
    }
  }
  &.hide-mobile {
    display: block;
    @media @tablet {
      display: none;
    }
  }
}
.next-btn {
  right: 5px;
  @media @mobile {
    right: 15px;
  }
}
.prev-btn {
  left: 5px;
  @media @mobile {
    left: 15px;
  }
}
</style>
<script>
import { isBrowser, isNode } from "browser-or-node";
import { detectMobileWidth } from "../helper/utils";
// import smartImage from "./../global/components/common/smart-image";
import fyImage from "./../global/components/common/whitesplash-image.vue";
import VueSlickCarousel from "vue-slick-carousel";

export default {
  props: ["settings"],
  components: {
    "whitesplash-image": fyImage,
    VueSlickCarousel,
  },
  computed: {
    imageWidth: function () {
      let overlap = this.settings.props.slide_width.value;
      let w = 1200;
      if (!overlap) {
        w = 1200;
      }
      if (isBrowser) {
        if (window.screen.width >= 600 && window.screen.width <= 768) {
          w = 768;
        } else if (window.screen.width > 480 && window.screen.width <= 599) {
          w = 600;
        } else if (window.screen.width > 360 && window.screen.width <= 480) {
          w = 480;
        } else if (window.screen.width <= 360) {
          w = 360;
        }
      }
      return w;
    },
  },
  data: function () {
    return {
      slickOptions: {
        autoplaySpeed: this.settings.props.autoplay.value
          ? this.settings.props.slide_interval.value * 1000
          : undefined, //convert to ms
        autoplay: this.settings.props.autoplay.value,
        arrows: false,
        dots: true,
        swipeToSlide: true,
        slidesToShow: 1,
        infinite: true,
      },
      selectedSlideIndex: 0,
      dots: false,
    };
  },
  methods: {
    prevSlide() {
      this.$refs.slick.prev();
    },
    nextSlide() {
      this.$refs.slick.next();
    },
  },
};
</script>
