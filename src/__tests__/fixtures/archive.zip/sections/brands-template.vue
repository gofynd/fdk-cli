<template>
  <div class="section-main-container" v-if="brands">
    <div class="brands__template">
      <template v-if="brands.length > 0">
        <fdk-infinite-scrolling
          @loadmore="loadMoreData()"
          :loadingData="loading"
        >
          <template v-if="brands.length > 0">
            <div class="card-container">
              <div class="top-items">
                <div class="title-block">
                  <div
                    class="ukt-title bold-md"
                    v-if="
                      settings.props.title.value &&
                      settings.props.title.value.length > 0
                    "
                  >
                    {{ settings.props.title.value }}
                  </div>
                  <fdk-link
                    :link="'/brands/'"
                    class="ukt-links bold-sm"
                    v-if="brands.length > 0 && settings.props.view_all.value"
                    >View All</fdk-link
                  >
                </div>
                <div v-if="settings.props.layout.value === 'grid'">
                  <group-list
                    :cardlist="getBrands"
                    :cardtype="'BRANDS'"
                    :itemcount="settings.props.item_count.value"
                  ></group-list>
                </div>

                <div v-if="settings.props.layout.value === 'horizontal'">
                  <div class="brand-items">
                    <div :class="'glide' + _uid" ref="glide">
                      <div data-glide-el="track" class="glide__track">
                        <div
                          class="glide__slides ssr-slides-brand"
                          :data-count="settings.props.item_count.value"
                          :class="{
                            'big-slide-item':
                              settings.props.item_count.value < 5,
                          }"
                        >
                          <div
                            class="glide__slide"
                            v-for="(brand, index) in brands"
                            :key="index"
                          >
                            <fdk-link
                              v-if="brand"
                              class="item"
                              :link="`/products/?brand=${brand.slug}`"
                            >
                              <div class="carousel-cell">
                                <whitesplash-image
                                  :src="getBrandImage(brand)"
                                  class="imgClass"
                                  :alt="brand.name"
                                  :sources="[
                                    { breakpoint: { min: 1025 }, width: 220 },
                                    { breakpoint: { min: 769 }, width: 316 },
                                    { breakpoint: { min: 768 }, width: 231 },
                                    { breakpoint: { min: 481 }, width: 220 },
                                    { breakpoint: { min: 376 }, width: 190 },
                                    { breakpoint: { min: 361 }, width: 162 },
                                    { breakpoint: { min: 321 }, width: 154 },
                                    { breakpoint: { max: 320 }, width: 136 },
                                  ]"
                                />
                                <div class="carousel-details">
                                  <div
                                    class="card-logo"
                                    v-if="brand && brand.logo && brand.logo.url"
                                  >
                                    <whitesplash-image
                                      :src="brand.logo.url"
                                      :sources="[{ width: 50 }]"
                                      :placeholder="''"
                                    />
                                  </div>
                                  <div class="collection_desc">
                                    <div class="card-desc cl-content">
                                      <span class="ukt-title">{{
                                        brand.name
                                      }}</span>
                                    </div>
                                  </div>
                                  <!-- <img class="item__logo" :src="brand.logo.url" alt /> -->
                                </div>
                              </div>
                            </fdk-link>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- <p class="item__name">{{ brand.name }}</p> -->
                    <!-- </div> -->
                    <div
                      :class="{
                        'hide-slider-nav':
                          brands.length <= glideOptions.perView,
                      }"
                    >
                      <div
                        class="prev-btn btn-nav-brands"
                        ref="prevArrow"
                        @click="prevSlide"
                      >
                        <img src="../assets/images/arrow-left.png" />
                      </div>
                      <div
                        class="next-btn btn-nav-brands"
                        ref="nextArrow"
                        @click="nextSlide"
                      >
                        <img src="../assets/images/arrow-right.png" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </template>
          <template v-else-if="!isLoading && brands.length === 0">
            <placeholder-items
              :count="10"
              type="collection-1"
              text="Brand"
              :layout="settings.props.layout.value"
            />
          </template>
        </fdk-infinite-scrolling>
      </template>
    </div>
  </div>
</template>
<!-- #region  -->

<settings>
{
    "name":"brands-listing",
    "label":"Brands Listing",
    "props":[
    {
      "type": "text",
            "id": "title",
            "default": "",
            "label": "Title"
    },
    {
          "type":"header",
           "id": "header",
          "value":"Choose Brands to Show"
    },
    {
          "type":"radio",
          "id": "brand_type",
          "default":"all",
          "options": [
            {
              "value": "all",
              "text": "All"
            },
             {
              "value": "department",
              "text": "Department"
            },
            {
              "value": "handpicked",
              "text": "Handpicked"
            }
          ]
        },
        {
          "type":"department",
          "id":"department",
          "label": "Department",
          "info":"Select a department of brands",
          "note":"Department only applies if 'department' type is selected"
        },
          {
      "type": "range",
      "id": "item_count",
      "min": 3,
      "max": 5,
      "step": 1,
      "unit": "",
      "label": "Items per row",
      "default": 5,
      "info": "Maximum items allowed per row"
    },
    {
      "id": "layout",
      "type": "select",
      "options": [
        {
          "value": "grid",
          "text" : "Grid View"
        },
        {
          "value": "horizontal",
          "text" : "Horizontal View"
        }
      ],
      "default": "horizontal",
      "label": "Layout",
      "info":"Alignment of content"
    },
       {
        "type": "checkbox",
        "id": "view_all",
      "default": false,
        "label": "Show View All"
    }
    ],
     "blocks": [
      {
      "type": "brand-item",
      "name": "Brand Item",
      "props": [
        {
          "type": "brand",
          "id": "brand",
          "label":"Select Brand"
        }
  ]
}
  ]
}
</settings>
<!-- #endregion -->
<script>
import placeholderImage from "./../assets/images/placeholder.png";
import { isBrowser, isNode } from "browser-or-node";
import groupList from "./../global/components/group-list.vue";
import { detectMobileWidth } from "../helper/utils";
import fyImage from "./../global/components/common/whitesplash-image.vue";
import placeholderItemsVue from "../global/components/sections/placeholder-items.vue";
import uniqBy from "lodash/uniqBy";
import Glide from "@glidejs/glide";
import "../../node_modules/@glidejs/glide/dist/css/glide.core.min.css";
import "../../node_modules/@glidejs/glide/dist/css/glide.theme.min.css";

export default {
  props: ["settings", "serverProps", "apiSDK"],
  data() {
    return {
      brands: this.serverProps?.brands || [],
      isLoading: false,
      brandsLoaded: this.serverProps?.brandsLoaded || 0,
      page: this.serverProps?.page || { current: 0, has_next: true },
      isMounted: false,
      glideOptions: {
        type: "slider",
        bound: true,
        rewind: false,
        startAt: 0,
        gap: 30,
        perView: this.settings.props.item_count.value,
        breakpoints: {
          768: {
            perView: 3,
          },
          600: {
            perView: 2,
          },
          480: {
            perView: 2,
          },
        },
      },
      carouselHandle: null,
    };
  },
  components: {
    "group-list": groupList,
    "whitesplash-image": fyImage,
    "placeholder-items": placeholderItemsVue,
  },
  computed: {
    imageWidth: function () {
      let w = 312;
      if (isBrowser) {
        if (window.screen.width >= 1280) {
          w = 275;
        } else if (window.screen.width >= 768) {
          w = 312;
        } else if (window.screen.width > 360) {
          w = 184;
        } else if (window.screen.width <= 360) {
          w = 160;
        }
      }
      return w;
    },
    getBrands() {
      return uniqBy(this.brands, (e) => {
        return e.slug;
      });
    },
  },
  watch: {
    settings(newVal, oldVal) {
      if (
        newVal.props.department.value !== oldVal.props.department.value ||
        newVal.props.brand_type.value !== oldVal.props.brand_type.value ||
        newVal.props.item_count.value !== oldVal.props.item_count.value ||
        newVal.blocks !== oldVal.blocks
      ) {
        this.page = { current: 0, has_next: true };
        this.brands = [];
        this.brandsLoaded = 0;
        this.settings = newVal;
        this.cleanupComponent();
        this.initializeComponent();
      }
    },
  },
  beforeDestroy() {
    this.cleanupComponent();
  },
  methods: {
    isBlocksChanged(newBlocks, oldBlocks) {
      return JSON.stringify(newBlocks) === JSON.stringify(oldBlocks)
        ? false
        : true;
    },
    cleanupComponent() {
      if (isBrowser && this.carouselHandle) {
        this.carouselHandle.destroy();
        this.carouselHandle = null;
      }
    },
    checkisBrowser() {
      return isBrowser;
    },
    prevSlide() {
      // item_count variable holds the value of number of items to show
      let item_count = this.settings.props.item_count.value;

      if (detectMobileWidth()) {
        if (this.carouselHandle.index - 1 >= 0) {
          this.carouselHandle.go(`=${this.carouselHandle.index - 1}`);
        }
      } else {
        if (this.carouselHandle.index - item_count >= 0) {
          this.carouselHandle.go(`=${this.carouselHandle.index - item_count}`);
        } else {
          this.carouselHandle.go(`<<`);
        }
      }
    },
    nextSlide() {
      let item_count = this.settings.props.item_count.value - 1;
      if (detectMobileWidth()) {
        ///this.categories.length has to be replaced by the length of items in carousel
        if (this.carouselHandle.index + 1 < this.brands.length - 1) {
          this.carouselHandle.go(`=${this.carouselHandle.index + 1}`);
        }
      } else {
        if (this.carouselHandle.index + item_count < this.brands.length) {
          this.carouselHandle.go(`=${this.carouselHandle.index + item_count}`);
        } else {
          this.carouselHandle.go(`>>`);
        }
      }
    },
    initCarousel() {
      //if IsNode OR Layout is horizontal(optional flag) OR carouselHandle(carousel) is not already initialized
      if (
        !isBrowser ||
        this.settings.props.layout.value !== "horizontal" ||
        this.carouselHandle
      ) {
        return;
      }
      if (!this.$refs.glide) {
        setTimeout(() => {
          this.initCarousel();
        }, 1000);
        return;
      }
      // waiting for data to render, hence nextTick
      this.$nextTick(() => {
        try {
          if (window.screen.width <= 480) {
            this.glideOptions.gap = 10;
          }
          if (this.brands.length <= this.glideOptions.perView) {
            this.glideOptions.type = "slider";
          } else {
            this.glideOptions.type = "carousel";
          }
          this.carouselHandle = new Glide(this.$refs.glide, this.glideOptions);
          this.carouselHandle.on("mount.after", function () {
            let elt = document.querySelector(".ssr-slides-brand");
            elt.style.display = "flex";
            elt.style["grid-column-gap"] = 0;
            elt.style['touch-action'] = "pan-Y";
            elt.style.overflow = "hidden";
          });
          this.carouselHandle.mount();
        } catch (ex) {
          //There is an exception logged, due to rendering delay, so this try,catch is required
        }
      });
    },
    replaceByDefault(e) {
      e.target.src = placeholderImage;
    },
    getBrandImage(brand) {
      if (this.settings.props.brand_type.value !== "handpicked") {
        return brand.banners.portrait.url;
      }
      return brand.banners.portrait.url;
    },
    loadMoreData() {
      let options = {
        pageNo: this.page.current + 1,
      };
      if (this.settings.props.brand_type.value === "department") {
        options.department = this.settings.props.department.value;
      }
      if (
        this.settings.props.layout.value === "grid" &&
        this.settings.props.brand_type.value !== "handpicked"
      ) {
        !this.isLoading && this.fetchBrands(options);
      }
    },
    fetchBrands(options) {
      if (this.settings.props.brand_type.value !== "handpicked") {
        if (this.page && this.page.has_next) {
          this.isLoading = true;
          this.$apiSDK.catalog
            .getBrands(options)
            .then((data) => {
              this.brands = [...this.brands, ...data.items];
              this.page = data.page;
              this.isMounted = true;
              this.isLoading = false;
              this.initCarousel();
            })
            .catch((ex) => {
              console.log(ex);
              this.isLoading = false;
              this.isMounted = true;
              this.initCarousel();
            });
        }
      } else {
        if (this.settings.blocks.length === this.brandsLoaded) return;
        this.brands = [];
        Promise.all(
          this.settings.blocks.map((block) => {
            if (!block?.props?.brand?.value) return;
            this.isLoading = true;
            return this.$apiSDK.catalog
              .getBrandDetailBySlug({
                slug: block.props.brand.value.id,
              })
              .then((data) => {
                return data;
              });
          })
        )
          .then((brands) => {
            this.brands = brands.filter((b) => b?.name);
            this.isMounted = true;
            this.isLoading = false;
            this.brandsLoaded = brands.length;
            this.initCarousel();
          })
          .catch((ex) => {
            this.isLoading = false;
            this.isMounted = true;
            this.initCarousel();
          });
      }
    },
    loadBrands() {
      const { brand_type, department } = this.settings?.props || {};
      const options = {
        ...(department && { department: department.value }),
        pageNo: this.page.current + 1,
      };
      if (brand_type.value === "department") {
        options.department = department.value;
        this.brandsLoaded = 0;
      }
      const urlParams = new URLSearchParams(window.location.search);
      const checkIsPreview = urlParams.get("isPreview");
      if (this.brands.length == 0 || checkIsPreview) {
        !this.isLoading && this.fetchBrands(options);
      }
    },
    initializeComponent() {
      if (window.screen.width > 600 && window.screen.width <= 768) {
        this.glideOptions.perView = 3;
      } else if (window.screen.width <= 600) {
        this.glideOptions.perView = 2;
      }
      this.glideOptions.perView = this.settings.props.item_count.value;
      if (this.brands.length === 0) {
        this.loadBrands();
      } else {
        this.isMounted = true;
        this.initCarousel();
      }
    },
  },
  initializeServerProps({ settings, apiSDK }) {
    const { brand_type, department } = settings?.props || {};
    const options = {
      ...(department && { department: department.value }),
      pageNo: 1,
    };
    if (brand_type.value === "department") {
      options.department = department.value;
    }
    if (settings.props.brand_type.value !== "handpicked") {
      return apiSDK.catalog
        .getBrands(options)
        .then((data) => {
          return {
            brands: data.items || [],
            page: data.page,
          };
        })
        .catch((ex) => {
          console.log(ex);
        });
    } else {
      return Promise.all(
        settings.blocks.map((block) => {
          return apiSDK.catalog
            .getBrandDetailBySlug({
              slug: block.props.brand.value.id,
            })
            .then((data) => {
              return data.items || [];
            })
            .catch((ex) => {
              console.log(ex);
            });
        })
      ).then((brands) => {
        if (brands && brands[0].uid) {
          return {
            brands: brands || [],
            brandsLoaded: brands.length,
          };
        } else {
          return {
            brands: [],
            brandsLoaded: 0,
          };
        }
      });
    }
  },
  mounted() {
    this.initializeComponent();
  },
};
</script>

<style lang="less" scoped>
/deep/.imgClass {
  width: 100%;
  .fy__img {
    border-radius: 8px;
    height: 100%;
    width: 100%;
  }
}
.glide__slide {
  height: auto;
  a {
    display: flex;
    height: 100%;

    min-height: 290px;
    @media only screen and (max-width: 1024px) {
      min-height: 215px;
    }
    @media only screen and (max-width: 768px) {
      min-height: 280px;
    }
    @media only screen and (max-width: 600px) {
      min-height: 270px;
    }
    @media only screen and (max-width: 480px) {
      min-height: 230px;
    }
    @media only screen and (max-width: 360px) {
      min-height: 215px;
    }
  }
}

.glide__slides.ssr-slides-brand {
  touch-action: unset;
  overflow: scroll;

  display: grid;
  grid-column-gap: 30px;
  grid-auto-flow: column;
  grid-template-columns: repeat(auto-fill, minmax(17.9%, 1fr));

  @media @tablet {
    grid-template-columns: repeat(auto-fill, minmax(30%, 1fr));
  }

  @media @mobile {
    grid-template-columns: repeat(auto-fill, minmax(48%, 1fr));
    grid-column-gap: 10px;
  }

  &:big-slide-item {
    display: grid;
    grid-column-gap: 30px;
  }

  &.big-slide-item[data-count="3"] {
    grid-template-columns: repeat(auto-fill, minmax(31.5%, 1fr));

    @media @mobile {
      grid-template-columns: repeat(auto-fill, minmax(48%, 1fr));
      grid-column-gap: 10px;
    }
  }

  &.big-slide-item[data-count="4"] {
    grid-template-columns: repeat(auto-fill, minmax(23%, 1fr));

    @media @tablet {
      grid-template-columns: repeat(auto-fill, minmax(30%, 1fr));
    }

    @media @mobile {
      grid-template-columns: repeat(auto-fill, minmax(48%, 1fr));
      grid-column-gap: 10px;
    }
  }
  .glide__slide {
    border-radius: 8px;
    min-height: 290px;

    @media only screen and (max-width: 1024px) {
      min-height: 215px;
    }
    @media only screen and (max-width: 768px) {
      min-height: 280px;
    }
    @media only screen and (max-width: 600px) {
      min-height: 270px;
    }
    @media only screen and (max-width: 480px) {
      min-height: 230px;
    }
    @media only screen and (max-width: 360px) {
      min-height: 215px;
    }
  }
}
.btn-nav-cat {
  z-index: @layer;
  transform: translate(0%, -50%);
  background-color: transparent;
  padding: unset;
  cursor: pointer;
  width: 50px;
  @media @mobile {
    width: 30px;
  }
}
.icon {
  display: inline-block;
  width: 47px;
  height: 19px;
  background-size: cover;
}
.icon-next {
  background-image: url(../assets/images/arrow-right.png);
}
.icon-prev {
  background-image: url(../assets/images/arrow-left.png);
  transform: rotate(180deg);
}
.collection-carousel-items {
  position: relative;
  @media @mobile {
    padding: 0;
  }
}

::-webkit-scrollbar {
  display: none;
}
.brands {
  &__template {
    max-width: 1200px;
    position: relative;
    margin: 40px auto 0 auto;
    background-color: transparent;
    padding: 0;
    @media @tablet {
      padding: 0px;
      margin: 0px;
    }
    @media @mobile {
      background-color: #fff;
      margin: 0px;
      padding: 0px;
    }
    .hide-slider-nav {
      display: none;
      @media @tablet {
        display: block;
      }
    }

    .section-heading {
      font-size: 18px;
      text-align: left;
      color: #41434c;
      margin-bottom: 6px;
      @media @mobile {
        font-size: 14px;
        margin-bottom: 6px;
        margin-left: 9px;
      }
    }
  }
  &__content {
    top: 92%;
    position: absolute;
    display: flex;
    width: 100%;
    left: 50%;
    transform: translate(-50%, -50%);
    transition: all 0.5s;
    background: transparent linear-gradient(180deg, transparent, #000) 0 0
      no-repeat padding-box;
    color: #ffffff;
    border-radius: 8px;
  }
}

.card-container {
  margin: 0;
}
.top-items {
  padding: 14px;
  border-radius: @BorderRadius;
  background: transparent;
  margin: 10px 0 0 0;

  @media @mobile {
    padding: 0;
    margin: 0;
  }
}

.title-block {
  display: flex;
  align-items: baseline;
  text-transform: uppercase;
  margin: 0 0 15px 0;
}
.ukt-links {
  margin-left: auto;
  right: 15px;
  text-transform: uppercase;
  position: relative;
}
.brands {
  justify-content: left;
}

// Horizontal View CSS

.brand-items {
  position: relative;
  @media @mobile {
    padding: 0;
  }
  .carousel-cell {
    cursor: pointer;
    height: auto;
    width: 100%;
    display: flex;
    align-items: center;
    background-color: #f2f2f2;
    border-radius: 8px;
    box-shadow: 9px 6px 10px rgba(0, 0, 0, 0.2);
    position: relative;
    img.carousel-image {
      border-radius: 8px;
      height: 100%;
      width: 100%;
      box-shadow: 9px 6px 10px rgba(0, 0, 0, 0.2);
      @media @mobile {
        height: 100%;
      }
    }

    .carousel-details {
      bottom: 0;
      position: absolute;
      display: flex;
      width: 100%;
      left: 50%;
      height: 80px;
      background: transparent linear-gradient(180deg, transparent, #000) 0 0
        no-repeat padding-box;
      color: #fff;
      border-radius: 8px;
      box-sizing: border-box;
      left: 0;
      right: 0;
      align-items: center;
      @media @mobile {
        align-items: flex-end;
      }
      .card-logo {
        bottom: 30px;
        width: 50px;
        height: 50px;
        margin-left: 10px;
        /deep/ .fy__img {
          width: 50px;
          border-radius: 8px;
          @media @mobile {
            width: 40px;
            height: 40px;
            margin-left: 8px;
          }
        }
      }
      .collection_desc {
        font-size: 16px;
        font-weight: 700;
        margin-left: 10px;
        color: #ffffff;
        height: 60px;
        display: flex;
        align-items: center;
        @media @mobile {
          margin-left: 0;
        }
        .ukt-title {
          text-transform: uppercase;
          width: 100px;
          display: block;
          text-align: left;
          color: #ffffff;
          @media @mobile {
            width: 88px;
            font-size: 10px;
          }
        }
        .cl-img {
          width: 50px;
          left: 50%;
          transform: translate(-50%, 0%);
          height: 50px;
          position: relative;
        }
        .cl-content {
          white-space: normal !important;
          padding: 0px 10px;
          width: auto;
          line-height: 15px;
          @media @tablet {
            padding: 0 18px;
          }
          .card-count {
            padding: 0px;
            margin-top: 10px;
          }
        }
      }
    }
  }
}

.btn-nav-brands {
  position: absolute;
  top: 50%;
  z-index: @layer;
  transform: translate(0%, -50%);
  background-color: transparent;
  padding: unset;
  width: 50px;
  cursor: pointer;
  @media @mobile {
    width: 30px;
  }
}
.next-btn {
  right: 0px;
  @media @mobile {
    right: 20px;
  }
}
.prev-btn {
  left: 0;
}

.item {
  &__image {
    position: relative;
    box-shadow: 9px 6px 10px rgba(0, 0, 0, 0.2);
    border-radius: 8px;
    min-height: 300px;
    margin: 10px;
    @media @tablet {
      min-height: 257px;
    }
    @media @mobile {
      min-height: 230px imp !important;
      box-shadow: none;
    }
    @media only screen and (max-width: 359px) {
      min-height: 209px !important;
      box-shadow: none;
    }
  }
  &__brand-image {
    width: 100%;
    background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANsAAAFWAQMAAADaFHqxAAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAACBJREFUaN7twTEBAAAAwqD1T20LL6AAAAAAAAAAAADgbSa+AAGGhRJaAAAAAElFTkSuQmCC");
    border-radius: 8px;
  }

  &__logo {
    top: 70%;
    position: absolute;
    width: 50px;
    left: 50%;
    transform: translateX(-50%);
  }
  &__name {
    font-weight: bold;
    color: #41434c;
    font-size: 14px;
    text-align: center;
    @media @mobile {
      font-size: 12px;
    }
  }
}
</style>
