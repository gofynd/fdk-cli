<template>
  <div>
    <div class="group-cards" v-if="layout === 'grid'">
      <placeholder-item
        v-for="index in count"
        :type="type"
        :key="index"
        :text="`${text} ${index}`"
      ></placeholder-item>
    </div>
    <div v-else-if="layout === 'horizontal'">
      <div class="brand-items">
        <VueSlickCarousel ref="slick" v-bind="slickOptions">
          <fdk-link :link="`#`" v-for="index in count" :key="index">
            <div class="carousel-cell">
              <fdk-placeholder :type="type" class="imgClass" />
              <div class="carousel-details">
                <div class="collection_desc">
                  <div class="card-desc cl-content">
                    <span class="ukt-title">{{ `${text} ${index}` }}</span>
                  </div>
                </div>
                <!-- <img class="item__logo" :src="brand.logo.url" alt /> -->
              </div>
            </div>

            <!-- <p class="item__name">{{ brand.name }}</p> -->
          </fdk-link>
        </VueSlickCarousel>
        <div class="arrows">
          <div
            class="prev-btn btn-nav-brands"
            ref="prevArrow"
            @click="prevSlide"
          >
            <img src="../../../assets/images/arrow-left.png" />
          </div>
          <div
            class="next-btn btn-nav-brands"
            ref="nextArrow"
            @click="nextSlide"
          >
            <img src="../../../assets/images/arrow-right.png" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import placeholderItemVue from './placeholder-item.vue';
import VueSlickCarousel from 'vue-slick-carousel';
import { detectMobileWidth } from '../../../helper/utils';
export default {
  name: 'placeholder-items',
  components: {
    'placeholder-item': placeholderItemVue,
    VueSlickCarousel,
  },
  props: {
    count: {
      type: Number,
    },
    type: {
      type: String,
    },
    text: {
      type: String,
    },
    layout: {
      type: String,
      default: 'grid',
    },
  },
  data() {
    return {
      slickOptions: {
        arrows: false,
        dots: false,
        swipeToSlide: true,
        slidesToShow: 4,
        slidesToScroll: 2,
      },
    };
  },
  methods: {
    prevSlide() {
      if (detectMobileWidth()) {
        this.$refs.slick.goTo(
          this.$refs.slick.$refs.innerSlider.currentSlide - 1
        );
      } else {
        this.$refs.slick.goTo(
          this.$refs.slick.$refs.innerSlider.currentSlide - 4
        );
      }
    },
    nextSlide() {
      if (detectMobileWidth()) {
        this.$refs.slick.goTo(
          this.$refs.slick.$refs.innerSlider.currentSlide + 1
        );
      } else {
        this.$refs.slick.goTo(
          this.$refs.slick.$refs.innerSlider.currentSlide + 4
        );
      }
    },
  },
};
</script>

<style lang="less" scoped>
.group-cards {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(15%, 1fr));
  grid-auto-rows: auto;
  grid-gap: 2em;
}
@media screen and (max-width: 768px) {
  .group-cards {
    grid-template-columns: repeat(auto-fill, minmax(40%, 1fr));
    grid-gap: 0.5em;
    padding: 0 10px;
  }
}

.brand-items {
  position: relative;
  @media @mobile {
    padding: 0;
  }
  .carousel-cell {
    cursor: pointer;
    height: auto;
    margin-right: 30px;
    @media @mobile {
      margin-right: 10px;
    }
    position: relative;
    img.carousel-image {
      border-radius: 8px;
      /*border: 1px solid #aba3a333;*/
      // height: 328px;
      width: 100%;
      box-shadow: 9px 6px 10px rgba(0, 0, 0, 0.2);
      // @media @mobile {
      //   height: 250px;
      // }
    }

    .carousel-details {
      bottom: 0;
      position: absolute;
      display: flex;
      width: 100%;
      left: 50%;
      height: 80px;
      background: transparent linear-gradient(180deg, transparent, #000) 0 0
        no-repeat padding-box;
      color: #fff;
      border-radius: 8px;
      box-sizing: border-box;
      left: 0;
      right: 0;
      align-items: center;
      @media @mobile {
        height: 55px;
      }

      .collection_desc {
        font-size: 16px;
        font-weight: 700;
        margin-left: 10px;
        color: #ffffff;
        height: 30px;
        @media @mobile {
          margin-left: 0;
        }
        .ukt-title {
          text-transform: uppercase;
          width: 100px;
          display: block;
          white-space: nowrap;
          text-align: left;
          color: #ffffff;
          @media @mobile {
            width: 88px;
            font-size: 10px;
          }
        }
        .cl-img {
          width: 50px;
          left: 50%;
          transform: translate(-50%, 0%);
          height: 50px;
          position: relative;
        }
        .cl-content {
          white-space: normal !important;
          margin: 0px 10px;
          width: auto;

          .card-count {
            padding: 0px;
            margin-top: 10px;
          }
        }
      }
    }
  }
}

.slick-slide img {
  display: unset !important;
}

.btn-nav-brands {
  position: absolute;
  top: 50%;
  z-index: @layer;
  transform: translate(0%, -50%);
  background-color: transparent;
  padding: unset;
  width: 50px;
  cursor: pointer;
  @media @mobile {
    width: 30px;
  }
}
.next-btn {
  right: 15px;
}
.prev-btn {
  left: 0;
}
</style>
