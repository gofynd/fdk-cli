<template>
  <fdk-product-card>
    <template slot-scope="productData">
      <fdk-accounts class="wishlist-btn">
        <template slot-scope="accountsData">
          <div
            v-if="accountsData.is_logged_in && isMounted"
            @click="productData.updateWishList($event, item)"
          >
            <img v-if="!item.follow" src="../../assets/images/heart-default.svg" alt="" />
            <img v-else-if="item.follow" src="../../assets/images/heart-selected.svg" alt="" />
          </div>
        </template>
      </fdk-accounts>
    </template>
  </fdk-product-card>
</template>

<style lang="less" scoped></style>

<script>
export default {
  name: "favourite",
  props: {
    item: Object,
    cardType: String,
  },
  mounted() {
    this.isMounted = true;
  },
  data() {
    return {
      isMounted: false,
    };
  },
  methods: {},
};
</script>
