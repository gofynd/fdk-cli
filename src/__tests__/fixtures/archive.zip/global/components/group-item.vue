<template>
  <div class="card-item" :title="getTitle">
    <fdk-link :action="card.action">
      <div class="card-img" :class="{}" :data-cardtype="cardtype">
        <div class="overlay-2"></div>
        <whitesplash-image
          class="group-item-img"
          :src="getMediaURL"
          :sources="[
            { breakpoint: { min: 769 }, width: 209 },
            { breakpoint: { min: 541, max: 768 }, width: 360 },
            { breakpoint: { max: 540 }, width: 209 },
          ]"
        />
        <div class="logo-wrapper">
          <div class="card-logo" v-if="getCardLogo">
            <whitesplash-image :src="getCardLogo" :sources="[{ width: 100 }]" />
          </div>
          <div class="collection_desc" :class="{ 'pos-center': !getCardLogo }">
            <div class="card-desc cl-content text-center">
              <span class="ukt-title clrWhite" :title="card.name">{{
                ellipseText(card.name)
              }}</span>
            </div>
          </div>
        </div>
      </div>
    </fdk-link>
  </div>
</template>
<style lang="less" scoped>
.text-center {
  text-align: center;
}

.clrWhite {
  color: @White !important;
}
.card-item {
  border: 0 !important;
  position: relative;
  // margin-bottom: 15px;
  width: 100%;
  display: flex;
  align-items: center;
  background: #f2f2f2;
  border-radius: 8px;
  height: 100%;
  display: flex;
  align-items: center;
  background: #f2f2f2;
  border-radius: 8px;
  cursor: pointer;

  a {
    text-decoration: none;
    width: 100%;
    height: 100%;
  }
  /deep/.card-img {
    position: relative;
    border-radius: 8px;
    width: 100%;
    min-height: 270px;
    height: 100%;
    display: flex;
    align-items: center;
    overflow: hidden;
    box-shadow: 9px 6px 10px rgba(0, 0, 0, 0.2);

    @media only screen and(max-width:1024px) {
      min-height: 215px;
    }

    @media only screen and(max-width: 768px) {
      min-height: 278px;
    }

    @media only screen and(max-width: 600px) {
      min-height: 280px;
    }

    @media only screen and(max-width: 480px) {
      min-height: 240px;
      box-shadow: none;
    }

    @media only screen and(max-width: 360px) {
      min-height: 215px;
      box-shadow: none;
    }

    .group-item-img {
      width: 100%;
    }

    img {
      border-radius: 8px;
      animation: fadeIn 0.5s ease;
      width: 100%;
      // background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANsAAAFWAQMAAADaFHqxAAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAACBJREFUaN7twTEBAAAAwqD1T20LL6AAAAAAAAAAAADgbSa+AAGGhRJaAAAAAElFTkSuQmCC");
    }

    .PDP img {
      box-shadow: none;
    }

    .bg-gradient {
      background-image: linear-gradient(
        to bottom,
        rgba(0, 0, 0, 0.14),
        rgba(0, 0, 0, 0.6)
      );
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: calc(100% - 3px);
      background-size: cover;
      border-radius: @BorderRadius;
      opacity: 0.4;
    }
    .item-selection {
      position: absolute;
      top: 10px;
      left: 10px;
    }
    .item-sets {
      position: absolute;
      right: 0px;
      top: 0px;
    }
  }

  .logo-wrapper {
    bottom: 0;
    position: absolute;
    display: flex;
    width: 100%;
    height: 80px;
    transition: all 0.5s;
    background: transparent linear-gradient(180deg, transparent, #000) 0 0
      no-repeat padding-box;
    color: #fff;
    border-radius: 8px;
    padding: 20px 0 0 0px;
    box-sizing: border-box;
  }
  .card-logo {
    /* position: absolute; */
    bottom: 30px;
    width: 50px;
    /* left: 50%; */
    /* transform: translate(-50%,-50%); */
    height: 50px;
    margin-left: 10px;
    @media @mobile {
      margin-left: 0px;
    }
    /deep/ .fy__img {
      width: 50px;
      border-radius: 8px;
      @media @mobile {
        margin-left: 8px;
        width: 42px;
      }
    }
  }
  .collection_desc {
    font-size: 16px;
    font-weight: 700;
    // margin-left: 10px;
    width: 70%;
    display: flex;
    align-items: center;
    height: 50px;
    @media @mobile {
      height: 40px;
    }
    .ukt-title {
      text-transform: uppercase;
      width: auto;
      display: block;
      white-space: pre-wrap;
      text-align: left;
      font-size: 14px;
      line-height: 16px;
      @media screen and (max-width: 1024px) {
        font-size: 11px;
      }
      @media @mobile {
        font-size: 14px;
        white-space: nowrap !important;
        text-overflow: ellipsis;
        overflow: hidden;
        padding: 0 15px 0 0;
      }
    }
    .cl-img {
      width: 50px;
      left: 50%;
      transform: translate(-50%, 0%);
      height: 50px;
      position: relative;
    }
    .cl-content {
      white-space: normal !important;
      margin: 0px 18px;
      width: auto;
      box-sizing: border-box;
      @media @mobile {
        margin: 0 0 0 10px;
        width: 100%;
      }
      .card-count {
        padding: 0px;
        margin-top: 10px;
      }
    }
  }
  .collection_desc.pos-center {
    width: 100%;
    margin: 0;
    display: flex;
    align-items: center;
    .cl-content {
      white-space: normal !important;
      padding: 0px 10px 0 10px;
      width: 100%;
      box-sizing: border-box;
      margin: 0 auto;
    }
    .ukt-title {
      width: 100%;
      text-align: center;
    }
  }

  .overlay-2 {
    background: #000000;
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    pointer-events: none;
    opacity: 0;
    z-index: 1;
    width: 100%;
    height: 100%;
    min-height: 300px;
    border-radius: 8px;
  }
  &:hover {
    .logo-wrapper {
      bottom: 30%;
      opacity: 1 !important;
      z-index: 2;
    }
    .overlay-2 {
      opacity: 0.8 !important;
    }
  }
}
</style>

<script>
import Favourite from "./../../global/components/favourite.vue";
import Rating from "./../../global/components/fy-rating.vue";
import placeholderImage from "./../../assets/images/placeholder.png";
import fyImage from "../../global/components/common/whitesplash-image.vue";

export default {
  name: "groupItem",
  components: {
    favourite: Favourite,
    rating: Rating,
    "whitesplash-image": fyImage,
  },
  props: {
    card: {
      type: Object,
      required: true,
    },
    cardtype: {
      type: String,
      enum: ["BRANDS", "CATEGORIES", "COLLECTIONS", "WISHLIST"],
    },
    layout: {
      type: String,
    },
  },

  computed: {
    getTitle() {
      let title = this.card.name;
      if (this.card.product_name) {
        title += " " + this.card.product_name;
      }
      return title;
    },
    getCardLogo() {
      return this.card.logo ? this.card.logo.url : null;
    },
    getMediaURL() {
      let mediaURL = this.card.image
        ? this.card.image.url
        : Array.isArray(this.card.medias)
        ? this.card.medias[0].url
        : "";
      if (this.cardtype === "COLLECTIONS") {
        mediaURL = this.card.banners.portrait.url;
      }
      if (this.cardtype === "BRANDS" && this.card.banners) {
        mediaURL = this.card.banners.portrait.url;
      }
      if (this.cardtype === "CATEGORIES" && this.card.banners) {
        mediaURL = this.card.banners.portrait.url;
      }
      return mediaURL;
    },
  },
  methods: {
    getProductPrice(key) {
      if (this.card.price) {
        return this.card.price[key].min !== this.card.price[key].max
          ? this.$options.filters.currencyformat(this.card.price[key].min) +
              " - " +
              this.$options.filters.currencyformat(this.card.price[key].max)
          : this.$options.filters.currencyformat(this.card.price[key].min);
      }
      return "";
    },
    generateQuery() {
      let strQuery = "";
      for (let key in this.card.action.query) {
        for (let i = 0; i < this.card.action.query[key].length; i++) {
          strQuery += key + "=" + this.card.action.query[key][i] + "&";
        }
      }
      return strQuery;
    },
    validateCardType() {
      return (
        this.cardtype !== "BRANDS" &&
        this.cardtype !== "COLLECTIONS" &&
        this.cardtype !== "CATEGORIES"
      );
    },
    replaceByDefault(e) {
      e.target.src = placeholderImage;
    },
    ellipseText(text) {
      return text.length > 35 ? text.substring(0, 35) + ".." : text;
    },
  },
};
</script>
