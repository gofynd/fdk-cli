<template>
  <div>
    <div
      :class="{
        'group-cards': itemcount == 5,
        'group-cards-4': itemcount == 4,
        'group-cards-3': itemcount == 3,
      }"
    >
      <group-item
        v-for="(item, index) in cardlist"
        :card="item"
        :key="item.name + cardtype + index"
        :cardtype="cardtype"
      ></group-item>
    </div>
  </div>
</template>

<script>
import groupItem from "./group-item.vue";

export default {
  name: "groupList",
  components: {
    "group-item": groupItem,
  },
  props: {
    cardlist: {
      type: Array,
    },
    cardtype: {
      type: String,
      enum: ["BRANDS", "CATEGORIES", "COLLECTIONS", "WISHLIST"],
    },
    itemcount: {
      type: Number,
    },
  },
  computed: {
    getFlex() {
      return this.itemcount
        ? `grid-template-columns: repeat(${this.itemcount}, 1fr)`
        : "";
    },
  },
};
</script>

<style lang="less" scoped>
.group-cards {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  grid-auto-rows: auto;
  grid-gap: 2em;
  @media screen and (max-width: 1024px) {
    grid-gap: 1em;
  }
  @media screen and (max-width: 768px) {
    grid-template-columns: repeat(3, 1fr);
    grid-gap: 0.5em;
  }
  @media screen and (max-width: 600px) {
    grid-template-columns: repeat(2, 1fr);
    grid-gap: 0.5em;
  }
}
.group-cards-4 {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  grid-auto-rows: auto;
  grid-gap: 2em;
  @media screen and (max-width: 1024px) {
    grid-gap: 1em;
  }
  @media screen and (max-width: 768px) {
    grid-template-columns: repeat(3, 1fr);
    grid-gap: 0.5em;
  }
  @media screen and (max-width: 600px) {
    grid-template-columns: repeat(2, 1fr);
    grid-gap: 0.5em;
  }
}

.group-cards-3 {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-auto-rows: auto;
  grid-gap: 2em;
  @media screen and (max-width: 768px) {
    grid-gap: 0.5em;
  }
  @media screen and (max-width: 600px) {
    grid-template-columns: repeat(2, 1fr);
    grid-gap: 0.5em;
  }
}
</style>
