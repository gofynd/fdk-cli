<template>
  <select
    :disabled="disabled === true"
    class="custom-select"
    v-model="selectedOpt"
    @change="changeSelection"
  >
    <option v-for="(opt, index) in options" :key="index" :value="opt.value">
      {{ opt.display }}
    </option>
  </select>
</template>

<style lang="less" scoped>
.custom-select {
  width: 100%;
}
</style>

<script>
export default {
  name: "fy-select",
  props: {
    options: {},
    selectedOpt: {
      type: String,
      default: "",
    },
    disabled: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {};
  },
  methods: {
    changeSelection(event) {
      this.$emit("change-selection", event);
    },
  },
};
</script>
