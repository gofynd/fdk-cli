export const LANGUAGES = `
    query Languages {
        languages {
            locale
            direction
            name
            is_default
            display_name
        }
    }
`;
