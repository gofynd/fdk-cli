import React, { useState } from "react";

import { motion, AnimatePresence } from "framer-motion";
import Modal from "fdk-react-templates/components/core/modal/modal";
import "fdk-react-templates/components/core/modal/modal.css";

import SvgWrapper from "../../../../components/core/svgWrapper/SvgWrapper";
import DeliveryInfo from "../delivery-info/delivery-info";
import SizeGuide from "../../size-guide/size-guide";
import styles from "./sticky-addtocart.less";
import { useGlobalTranslation } from "fdk-core/utils";

const StickyAddToCart = ({
  productMeta,
  selectedSize,
  onSizeSelection,
  blockProps,
  sizes,
  getProductPrice,
  addProductForCheckout,
  productPriceBySlug,
  isSizeGuideAvailable,
  deliveryInfoProps,
  showBuyNow,
}) => {
  const { t } = useGlobalTranslation("translation");
  const [showSizeModal, setShowSizeModal] = useState(false);
  const [showSizeGuide, setShowSizeGuide] = useState(false);
  const [modalType, setModalType] = useState("");

  const openSizeModal = (e, modalType) => {
    if (
      selectedSize &&
      deliveryInfoProps?.pincode &&
      deliveryInfoProps?.isValidDeliveryLocation
    ) {
      cartHandler(e, modalType === "buy-now");
    } else {
      e.preventDefault();
      setShowSizeModal(true);
      setModalType(modalType);
    }
  };
  const cartHandler = async (e, isBuyNow) => {
    addProductForCheckout(e, selectedSize, isBuyNow);
  };

  return (
    <>
      <AnimatePresence mode="wait">
        <motion.div
          className={`${styles.stickyAddtocart} ${showSizeGuide && styles["stickyAddtocart--zIndex"]}`}
          key="add-to-cart-container"
          initial={{ opacity: 0, y: "100%" }}
          animate={{ opacity: 1, y: "0%" }}
          exit={{ opacity: 0, y: "100%" }}
          transition={{ duration: 0.5 }}
        >
          <button
            type="button"
            className={`btnSecondary ${styles.button}`}
            onClick={(e) => openSizeModal(e, "add-to-cart")}
          >
            <SvgWrapper svgSrc="cart" className={styles.cartIcon} />
            {t("resource.common.add_to_cart")}
          </button>
        </motion.div>
        {showBuyNow && (
          <motion.div
            className={`${styles.stickyAddtocart} ${showSizeGuide && styles["stickyAddtocart--zIndex"]}`}
            key="buy-now-container"
            initial={{ opacity: 0, y: "100%" }}
            animate={{ opacity: 1, y: "0%" }}
            exit={{ opacity: 0, y: "100%" }}
            transition={{ duration: 0.5 }}
          >
            <button
              type="button"
              className={`${styles.button} btnPrimary`}
              onClick={(e) => openSizeModal(e, "buy-now")}
            >
              <SvgWrapper svgSrc="buyNow" className={styles.cartIcon} />
              {t("resource.common.buy_now")}
            </button>
          </motion.div>
        )}
      </AnimatePresence>
      <div className={styles.addToCartModal}>
        <Modal
          isOpen={showSizeModal}
          title={t("resource.common.select_size")}
          closeDialog={() => setShowSizeModal(false)}
          headerClassName={styles.customMHeader}
          bodyClassName={styles.customMBody}
          isCancellable={false}
        >
          <div>
            <div className={styles.guideCta}>
              <span style={{ width: "65%" }}>
                {selectedSize
                  ? `${t("resource.product.style_size")} (${selectedSize})`
                  : t("resource.common.select_size_caps")}
              </span>
              {isSizeGuideAvailable && (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      setShowSizeGuide(true);
                    }}
                    className={styles["product__size--guide"]}
                  >
                    <span>{t("resource.common.size_guide")}</span>
                    <SvgWrapper svgSrc="scale" className={styles.scaleIcon} />
                  </button>
                </>
              )}
            </div>

            <div className={styles.sizes}>
              <ul>
                {sizes?.sizes?.map?.((size, index) => (
                  <li
                    key={index}
                    onClick={() => onSizeSelection(size)}
                    className={`${styles.product__size} ${selectedSize === size.display && styles["product__size--selected"]} ${size.quantity === 0 && styles["product__size--disabled"]}`}
                  >
                    {size.display.length < 15
                      ? size.display
                      : `${size.display.substring(0, 15)}...`}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className={styles.priceBlock}>
            <div className={styles.productPrice}>
              {getProductPrice("effective") &&
                blockProps?.mrp_label &&
                getProductPrice("effective") === getProductPrice("marked") && (
                  <span className="mrp-label">{t("resource.common_common_words.mrp")}</span>
                )}
              <h4 className={styles["productPrice--effective"]}>
                {getProductPrice("effective")}
              </h4>

              {getProductPrice("marked") &&
                blockProps?.mrp_label &&
                getProductPrice("effective") !== getProductPrice("marked") && (
                  <>
                    <span className={styles.mrpLabel}>{t("resource.common_common_words.mrp")}</span>
                    <span className={styles["productPrice--marked"]}>
                      {getProductPrice("marked")}
                    </span>
                  </>
                )}

              {productPriceBySlug?.discount && (
                <span className={styles["productPrice--discount"]}>
                  {productPriceBySlug?.discount}
                </span>
              )}
            </div>

            {blockProps?.tax_label && (
              <div className={`${styles["caption-normal"]} ${styles.taxLabel}`}>
                {blockProps?.tax_label}
              </div>
            )}
          </div>

          {selectedSize && <DeliveryInfo {...deliveryInfoProps} />}

          {modalType === "add-to-cart" && (
            <button
              type="button"
              className={`btnSecondary ${styles.button}`}
              onClick={(e) => cartHandler(e, false)}
              disabled={!productMeta.sellable}
            >
              <SvgWrapper svgSrc="cart" className={styles.cartIcon} />
              {t("resource.common.add_to_cart")}
            </button>
          )}

          {modalType === "buy-now" && (
            <button
              type="button"
              className={`btnPrimary ${styles.button}`}
              onClick={(e) => cartHandler(e, true)}
              disabled={!productMeta.sellable}
            >
              <SvgWrapper svgSrc="buyNow" className={styles.cartIcon} />
              {t("resource.common.buy_now")}
            </button>
          )}
        </Modal >
        {isSizeGuideAvailable && (
          <SizeGuide
            customClass={styles.sizeGuide}
            isOpen={showSizeGuide}
            onCloseDialog={(e) => {
              e.preventDefault();
              setShowSizeGuide(false);
            }}
            productMeta={productMeta}
          />
        )}
      </div >
    </>
  );
};

export default StickyAddToCart;
