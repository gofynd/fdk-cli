import CartLanding from "./templates/pages/cart-landing.vue";
import Categories from "./templates/pages/categories.vue";
import Collections from "./templates/pages/collections.vue";
import CollectionListing from "./templates/pages/collection-listing.vue";
import BrandListing from "./templates/pages/brand-listing.vue";
import CategoryListing from "./templates/pages/category-listing.vue";
import CompareProducts from "./templates/pages/compare-products.vue";
import Footer from "./templates/components/footer.vue";
import Header from "./templates/components/header.vue";
import ProductDescription from "./templates/pages/product-description.vue";
import ProductListing from "./templates/pages/product-listing.vue";
import ProductReviews from "./templates/pages/product-reviews.vue";
import AddProductReview from "./templates/pages/add-product-review.vue";
import ScreenSaver from "./templates/components/screen-saver.vue";
import Loader from "./templates/components/loader.vue";
import Wishlist from "./templates/pages/wishlist.vue";
import Brands from "./templates/pages/brands.vue";
import EmptyState from "./templates/components/empty-state.vue";
import FAQ from "./templates/pages/faq.vue";
import Home from "./templates/pages/home.vue";
import CustomTemplates from "./custom-templates";
import styles from "./global/head.less";
import sections from "./sections";

/* UNCOMMENT TO APPLY FYND THEME */

export default {
    getCartLanding: () => CartLanding,
    getCategories: () => Categories,
    getCollections: () => Collections,
    getCollectionListing: () => CollectionListing,
    getBrandListing: () => BrandListing,
    getCategoryListing: () => CategoryListing,
    getCompareProducts: () => CompareProducts,
    getFooter: () => Footer,
    getHeader: () => Header,
    getProductDescription: () => ProductDescription,
    getProductListing: () => ProductListing,
    getScreenSaver: () => ScreenSaver,
    getHome: () => Home,
    getBrands: () => Brands,
    getLoader: () => Loader,
    getWishList: () => Wishlist,
    getFaq: () => FAQ,
    getEmptyState: () => null,
    getProductReviews: () => ProductReviews,
    getAddProductReview: () => AddProductReview,
    getCustomTemplates: () => {
        return CustomTemplates;
    },
    sections,
};