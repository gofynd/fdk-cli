import React from "react";
import SetPasswordPage from "../page-layouts/set-password/set-password-page";

function SetPassword({ fpi }) {
  return <SetPasswordPage fpi={fpi} />;
}

export default SetPassword;
